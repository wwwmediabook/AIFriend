# AI Friend
1. GitHub এ নতুন repo বানান, এই ফোল্ডারের সব ফাইল (লুকানো .github সহ) আপলোড করুন।
2. Actions ট্যাব -> Build APK -> শেষ হলে Artifacts থেকে AIFriend-APK ডাউনলোড করুন।
3. APK ইনস্টল করে Settings এ API Key (aistudio.google.com/apikey), মডেল, নাম দিন।
4. পারমিশন দিন -> START চাপুন।
