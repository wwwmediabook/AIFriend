package com.aifriend.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** অনুমোদন-মোডে নোটিফিকেশনের "পাঠাও / বাতিল" বাটন */
class BizReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        if (i.action == "PAUSE") {
            BizListener.paused[i.getStringExtra("key") ?: ""] = System.currentTimeMillis() + 6 * 3600_000L
            BizListener.pending.remove(id)
            c.getSystemService(NotificationManager::class.java).cancel(id)
            Biz.log(c, "একটি চ্যাট ৬ ঘণ্টা থামানো হয়েছে")
            return
        }
        val p = BizListener.pending.remove(id) ?: return
        if (i.action == "SEND") {
            val ok = BizListener.send(c, p.action, p.text)
            if (ok) {
                if (p.order != null) Biz.addOrder(c, p.shopId, p.shopName, p.app, p.who, p.order)
                Biz.log(c, "অনুমোদিত উত্তর পাঠানো: ${p.who}")
            } else Biz.log(c, "পাঠানো যায়নি (চ্যাটের নোটিফিকেশন আর নেই): ${p.who}")
        }
        c.getSystemService(NotificationManager::class.java).cancel(id)
    }
}
