package com.aifriend.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * সম্পূর্ণ কাল্পনিক কার্টুন চরিত্র (বাস্তব কারো মুখ নয়): ছেলে বা মেয়ে, মাথা থেকে পা পর্যন্ত দাঁড়ানো।
 * state: 0 অপেক্ষা, 1 শুনছে, 2 ভাবছে, 3 বলছে। male = false মানে মেয়ে ভার্সন।
 */
class Avatar(c: Context) : View(c) {
    var state = 0
    var theme = "ocean"
    var male = false
    var outfitColor: Int? = null   // null হলে থিমের রঙ ব্যবহার হয়
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f
    private var blink = 1f

    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                t = it.animatedValue as Float
                blink = if (t > 0.93f) 0.08f else 1f
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val pal = Theme.of(theme)
        val cx = width / 2f
        val headCy = height * 0.26f
        val r = min(width, height) * 0.22f   // মাথার আকার, পুরো শরীর আঁকার মাপকাঠি
        val skin = 0xFFF3C7A1.toInt()
        val outfit = outfitColor ?: when (state) { 3 -> pal.speak; 2 -> pal.think; 1 -> pal.listen; else -> pal.idle }
        val hairCol = Color.rgb(
            (Color.red(pal.speak) * 0.32f).toInt(), (Color.green(pal.speak) * 0.26f).toInt(), (Color.blue(pal.speak) * 0.38f + 18).toInt().coerceAtMost(255))

        // পেছনের গ্লো
        p.style = Paint.Style.FILL
        val pulse = 0.5f + 0.5f * sin(t * 6.283f * (if (state == 3) 2 else 1))
        p.shader = RadialGradient(cx, headCy, r * (2.4f + 0.4f * pulse), intArrayOf((pal.idle and 0xFFFFFF) or (0x2A shl 24), 0x00000000), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, headCy, r * 2.6f, p); p.shader = null

        // ---------- শরীরের পরিমাপ ----------
        val neckY = headCy + r * 0.95f
        val shoulderY = neckY + r * 0.22f
        val hipY = shoulderY + r * (if (male) 2.3f else 2.6f)
        val footY = min(height * 0.97f, hipY + r * 2.6f)
        val shoulderW = r * (if (male) 1.15f else 0.95f)
        val hipW = r * (if (male) 0.75f else 1.15f)

        // পা ও জুতা
        p.color = skin; p.style = Paint.Style.FILL
        for (s in intArrayOf(-1, 1)) c.drawRoundRect(cx + s * hipW * 0.32f - r * 0.13f, hipY, cx + s * hipW * 0.32f + r * 0.13f, footY - r * 0.12f, r * 0.08f, r * 0.08f, p)
        p.color = 0xFF2B2B33.toInt()
        for (s in intArrayOf(-1, 1)) c.drawRoundRect(cx + s * hipW * 0.32f - r * 0.17f, footY - r * 0.15f, cx + s * hipW * 0.32f + r * 0.2f, footY, r * 0.06f, r * 0.06f, p)

        // পোশাক: মূল শরীর (ছেলে: শার্ট+প্যান্ট ঢিলা রেখা, মেয়ে: গাউন/স্কার্ট)
        p.color = outfit
        if (male) {
            // শার্ট
            path.reset(); path.moveTo(cx - shoulderW, shoulderY)
            path.lineTo(cx - hipW, hipY); path.lineTo(cx + hipW, hipY); path.lineTo(cx + shoulderW, shoulderY)
            path.cubicTo(cx + shoulderW * 0.4f, shoulderY - r * 0.05f, cx - shoulderW * 0.4f, shoulderY - r * 0.05f, cx - shoulderW, shoulderY)
            path.close(); c.drawPath(path, p)
            // প্যান্ট
            val darker = Color.rgb((Color.red(outfit) * 0.55f).toInt(), (Color.green(outfit) * 0.55f).toInt(), (Color.blue(outfit) * 0.55f).toInt())
            p.color = darker
            for (s in intArrayOf(-1, 1)) c.drawRect(cx + s * hipW * 0.5f - r * 0.22f, hipY - r * 0.1f, cx + s * hipW * 0.5f + r * 0.22f, hipY + r * 1.4f, p)
        } else {
            // গাউন/ড্রেস: কাঁধ থেকে ছড়ানো স্কার্ট পর্যন্ত
            path.reset(); path.moveTo(cx - shoulderW, shoulderY)
            path.cubicTo(cx - hipW * 1.15f, hipY + r * 0.3f, cx - hipW * 1.3f, footY - r * 0.4f, cx - hipW * 1.1f, footY - r * 0.1f)
            path.lineTo(cx + hipW * 1.1f, footY - r * 0.1f)
            path.cubicTo(cx + hipW * 1.3f, footY - r * 0.4f, cx + hipW * 1.15f, hipY + r * 0.3f, cx + shoulderW, shoulderY)
            path.cubicTo(cx + shoulderW * 0.4f, shoulderY - r * 0.05f, cx - shoulderW * 0.4f, shoulderY - r * 0.05f, cx - shoulderW, shoulderY)
            path.close(); c.drawPath(path, p)
            // হালকা ফ্লোরাল প্যাটার্নের আভাস (ছোট ছোট বিন্দু)
            p.color = 0x33FFFFFF
            for (i in 0 until 10) {
                val fx = cx + (i - 5) * hipW * 0.22f
                val fy = hipY + r * 0.6f + (i % 3) * r * 0.5f
                c.drawCircle(fx, fy, r * 0.045f, p)
            }
        }

        // ঘাড়
        p.color = skin; c.drawRoundRect(cx - r * 0.18f, neckY - r * 0.05f, cx + r * 0.18f, neckY + r * 0.2f, r * 0.08f, r * 0.08f, p)

        // মাথা
        p.color = skin
        c.drawOval(cx - r * 0.85f, headCy - r * 1.05f, cx + r * 0.85f, headCy + r * 0.85f, p)

        // চুল
        p.color = hairCol
        if (male) {
            path.reset()
            path.moveTo(cx - r * 0.85f, headCy - r * 0.05f)
            path.cubicTo(cx - r * 0.95f, headCy - r * 1.15f, cx - r * 0.2f, headCy - r * 1.3f, cx, headCy - r * 1.2f)
            path.cubicTo(cx + r * 0.2f, headCy - r * 1.3f, cx + r * 0.95f, headCy - r * 1.15f, cx + r * 0.85f, headCy - r * 0.05f)
            path.cubicTo(cx + r * 0.8f, headCy - r * 0.5f, cx + r * 0.5f, headCy - r * 0.6f, cx + r * 0.4f, headCy - r * 0.3f)
            path.cubicTo(cx + r * 0.25f, headCy - r * 0.65f, cx - r * 0.25f, headCy - r * 0.65f, cx - r * 0.4f, headCy - r * 0.3f)
            path.cubicTo(cx - r * 0.5f, headCy - r * 0.6f, cx - r * 0.8f, headCy - r * 0.5f, cx - r * 0.85f, headCy - r * 0.05f)
            path.close(); c.drawPath(path, p)
        } else {
            path.reset()
            path.moveTo(cx - r * 0.95f, headCy - r * 0.1f)
            path.cubicTo(cx - r * 1.05f, headCy - r * 1.25f, cx - r * 0.3f, headCy - r * 1.5f, cx, headCy - r * 1.35f)
            path.cubicTo(cx + r * 0.3f, headCy - r * 1.5f, cx + r * 1.05f, headCy - r * 1.25f, cx + r * 0.95f, headCy - r * 0.1f)
            path.cubicTo(cx + r * 0.95f, headCy - r * 0.5f, cx + r * 0.55f, headCy - r * 0.65f, cx + r * 0.4f, headCy - r * 0.35f)
            path.cubicTo(cx + r * 0.3f, headCy - r * 0.75f, cx - r * 0.3f, headCy - r * 0.75f, cx - r * 0.4f, headCy - r * 0.35f)
            path.cubicTo(cx - r * 0.55f, headCy - r * 0.65f, cx - r * 0.95f, headCy - r * 0.5f, cx - r * 0.95f, headCy - r * 0.1f)
            path.close(); c.drawPath(path, p)
            for (s in intArrayOf(-1, 1)) {
                path.reset()
                path.moveTo(cx + s * r * 0.85f, headCy - r * 0.2f)
                path.cubicTo(cx + s * r * 1.05f, headCy + r * 0.5f, cx + s * r * 0.9f, headCy + r * 1.1f, cx + s * r * 0.55f, headCy + r * 1.3f)
                path.cubicTo(cx + s * r * 0.8f, headCy + r * 0.7f, cx + s * r * 0.75f, headCy + r * 0.1f, cx + s * r * 0.65f, headCy - r * 0.15f)
                path.close(); c.drawPath(path, p)
            }
        }

        // গাল
        p.color = 0x33FF8FA3
        c.drawCircle(cx - r * 0.55f, headCy + r * 0.18f, r * 0.17f, p)
        c.drawCircle(cx + r * 0.55f, headCy + r * 0.18f, r * 0.17f, p)

        // চোখ
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * r * 0.32f; val ey = headCy - r * 0.08f
            p.color = Color.WHITE
            c.drawOval(ex - r * 0.17f, ey - r * 0.2f * blink, ex + r * 0.17f, ey + r * 0.2f * blink, p)
            p.color = hairCol
            c.drawCircle(ex, ey, r * 0.1f * blink, p)
            p.color = Color.WHITE
            c.drawCircle(ex - r * 0.04f, ey - r * 0.06f, r * 0.03f * blink, p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.03f; p.strokeCap = Paint.Cap.ROUND; p.color = hairCol
        for (s in intArrayOf(-1, 1)) c.drawLine(cx + s * r * 0.18f, headCy - r * 0.34f, cx + s * r * 0.46f, headCy - r * 0.38f, p)
        p.style = Paint.Style.FILL

        // মুখ: কথা বললে নড়ে
        p.color = 0xFFB85C6B.toInt()
        if (state == 3) {
            val o = r * (0.05f + 0.15f * abs(sin(t * 6.283f * 4)))
            c.drawOval(cx - r * 0.17f, headCy + r * 0.3f - o / 2, cx + r * 0.17f, headCy + r * 0.3f + o / 2, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.045f; p.strokeCap = Paint.Cap.ROUND
            c.drawArc(cx - r * 0.2f, headCy + r * 0.16f, cx + r * 0.2f, headCy + r * 0.44f, 15f, 150f, false, p)
            p.style = Paint.Style.FILL
        }

        // হাত: কথা বলা/শোনার সময় একটু নড়ে
        val wave = sin(t * 6.283f * 1.3f) * (if (state == 3) 1f else if (state == 1) 0.35f else 0.1f)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.17f; p.strokeCap = Paint.Cap.ROUND
        for (sgn in intArrayOf(-1, 1)) {
            p.color = outfit
            val hx = cx + sgn * shoulderW; val hy = shoulderY + r * 0.1f
            val lift = if (sgn == 1) wave else wave * 0.3f
            c.drawLine(hx, hy, hx + sgn * r * 0.15f, hy + r * 0.9f - lift * r * 0.25f, p)
            p.color = skin; p.style = Paint.Style.FILL
            c.drawCircle(hx + sgn * r * 0.15f, hy + r * 0.9f - lift * r * 0.25f, r * 0.13f, p)
            p.style = Paint.Style.STROKE
        }
        p.style = Paint.Style.FILL
    }
}
