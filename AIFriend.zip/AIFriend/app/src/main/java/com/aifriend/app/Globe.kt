package com.aifriend.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** পৃথিবীর মতো ঘুরতে থাকা গোল মুখ (ফুল স্ক্রিন) — state: 0 অপেক্ষা, 1 শুনছে, 2 ভাবছে, 3 বলছে */
class Globe(c: Context) : View(c) {
    var state = 0
    var theme = "ocean"  // ocean, sunset, royal, mono, candy
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f
    private var rot = 0f
    private val cities = arrayOf(
        floatArrayOf(10f, 20f), floatArrayOf(60f, -10f), floatArrayOf(110f, 35f), floatArrayOf(160f, 5f),
        floatArrayOf(200f, -30f), floatArrayOf(250f, 25f), floatArrayOf(300f, -5f), floatArrayOf(340f, 40f),
        floatArrayOf(35f, -40f), floatArrayOf(130f, -20f), floatArrayOf(230f, 50f), floatArrayOf(280f, 15f))

    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                t = it.animatedValue as Float
                rot = (rot + (if (state == 3) 1.8f else if (state == 2) 1.1f else 0.55f)) % 360f
                invalidate()
            }
            start()
        }
    }

    private fun rad(d: Float) = Math.toRadians(d.toDouble()).toFloat()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = min(width, height) * 0.36f
        val pal = Theme.of(theme)
        val col = when (state) { 3 -> pal.speak; 2 -> pal.think; 1 -> pal.listen; else -> pal.idle }
        val rgb = col and 0xFFFFFF
        val pulse = 0.5f + 0.5f * sin(t * 6.283f * (if (state == 3) 2 else 1))
        val g = r * (1.45f + 0.3f * pulse)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, g, intArrayOf(rgb or (0xB0 shl 24), rgb), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, g, p)
        p.shader = RadialGradient(cx - r / 3, cy - r / 3, r * 1.6f, intArrayOf(0xFFFFFFFF.toInt(), col, 0xFF0B0F2E.toInt()),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p); p.shader = null

        // পৃথিবীর দ্রাঘিমা/অক্ষরেখা ও শহর, গোলকের ভেতরে
        c.save(); path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(path)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.012f + 1.5f
        for (k in 0 until 6) {
            val w = abs(cos(rad(rot + k * 30f))) * r
            p.color = 0x55FFFFFF
            c.drawOval(cx - w, cy - r, cx + w, cy + r, p)
        }
        for (lat in intArrayOf(-60, -30, 0, 30, 60)) {
            val la = rad(lat.toFloat())
            val y = cy + r * sin(la); val w = r * cos(la)
            p.color = 0x33FFFFFF
            c.drawLine(cx - w, y, cx + w, y, p)
        }
        p.style = Paint.Style.FILL
        for (ct in cities) {
            val lon = rad(ct[0] + rot); val la = rad(ct[1])
            val z = cos(la) * cos(lon)
            if (z > 0f) {
                p.color = ((z * 220).toInt() shl 24) or 0xFFFFFF
                c.drawCircle(cx + r * cos(la) * sin(lon), cy - r * sin(la), r * 0.025f + 1f, p)
            }
        }
        c.restore()

        // ঘূর্ণায়মান বলয় ও উপগ্রহ
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = rgb or (0x66 shl 24)
        c.save(); c.rotate(-18f, cx, cy)
        c.drawOval(cx - r * 1.35f, cy - r * 0.38f, cx + r * 1.35f, cy + r * 0.38f, p)
        val oa = rad(rot * 2f)
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawCircle(cx + r * 1.35f * cos(oa), cy + r * 0.38f * sin(oa), r * 0.04f, p)
        c.restore()

        // মুখ: চোখ ও ঠোঁট
        val blink = if (t > 0.92f) 0.15f else 1f
        for (s in listOf(-1, 1)) {
            p.style = Paint.Style.FILL; p.color = 0x66FFFFFF
            c.drawOval(cx + s * r * 0.36f - r * 0.12f, cy - r * 0.12f - r * 0.19f * blink, cx + s * r * 0.36f + r * 0.12f, cy - r * 0.12f + r * 0.19f * blink, p)
            p.color = 0xFF0B0F1E.toInt()
            c.drawOval(cx + s * r * 0.36f - r * 0.09f, cy - r * 0.12f - r * 0.15f * blink, cx + s * r * 0.36f + r * 0.09f, cy - r * 0.12f + r * 0.15f * blink, p)
        }
        if (state == 3) {
            val o = r * (0.06f + 0.2f * abs(sin(t * 6.283f * 4)))
            p.style = Paint.Style.FILL; p.color = 0xFF0B0F1E.toInt()
            c.drawOval(cx - r * 0.2f, cy + r * 0.3f - o / 2, cx + r * 0.2f, cy + r * 0.3f + o / 2, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.06f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFF0B0F1E.toInt()
            c.drawArc(cx - r * 0.24f, cy + r * 0.08f, cx + r * 0.24f, cy + r * 0.46f, 20f, 140f, false, p)
            p.style = Paint.Style.FILL
        }
    }
}
