package com.aifriend.app

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

/** ফোনের নিরাপত্তা পরীক্ষা: সত্যিকারের সেটিং, অ্যাপ ও অনুমতি যাচাই (অ্যান্টিভাইরাসের বিকল্প নয়) */
object Scanner {
    class Finding(val sev: Int, val title: String, val detail: String)
    class Result(val findings: List<Finding>, val score: Int, val apps: Int) {
        fun text(): String = findings.take(25).joinToString("\n") {
            "[${arrayOf("info", "low", "medium", "HIGH")[it.sev]}] ${it.title}: ${it.detail}"
        }
    }

    private val RISKY = mapOf(
        "android.permission.READ_SMS" to 2, "android.permission.RECEIVE_SMS" to 2, "android.permission.SEND_SMS" to 2,
        "android.permission.READ_CALL_LOG" to 1, "android.permission.RECORD_AUDIO" to 1, "android.permission.CAMERA" to 1,
        "android.permission.ACCESS_FINE_LOCATION" to 1, "android.permission.SYSTEM_ALERT_WINDOW" to 2,
        "android.permission.REQUEST_INSTALL_PACKAGES" to 2, "android.permission.BIND_ACCESSIBILITY_SERVICE" to 3,
        "android.permission.BIND_DEVICE_ADMIN" to 3, "android.permission.READ_CONTACTS" to 1)

    private val STORES = setOf("com.android.vending", "com.sec.android.app.samsungapps", "com.xiaomi.mipicks", "com.xiaomi.market",
        "com.huawei.appmarket", "com.amazon.venezia", "com.heytap.market", "com.vivo.appstore", "com.oppo.market", "org.fdroid.fdroid")

    private fun label(pm: PackageManager, pkg: String): String =
        try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

    @Suppress("DEPRECATION")
    private fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName else pm.getInstallerPackageName(pkg)
    } catch (e: Exception) { null }

    private fun sha256(f: File): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s -> val b = ByteArray(65536); while (true) { val n = s.read(b); if (n <= 0) break; md.update(b, 0, n) } }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { null }

    private fun vt(key: String, sha: String): String = try {
        val cn = URL("https://www.virustotal.com/api/v3/files/${sha}").openConnection() as HttpURLConnection
        cn.setRequestProperty("x-apikey", key); cn.connectTimeout = 15000; cn.readTimeout = 20000
        when (cn.responseCode) {
            200 -> {
                val st = JSONObject(cn.inputStream.bufferedReader().readText()).getJSONObject("data").getJSONObject("attributes").getJSONObject("last_analysis_stats")
                val m = st.optInt("malicious", 0)
                if (m >= 3) "mal:${m}" else if (m >= 1) "weak:${m}" else "clean"
            }
            404 -> "unknown"
            429 -> "rate"
            401, 403 -> "key"
            else -> "err"
        }
    } catch (e: Exception) { "err" }

    fun scan(c: Context, vtKey: String, log: (String, Int) -> Unit): Result {
        val out = ArrayList<Finding>()
        val pm = c.packageManager
        log("সিস্টেম ও নিরাপত্তা সেটিংস পরীক্ষা…", 4)
        try {
            val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) out.add(Finding(3, "স্ক্রিন লক নেই", "পিন, প্যাটার্ন বা ফিঙ্গারপ্রিন্ট দিন, নইলে ফোন হারালে সব খোলা থাকবে"))
        } catch (_: Exception) {}
        try {
            if (Settings.Global.getInt(c.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1)
                out.add(Finding(2, "USB ডিবাগিং চালু", "দরকার না হলে ডেভেলপার অপশন থেকে বন্ধ করুন"))
        } catch (_: Exception) {}
        try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH)
            if (d != null) {
                val months = (System.currentTimeMillis() - d.time) / (30L * 24 * 3600 * 1000)
                if (months >= 12) out.add(Finding(2, "নিরাপত্তা আপডেট অনেক পুরনো", "সর্বশেষ প্যাচ ${Build.VERSION.SECURITY_PATCH} (${months} মাস আগে), আপডেট দিন"))
                else if (months >= 6) out.add(Finding(1, "নিরাপত্তা আপডেট পিছিয়ে", "সর্বশেষ প্যাচ ${Build.VERSION.SECURITY_PATCH}"))
            }
        } catch (_: Exception) {}
        val su = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk", "/su/bin/su")
        if (su.any { File(it).exists() } || (Build.TAGS ?: "").contains("test-keys"))
            out.add(Finding(3, "রুট বা পরিবর্তিত সিস্টেমের চিহ্ন", "ফোনটি রুট করা বা অননুমোদিতভাবে বদলানো হতে পারে"))
        try {
            val sf = StatFs(Environment.getDataDirectory().path)
            val free = sf.availableBytes * 100 / sf.totalBytes
            if (free < 10) out.add(Finding(1, "স্টোরেজ প্রায় ভরা", "মাত্র ${free}% খালি, ফোন ধীর হতে পারে"))
        } catch (_: Exception) {}
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) out.add(Finding(0, "VPN চালু", "নিজে চালু না করলে দেখে নিন"))
        } catch (_: Exception) {}

        log("অ্যাক্সেসিবিলিটি, নোটিফিকেশন ও অ্যাডমিন অনুমতি…", 10)
        fun pkgs(raw: String?) = (raw ?: "").split(":").map { it.substringBefore("/") }.filter { it.isNotBlank() && it != c.packageName }
        for (p in pkgs(Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)))
            out.add(Finding(2, "অ্যাক্সেসিবিলিটি চালু: ${label(pm, p)}", "এটি স্ক্রিন পড়তে ও ট্যাপ করতে পারে। চেনা অ্যাপ না হলে বন্ধ করুন"))
        for (p in pkgs(Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners")))
            out.add(Finding(1, "নোটিফিকেশন পড়তে পারে: ${label(pm, p)}", "OTP ও মেসেজ দেখতে পারে। দরকার না হলে বন্ধ করুন"))
        try {
            val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.activeAdmins?.forEach { out.add(Finding(2, "ডিভাইস অ্যাডমিন: ${label(pm, it.packageName)}", "সরানো কঠিন করতে পারে। চেনা না হলে বন্ধ করুন")) }
        } catch (_: Exception) {}

        val user = pm.getInstalledApplications(0).filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
        val total = user.size
        val vtCand = ArrayList<Pair<String, String>>()
        var i = 0
        for (a in user) {
            i++
            val pkg = a.packageName
            log("অ্যাপ বিশ্লেষণ: ${pkg}", 14 + 56 * i / maxOf(total, 1))
            val info = try { pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES) } catch (e: Exception) { null } ?: continue
            var score = 0
            val why = ArrayList<String>()
            for (p in (info.requestedPermissions ?: emptyArray())) {
                val w = RISKY[p]
                if (w != null) { score += w; if (why.size < 4) why.add(p.substringAfterLast('.')) }
            }
            if (info.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true) { score += 3; why.add("অ্যাক্সেসিবিলিটি সার্ভিস") }
            val side = (installer(pm, pkg) ?: "") !in STORES
            if (side) { score += 2; why.add("অফিসিয়াল স্টোরের বাইরে থেকে ইনস্টল") }
            if (pm.getLaunchIntentForPackage(pkg) == null && score >= 2) { score += 1; why.add("আইকন নেই (লুকানো)") }
            if ((a.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) { score += 2; why.add("ডিবাগযোগ্য") }
            if (a.targetSdkVersion < 23) { score += 1; why.add("অনেক পুরনো অ্যাপ") }
            val sev = when { side && score >= 9 -> 3; side && score >= 7 -> 2; score >= 11 -> 2; side && score >= 5 -> 1; else -> 0 }
            if (sev > 0) out.add(Finding(sev, label(pm, pkg), why.joinToString(", ") + " (ঝুঁকি-পয়েন্ট ${score}) [${pkg}]"))
            if (side && vtCand.size < 8) vtCand.add(Pair(pkg, a.sourceDir))
        }

        if (vtKey.isNotBlank() && vtCand.isNotEmpty()) {
            var n = 0
            for ((pkg, path) in vtCand) {
                n++
                log("VirusTotal যাচাই: ${pkg}", 70 + 28 * n / vtCand.size)
                val sh = sha256(File(path)) ?: continue
                val r = vt(vtKey, sh)
                var stop = false
                when {
                    r.startsWith("mal:") -> out.add(Finding(3, "ম্যালওয়্যার শনাক্ত: ${label(pm, pkg)}", "VirusTotal-এর ${r.substring(4)}টি ইঞ্জিন বিপজ্জনক বলেছে। মুছে ফেলা ভালো"))
                    r.startsWith("weak:") -> out.add(Finding(1, "সন্দেহ: ${label(pm, pkg)}", "VirusTotal-এর ${r.substring(5)}টি ইঞ্জিন সন্দেহ করেছে (ভুল সংকেতও হতে পারে)"))
                    r == "unknown" -> out.add(Finding(1, "অচেনা ফাইল: ${label(pm, pkg)}", "VirusTotal-এর ডেটাবেসে এই ফাইল নেই"))
                    r == "rate" -> { out.add(Finding(0, "VirusTotal সীমা শেষ", "বাকি অ্যাপ যাচাই হয়নি")); stop = true }
                    r == "key" -> { out.add(Finding(0, "VirusTotal কী কাজ করেনি", "কীটা আবার দেখুন")); stop = true }
                }
                if (stop) break
                if (n < vtCand.size) Thread.sleep(16000)
            }
        }

        var score = 100
        for (f in out) score -= when (f.sev) { 3 -> 18; 2 -> 8; 1 -> 3; else -> 0 }
        score = score.coerceIn(5, 100)
        log("স্ক্যান সম্পন্ন", 100)
        return Result(out.sortedByDescending { it.sev }, score, total)
    }
}
