package com.aifriend.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject
import java.io.File

/**
 * WhatsApp / WhatsApp Business / Messenger-এর ইনকামিং ডিএম নোটিফিকেশন পড়ে,
 * দোকানের তথ্য অনুযায়ী উত্তর বানায় এবং নোটিফিকেশনের "Reply" দিয়ে পাঠায়।
 */
class BizListener : NotificationListenerService() {
    class Pending(val action: Notification.Action, val text: String, val who: String, val order: JSONObject?,
                  val shopId: String, val shopName: String, val app: String)

    companion object {
        val pending = HashMap<Int, Pending>()
        @Volatile var nid = 1000

        fun send(c: Context, a: Notification.Action, text: String): Boolean {
            return try {
                val ris = a.remoteInputs ?: return false
                val i = Intent(); val b = Bundle()
                for (r in ris) b.putCharSequence(r.resultKey, text)
                RemoteInput.addResultsToIntent(ris, i, b)
                a.actionIntent.send(c, 0, i)
                true
            } catch (e: Exception) { false }
        }
    }

    private val lastTs = HashMap<String, Long>()
    private val lastText = HashMap<String, String>()
    private val botText = HashMap<String, String>()
    private val sentLog = HashMap<String, ArrayList<Long>>()
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        Gemini.init(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("biz", "ব্যবসা", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) { try { handle(sbn) } catch (_: Exception) {} }

    private fun ownerNote(title: String, text: String) {
        val id = nid++
        val n = Notification.Builder(this, "biz").setSmallIcon(R.drawable.ic_store).setContentTitle(title)
            .setContentText(text.take(90)).setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(id, n)
    }

    private fun handle(sbn: StatusBarNotification) {
        val mode = cfg.getString("bizmode", "off") ?: "off"
        if (mode == "off") return
        val app = when (sbn.packageName) { "com.whatsapp" -> "wa"; "com.whatsapp.w4b" -> "w4b"; "com.facebook.orca" -> "msg"; else -> return }
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras
        if (ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return
        if (!(ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString() ?: "").isBlank()) return
        val act = n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true } ?: return
        val who = (ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "").trim()
        if (who.isEmpty()) return

        var text: String? = null; var ts = 0L
        val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (msgs != null && msgs.isNotEmpty()) {
            val m = msgs[msgs.size - 1] as? Bundle
            text = m?.getCharSequence("text")?.toString(); ts = m?.getLong("time") ?: 0L
        }
        if (text.isNullOrBlank()) text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        if (text.isNullOrBlank()) return
        val key = "${app}|${who}"
        if (text == botText[key]) return
        if (ts != 0L && ts <= (lastTs[key] ?: 0L)) return
        if (ts == 0L && text == lastText[key]) return
        lastTs[key] = ts; lastText[key] = text

        val now = System.currentTimeMillis()
        val sl = sentLog.getOrPut(key) { ArrayList() }
        sl.removeAll { now - it > 600_000L }
        if (sl.size >= 6) { Biz.log(this, "থামানো হলো (বারবার উত্তর): ${who}"); return }

        val shop = Biz.shopFor(this, app) ?: return
        val msgText: String = text
        Thread { reply(mode, app, who, key, msgText, act, shop) }.start()
    }

    private fun validate(shop: JSONObject, order: JSONObject, round: Int): JSONObject? {
        val items = order.optJSONArray("items") ?: return null
        if (items.length() == 0) return null
        val ps = shop.optJSONArray("products") ?: return null
        val out = org.json.JSONArray(); var total = 0.0
        for (i in 0 until items.length()) {
            val row = items.getJSONObject(i)
            val name = row.optString("name").trim().lowercase()
            val qty = row.optInt("qty", 1).coerceAtLeast(1)
            val price = row.optDouble("price", -1.0)
            if (name.isBlank()) return null
            var prod: JSONObject? = null
            for (k in 0 until ps.length()) {
                val pr = ps.getJSONObject(k); val pn = pr.optString("name").lowercase()
                if (pn == name || pn.contains(name) || name.contains(pn)) { prod = pr; break }
            }
            if (prod == null) return null
            val stock = prod.optInt("stock", -1)
            if (stock >= 0 && stock < qty) return null
            if (price < Biz.best(prod, round) - 0.5) return null
            out.put(JSONObject().put("name", prod.optString("name")).put("qty", qty).put("price", price))
            total += price * qty
        }
        return JSONObject().put("items", out).put("total", total)
            .put("customer", order.optString("customer")).put("phone", order.optString("phone"))
            .put("address", order.optString("address")).put("note", order.optString("note"))
    }

    private fun reply(mode: String, app: String, who: String, key: String, text: String, act: Notification.Action, shop: JSONObject) {
        val appName = when (app) { "wa" -> "WhatsApp"; "w4b" -> "WhatsApp Business"; else -> "Messenger" }
        val owner = cfg.getString("owner", "মৃদুল") ?: "মৃদুল"
        try {
            Biz.addChat(this, key, "user", text)
            val first = Biz.count(this, key) <= 1
            val round = Biz.round(this, key)
            val j = Gemini.bizReply(cfg.getString("key", "") ?: "", cfg.getString("model", Gemini.DEF_MODEL) ?: Gemini.DEF_MODEL,
                Biz.prompt(shop, appName, owner, round), Biz.history(this, key))
            var reply = j.optString("reply", "").trim()
            val handoff = j.optBoolean("handoff", false)
            if (j.optBoolean("bargained", false)) Biz.setRound(this, key, round + 1)

            var order: JSONObject? = null
            if (j.optString("action") == "confirm_order") {
                order = validate(shop, j.optJSONObject("order") ?: JSONObject(), round)
                if (order == null) {
                    reply = "দুঃখিত, এই অর্ডারটা এখনই নিশ্চিত করতে পারছি না। মালিক শীঘ্রই আপনার সাথে যোগাযোগ করবেন।"
                    ownerNote("⚠️ অর্ডার যাচাই হয়নি: ${who}", "গ্রাহক: ${text}\nদাম বা স্টক মেলেনি, আপনি দেখুন।")
                    Biz.log(this, "অর্ডার যাচাই ব্যর্থ: ${who}")
                }
            }
            if (reply.isBlank()) return
            if (first && cfg.getBoolean("bizintro", true)) {
                val intro = (cfg.getString("bizintrotext", "") ?: "").ifBlank { "আমি ${shop.optString("name")}-এর এআই সহকারী, মালিকের হয়ে আপনাকে সাহায্য করছি।" }
                reply = intro + "\n" + reply
            }
            if (handoff) ownerNote("🙋 আপনার উত্তর দরকার: ${who}", "গ্রাহক: ${text}\nআমার উত্তর: ${reply}")

            val pid = j.optString("send_photo", "")
            if (pid.isNotBlank()) {
                val prod = Biz.find(shop.optJSONArray("products"), pid)
                val img = prod?.optString("img") ?: ""
                if (img.isNotBlank() && cfg.getBoolean("bizphoto", false) && cfg.getBoolean("running", false) && AccessSvc.inst != null) {
                    startService(Intent(this, AssistantService::class.java).setAction("SEND_PHOTO")
                        .putExtra("path", File(Biz.imgDir(this), img).absolutePath).putExtra("app", appName).putExtra("who", who))
                    Biz.log(this, "ছবি পাঠানোর কাজ শুরু: ${who}")
                } else ownerNote("📷 ছবি চাইছে: ${who}", "পণ্য: ${prod?.optString("name") ?: pid}। আপনি ছবি পাঠিয়ে দিন।")
            }

            if (mode == "auto") {
                if (send(this, act, reply)) {
                    botText[key] = reply
                    sentLog.getOrPut(key) { ArrayList() }.add(System.currentTimeMillis())
                    Biz.addChat(this, key, "model", reply)
                    Biz.log(this, "উত্তর: ${who}: ${reply.take(50)}")
                    if (order != null) {
                        Biz.addOrder(this, shop.optString("id"), shop.optString("name"), appName, who, order)
                        Biz.setRound(this, key, 0)
                        ownerNote("🛒 নতুন অর্ডার: ${who}", "মোট ${Biz.fmt(order.optDouble("total"))} টাকা\n${order.optJSONArray("items")}\nফোন: ${order.optString("phone")}\nঠিকানা: ${order.optString("address")}")
                    }
                } else Biz.log(this, "পাঠানো যায়নি (নোটিফিকেশন বদলে গেছে): ${who}")
            } else {
                val id = nid++
                pending[id] = Pending(act, reply, who, order, shop.optString("id"), shop.optString("name"), appName)
                val sendPi = PendingIntent.getBroadcast(this, id, Intent(this, BizReceiver::class.java).setAction("SEND").putExtra("id", id),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val dropPi = PendingIntent.getBroadcast(this, id + 5000, Intent(this, BizReceiver::class.java).setAction("DROP").putExtra("id", id),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val nt = Notification.Builder(this, "biz").setSmallIcon(R.drawable.ic_store)
                    .setContentTitle("${who}: ${text.take(60)}").setContentText("প্রস্তাবিত উত্তর: ${reply.take(80)}")
                    .setStyle(Notification.BigTextStyle().bigText("গ্রাহক: ${text}\n\nপ্রস্তাবিত উত্তর:\n${reply}" + (if (order != null) "\n\n(পাঠালে অর্ডার নথিভুক্ত হবে)" else "")))
                    .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_play), "পাঠাও", sendPi).build())
                    .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stop), "বাতিল", dropPi).build())
                    .setAutoCancel(true).build()
                getSystemService(NotificationManager::class.java).notify(id, nt)
                Biz.addChat(this, key, "model", reply)
                Biz.log(this, "খসড়া উত্তর তৈরি: ${who}")
            }
        } catch (e: Exception) {
            Biz.log(this, "⚠️ ${who}: ${e.message?.take(80)}")
        }
    }
}
