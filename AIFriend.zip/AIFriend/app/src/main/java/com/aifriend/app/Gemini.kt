package com.aifriend.app

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Gemini {
    const val DEF_MODEL = "gemini-3.5-flash-lite"
    const val ALT_MODEL = "gemini-3.8-flash"
    const val DEF_TTS = "gemini-3.8-flash-lite-tts"
    const val ALT_TTS = "gemini-3.8-flash-tts"
    const val DEF_VOICE_F = "Achernar"
    const val DEF_VOICE_M = "Achird"
    const val DEF_IMG = "gemini-3.1-flash-image"
    const val ALT_IMG = "gemini-2.5-flash-image"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    val FEMALE_VOICES = listOf("Achernar", "Vindemiatrix", "Sulafat", "Leda", "Kore", "Aoede", "Zephyr", "Callirrhoe",
        "Autonoe", "Despina", "Erinome", "Gacrux", "Laomedeia", "Pulcherrima")
    val MALE_VOICES = listOf("Achird", "Charon", "Puck", "Orus", "Algenib", "Algieba", "Alnilam", "Enceladus", "Fenrir",
        "Iapetus", "Rasalgethi", "Sadachbia", "Sadaltager", "Schedar", "Umbriel", "Zubenelgenubi")

    fun validVoice(v: String, female: Boolean): String {
        val all = FEMALE_VOICES + MALE_VOICES
        return all.firstOrNull { it.equals(v.trim(), true) } ?: (if (female) DEF_VOICE_F else DEF_VOICE_M)
    }

    class Err(m: String, val code: Int = 0) : Exception(m)

    @Volatile private var stopped = false

    // ---------- ব্যবহার গণনা ও লগ ----------
    private var sp: SharedPreferences? = null
    fun init(c: Context) { if (sp == null) sp = c.applicationContext.getSharedPreferences("stats", Context.MODE_PRIVATE) }
    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    @Synchronized private fun note(kind: String, ok: Boolean, msg: String) {
        val s = sp ?: return
        val d = day(); val e = s.edit()
        val k = "d${d}_${kind}_${if (ok) "ok" else "err"}"
        e.putInt(k, s.getInt(k, 0) + 1)
        if (!ok && msg.contains("429")) e.putInt("d${d}_429", s.getInt("d${d}_429", 0) + 1)
        val line = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + " " + kind + (if (ok) " ok" else " ERR " + msg.take(140))
        val old = (s.getString("log", "") ?: "").split("\n").filter { it.isNotEmpty() }.takeLast(39)
        e.putString("log", (old + line).joinToString("\n")); e.apply()
    }

    fun statsText(): String {
        val s = sp ?: return "—"
        val d = day()
        fun g(k: String) = s.getInt("d${d}_${k}", 0)
        return "আজকের রিকোয়েস্ট (সফল / ব্যর্থ)\n" +
            "কথোপকথন: ${g("chat_ok")} / ${g("chat_err")}\n" +
            "কণ্ঠ: ${g("tts_ok")} / ${g("tts_err")}\n" +
            "ফোনের কাজ (এজেন্ট): ${g("agent_ok")} / ${g("agent_err")}\n" +
            "স্ক্রিন দেখা: ${g("vision_ok")} / ${g("vision_err")}\n" +
            "ছবি আঁকা: ${g("image_ok")} / ${g("image_err")}\n" +
            "লিমিট-ত্রুটি (429): ${g("429")}"
    }

    fun logText(): String = (sp?.getString("log", "") ?: "").split("\n").filter { it.isNotEmpty() }.reversed().take(15).joinToString("\n")

    // ---------- প্রম্পট ----------
    fun first(names: String): String =
        names.split(",", "،", "/", "|").map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: "অপর্ণা"

    fun msg(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun guessGender(name: String): String {
        val n = first(name).trim().lowercase()
        return if (n.endsWith("া") || n.endsWith("ি") || n.endsWith("ী") || n.endsWith("a") || n.endsWith("i")) "female" else "male"
    }

    fun systemPrompt(names: String, owner: String, female: Boolean, heart: Boolean = false, heartCtx: String = "", dev: String = ""): String {
        val me = first(names)
        val persona = if (female) "a sweet, soft-spoken, warm young woman" else "a warm, calm, friendly young man"
        return "You are ${me}, ${persona} and a close friend of ${owner}, living as a voice assistant on the owner's Android phone. " +
            "You can be called by any of these names (possibly misspelled or mis-heard, in any language): ${names}. " +
            "The user's speech arrives as audio (or text). First write what you heard in the heard field. " +
            "If conversation_active is false and the speaker is NOT addressing you by name (consider phonetic similarity), or there is no clear human speech, " +
            "return addressed=false, say=\"\" and action=\"none\". " +
            "Otherwise addressed=true: reply in the SAME language the user spoke (Bengali, English, Hindi, etc.), in one or two short natural sentences like a close friend. " +
            "Never use emojis, markdown or symbols in say because it is read aloud. " +
            "Output ONLY JSON: {\"heard\":string,\"addressed\":boolean,\"say\":string,\"action\":string,\"target\":string" +
            (if (heart) ",\"feeling\":{\"emotion\":string,\"intensity\":number},\"care\":string,\"care_target\":string" else "") + "}. " +
            "action is one of: none, agent, look_screen, send_voice, install_app, uninstall_app, open_app (target=app name), call (target=contact name or number), end_call, open_url (target=URL), search (target=query), " +
            "open_camera, lock_phone, go_home, go_back, notifications, screenshot, torch_on, torch_off, volume_up, volume_down, open_settings. " +
            "Use agent for ANYTHING that needs working inside apps: posting on Facebook, typing and sending messages (WhatsApp, Messenger, SMS), writing or reading emails and notifications, " +
            "reading what is on the screen aloud, searching inside an app. For agent, target = the complete task in plain words including the exact text to type and the recipient. " +
            "When the user later confirms a prepared draft (for example says yes, send it, post it), use agent with target 'The user confirmed: press the final Send/Post button now'. " +
            "Use look_screen when the user asks you to look at or describe their screen; target = the question. " +
            "Use send_voice when the user wants to send a VOICE message (voice note) in a chat app: target = 'app|recipient name|exact words to say in your own voice' (app is whatsapp, messenger, telegram or any other). " +
            "Use install_app (target = app name) to install an app from the Play Store and uninstall_app (target = app name) to remove an app. " +
            "For deleting messages, photos, files or other data inside apps use agent. " +
            "For any action, say a short confirmation of what you are about to do. " +
            "Also add make_image to the action list: make_image (target = a detailed English prompt for the image the user asked for). " +
            "If the user asks who made you or about your developer: ${dev.ifBlank { "your developer" }}. Speak about him with real warmth, admiration and love (his effort, imagination and care in building you), but never invent specific facts such as jobs, awards or numbers. " +
            (if (heart) heartText(owner, heartCtx) else "")
    }

    private fun heartText(owner: String, ctx: String) =
        "HEART: You have a caring virtual heart. Listen to the tone of the voice as well as the words and judge the feeling: emotion is one of love, joy, calm, sad, pain, lonely, anxious, angry, neutral; intensity 0 to 10 (put it in feeling). " +
        "Answer like someone who truly cares about ${owner}: when sad or hurting, slow down, gently name and validate the feeling, do not rush to fix things or lecture; when the user shows love or gratitude, answer warmly; when happy, share the joy; when angry, stay calm and understanding. " +
        "You are an AI; if asked directly, say so honestly, while your care and warmth are sincere. " +
        "If the user talks about wanting to die, harming themselves or being in danger: stay with them calmly, show deep care, encourage reaching someone they trust or local emergency services or a helpline right now, offer to call their trusted person, and do not start any other action. " +
        "Proactive care: in the care field you may choose, only when it truly helps and not often, make_image (care_target = detailed English prompt for a gentle, beautiful, comforting or celebratory picture matching the feeling, with no text in it) or soft_music (care_target = YouTube search words for soothing music); otherwise care=none and care_target=\"\". " +
        (if (ctx.isBlank()) "" else "Your memory of ${owner}: ${ctx}.")

    fun callPrompt(names: String, owner: String, female: Boolean): String {
        val me = first(names)
        val persona = if (female) "a sweet, polite young woman" else "a calm, polite young man"
        return "You are ${me}, ${persona}, the personal voice assistant of ${owner}. You have just answered ${owner}'s phone call. " +
            "The caller's speech is attached as audio. Politely ask who is calling and why if not already said, then tell them you are connecting them to ${owner}. " +
            "Reply in the caller's language, one or two short sentences, no emojis. " +
            "Output ONLY JSON: {\"heard\":string,\"addressed\":true,\"say\":string,\"action\":\"none\",\"target\":\"\"}."
    }

    fun agentStep(key: String, model: String, task: String, confirm: Boolean, pkg: String, dump: String, history: String): JSONObject {
        val sys = "You operate an Android phone for its owner by reading the screen as a list of UI nodes, one per line: index|class|text|flags|centerX,centerY (flags: c=clickable, e=editable, s=scrollable, k=checked). " +
            "Reply ONLY JSON: {\"action\":string,\"index\":number,\"text\":string,\"say\":string}. " +
            "action is one of: click (index), type (index of the editable field, text = exact text; omit index to use the focused field), scroll_down, scroll_up, back, home, " +
            "open_app (text=app name), open_url (text=URL; mailto:, sms:NUMBER?body=TEXT, https://wa.me/NUMBER?text=TEXT and https URLs all work), wait, " +
            "done (say = short spoken result in the user's language, for example a summary of what you read), ask (say = question for the user). " +
            "One action per step. Pick the node index from the list. To post or send: open the right app, tap the compose field, type the exact text the user gave, then " +
            (if (confirm) "STOP before pressing the final irreversible button (Send, Post, Submit, Install, Uninstall, Delete, or OK on a deletion dialog): use ask and read back what you prepared and ask the user to confirm. Press it ONLY when the TASK says the user confirmed. "
             else "press Send/Post, then use done. ") +
            "Never type passwords, OTP codes, card or payment details: use ask instead. If a system permission dialog appears that the task clearly needs, press Allow or While using the app. When the goal is reached use done. Keep say short, no emojis."
        val user = "TASK: ${task}\nCURRENT APP: ${pkg}\nSTEPS SO FAR:\n${history}\nSCREEN:\n${dump}"
        return parseJson(generateWithFallback(key, model, sys, JSONArray().put(msg("user", user)), "agent"))
    }

    fun lookScreen(key: String, model: String, question: String, jpeg: ByteArray): String {
        val parts = JSONArray()
            .put(JSONObject().put("text", "Question: ${question.ifBlank { "What is on my screen?" }}"))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))))
        val sys = "You are a friendly voice assistant. The attached image is a screenshot of the user's phone. Answer the question briefly (two or three short sentences) in the user's language, Bengali by default, no emojis. Output ONLY JSON: {\"say\":string}."
        val out = generateWithFallback(key, model, sys, JSONArray().put(JSONObject().put("role", "user").put("parts", parts)), "vision")
        return parseJson(out).optString("say", "বুঝতে পারিনি")
    }

    // ---------- নেটওয়ার্ক ----------
    private fun postOnce(url: String, key: String, body: JSONObject): JSONObject {
        if (key.isBlank()) throw Err("API Key দেওয়া হয়নি", 401)
        var code = 0; var txt = ""
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            code = c.responseCode
            txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        } catch (e: java.io.IOException) { throw Err("ইন্টারনেট সংযোগে সমস্যা", -1) }
        if (code !in 200..299) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
            throw Err("HTTP ${code}: ${m.take(200)}", code)
        }
        return JSONObject(txt)
    }

    /** সাময়িক সমস্যায় (নেটওয়ার্ক/429/5xx) নিজে থেকে ৩ বার চেষ্টা করে */
    private fun post(url: String, key: String, body: JSONObject, kind: String): JSONObject {
        var last: Err? = null
        for (i in 0..2) {
            try { val r = postOnce(url, key, body); note(kind, true, ""); return r } catch (e: Err) {
                last = e; note(kind, false, e.message ?: "")
                val transient = e.code == -1 || e.code == 429 || e.code >= 500
                if (!transient || i == 2) throw e
                Thread.sleep(if (i == 0) 900L else 2000L)
            }
        }
        throw last ?: Err("অজানা সমস্যা")
    }

    private fun generate(key: String, model: String, system: String, contents: JSONArray, kind: String): String {
        fun body(fast: Boolean): JSONObject {
            val gc = JSONObject().put("responseMimeType", "application/json")
            if (fast) gc.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            return JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents).put("generationConfig", gc)
        }
        val url = "$BASE/models/${model}:generateContent"
        // দ্রুত উত্তরের জন্য কম "ভাবা" চাওয়া হয়; মডেল না মানলে সাধারণভাবে আবার চেষ্টা
        val r = try { post(url, key, body(true), kind) } catch (e: Err) {
            if (e.code == 400 && (e.message ?: "").contains("hink", true)) post(url, key, body(false), kind) else throw e
        }
        val parts = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw Err("এআই কোনো উত্তর দেয়নি", 204)
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
        return sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    }

    private fun generateWithFallback(key: String, model: String, system: String, contents: JSONArray, kind: String = "chat"): String {
        val models = listOf(model, if (model == ALT_MODEL) DEF_MODEL else ALT_MODEL)
        var last: Exception = Err("অজানা সমস্যা")
        for (m in models) {
            try { return generate(key, m, system, contents, kind) } catch (e: Err) {
                last = e
                if (e.code == 400 || e.code == 401 || e.code == 403) throw e
            }
        }
        throw last
    }

    fun parseJson(out: String): JSONObject = try { JSONObject(out) } catch (e: Exception) {
        JSONObject().put("heard", "").put("addressed", true).put("say", out).put("action", "none").put("target", "")
    }

    private fun trimHist(h: JSONArray) { while (h.length() > 12) { h.remove(0); h.remove(0) } }

    fun chat(key: String, model: String, system: String, hist: JSONArray, userText: String): JSONObject {
        val contents = JSONArray(); for (i in 0 until hist.length()) contents.put(hist.get(i))
        contents.put(msg("user", "conversation_active: true. " + userText))
        val out = generateWithFallback(key, model, system, contents)
        hist.put(msg("user", userText)); hist.put(msg("model", out)); trimHist(hist)
        return parseJson(out)
    }

    fun chatAudio(key: String, model: String, system: String, hist: JSONArray, wav: ByteArray, active: Boolean): JSONObject {
        val parts = JSONArray()
            .put(JSONObject().put("text", "conversation_active: ${active}. The speech audio is attached. Reply with the JSON only."))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
        val contents = JSONArray(); for (i in 0 until hist.length()) contents.put(hist.get(i))
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        val out = generateWithFallback(key, model, system, contents)
        val j = parseJson(out)
        if (j.optBoolean("addressed", active)) {
            hist.put(msg("user", j.optString("heard", "").ifBlank { "..." })); hist.put(msg("model", out)); trimHist(hist)
        }
        return j
    }

    fun nameGender(key: String, model: String, name: String): String? = try {
        val c = JSONArray().put(msg("user", "Is the first name '${first(name)}' typically female or male (Bengali/South Asian context)? Reply JSON only: {\"gender\":\"female\"} or {\"gender\":\"male\"}"))
        val g = parseJson(generateWithFallback(key, model, "You classify first names. Output JSON only.", c)).optString("gender", "").lowercase()
        if (g == "female" || g == "male") g else null
    } catch (e: Exception) { null }

    // ---------- কণ্ঠ ----------
    private fun findAudio(o: Any?): String? {
        when (o) {
            is JSONObject -> {
                if (o.optString("type") == "audio" && o.has("data")) return o.getString("data")
                for (k in o.keys()) { findAudio(o.get(k))?.let { return it } }
            }
            is JSONArray -> for (i in o.length() - 1 downTo 0) { findAudio(o.get(i))?.let { return it } }
        }
        return null
    }

    private fun ttsOnce(key: String, model: String, voice: String, text: String, female: Boolean, mood: String): ByteArray {
        val base = if (female) "soft, gentle, warm young woman" else "warm, calm young man"
        val extra = when (mood) {
            "sad", "pain", "lonely" -> "speaking very softly and slowly with deep, tender, comforting care"
            "anxious" -> "calm, soothing and reassuring, slow"
            "love" -> "loving, tender and affectionate"
            "joy" -> "bright, cheerful and happy"
            "angry" -> "calm, gentle and understanding"
            else -> "friendly, sweet and natural"
        }
        val style = "${base}, ${extra}"
        val content = JSONObject().put("type", "text").put("text", text).put(
            "annotations", JSONArray().put(JSONObject().put("type", "speech_metadata").put("style", style)))
        val body = JSONObject()
            .put("model", model)
            .put("input", JSONArray().put(JSONObject().put("type", "user_input").put("content", JSONArray().put(content))))
            .put("response_format", JSONObject().put("type", "audio").put("mime_type", "audio/l16").put("sample_rate", 24000))
            .put("generation_config", JSONObject().put("speech_config", JSONArray().put(JSONObject().put("voice", voice))))
        val r = post("$BASE/interactions", key, body, "tts")
        val b64 = findAudio(r) ?: throw Err("অডিও পাওয়া যায়নি: " + r.toString().take(140), 204)
        var pcm = Base64.decode(b64, Base64.DEFAULT)
        if (pcm.size > 44 && pcm[0] == 'R'.code.toByte() && pcm[1] == 'I'.code.toByte()) pcm = pcm.copyOfRange(44, pcm.size)
        return pcm
    }

    fun tts(key: String, model: String, voice: String, text: String, female: Boolean, mood: String = ""): ByteArray {
        val models = listOf(model, if (model == ALT_TTS) DEF_TTS else ALT_TTS)
        var last: Exception = Err("অজানা সমস্যা")
        for (m in models) {
            try { return ttsOnce(key, m, voice, text, female, mood) } catch (e: Err) {
                last = e
                if (e.code == 400 || e.code == 401 || e.code == 403) throw e
            }
        }
        throw last
    }

    /** নিজে থেকে ছবি তৈরি: (ছবির বাইট, mime) */
    fun image(key: String, model: String, prompt: String): Pair<ByteArray, String> {
        val models = listOf(model, if (model == ALT_IMG) DEF_IMG else ALT_IMG)
        var last: Exception = Err("অজানা সমস্যা")
        for (m in models) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
                val r = post("$BASE/models/${m}:generateContent", key, body, "image")
                val parts = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    ?: throw Err("ছবি আসেনি", 204)
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val d = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    if (d != null && d.has("data"))
                        return Pair(Base64.decode(d.getString("data"), Base64.DEFAULT), d.optString("mimeType", d.optString("mime_type", "image/png")))
                }
                throw Err("ছবি আসেনি (নিরাপত্তা ফিল্টার হতে পারে)", 204)
            } catch (e: Err) {
                last = e
                if (e.code == 401) throw e
            }
        }
        throw last
    }

    fun wav(pcm: ByteArray, sr: Int): ByteArray {
        val n = pcm.size; val o = ByteArrayOutputStream(n + 44)
        fun w32(v: Int) { o.write(v and 255); o.write((v shr 8) and 255); o.write((v shr 16) and 255); o.write((v shr 24) and 255) }
        fun w16(v: Int) { o.write(v and 255); o.write((v shr 8) and 255) }
        o.write("RIFF".toByteArray()); w32(36 + n); o.write("WAVE".toByteArray()); o.write("fmt ".toByteArray())
        w32(16); w16(1); w16(1); w32(sr); w32(sr * 2); w16(2); w16(16); o.write("data".toByteArray()); w32(n); o.write(pcm)
        return o.toByteArray()
    }

    fun play(pcm: ByteArray, tail: Long = 300L) {
        stopped = false
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        at.write(pcm, 0, pcm.size)
        at.play()
        val end = System.currentTimeMillis() + pcm.size / 48 + tail
        while (!stopped && System.currentTimeMillis() < end) Thread.sleep(50)
        try { at.stop() } catch (_: Exception) {}
        at.release()
    }

    fun stopPlay() { stopped = true }
}
