package com.aifriend.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    const val DEF_MODEL = "gemini-3.5-flash-lite"
    const val ALT_MODEL = "gemini-3.8-flash"
    const val DEF_TTS = "gemini-3.8-flash-lite-tts"
    const val ALT_TTS = "gemini-3.8-flash-tts"
    const val DEF_VOICE_F = "Achernar"
    const val DEF_VOICE_M = "Achird"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    class Err(m: String, val code: Int = 0) : Exception(m)

    @Volatile private var stopped = false

    fun first(names: String): String =
        names.split(",", "،", "/", "|").map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: "মায়া"

    fun msg(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun guessGender(name: String): String {
        val n = first(name).trim().lowercase()
        return if (n.endsWith("া") || n.endsWith("ি") || n.endsWith("ী") || n.endsWith("a") || n.endsWith("i")) "female" else "male"
    }

    fun systemPrompt(names: String, owner: String, female: Boolean): String {
        val me = first(names)
        val persona = if (female) "a sweet, soft-spoken, warm young woman" else "a warm, calm, friendly young man"
        return "You are ${me}, ${persona} and a close friend of ${owner}, living as a voice assistant on the owner's Android phone. " +
            "You can be called by any of these names (possibly misspelled or mis-heard, in any language): ${names}. " +
            "The user's speech arrives as audio (or text). First write what you heard in the heard field. " +
            "If conversation_active is false and the speaker is NOT addressing you by name (consider phonetic similarity), or there is no clear human speech, " +
            "return addressed=false, say=\"\" and action=\"none\". " +
            "Otherwise addressed=true: reply in the SAME language the user spoke (Bengali, English, Hindi, etc.), in one or two short natural sentences like a close friend. " +
            "Never use emojis, markdown or symbols in say because it is read aloud. " +
            "Output ONLY JSON: {\"heard\":string,\"addressed\":boolean,\"say\":string,\"action\":string,\"target\":string}. " +
            "action is one of: none, open_app (target=app name like Facebook, YouTube, Gallery), call (target=contact name or number), end_call, " +
            "open_url (target=URL), search (target=query), open_camera, lock_phone, go_home, go_back, notifications, screenshot, torch_on, torch_off, " +
            "volume_up, volume_down, open_settings. When the user asks for such a thing, set the action and say a short confirmation."
    }

    fun callPrompt(names: String, owner: String, female: Boolean): String {
        val me = first(names)
        val persona = if (female) "a sweet, polite young woman" else "a calm, polite young man"
        return "You are ${me}, ${persona}, the personal voice assistant of ${owner}. You have just answered ${owner}'s phone call. " +
            "The caller's speech is attached as audio. Politely ask who is calling and why if not already said, then tell them you are connecting them to ${owner}. " +
            "Reply in the caller's language, one or two short sentences, no emojis. " +
            "Output ONLY JSON: {\"heard\":string,\"addressed\":true,\"say\":string,\"action\":\"none\",\"target\":\"\"}."
    }

    private fun postOnce(url: String, key: String, body: JSONObject): JSONObject {
        if (key.isBlank()) throw Err("API Key দেওয়া হয়নি", 401)
        var code = 0; var txt = ""
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            code = c.responseCode
            txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        } catch (e: java.io.IOException) { throw Err("ইন্টারনেট সংযোগে সমস্যা", -1) }
        if (code !in 200..299) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
            throw Err("HTTP ${code}: ${m.take(200)}", code)
        }
        return JSONObject(txt)
    }

    /** সাময়িক সমস্যায় (নেটওয়ার্ক/429/5xx) নিজে থেকে ৩ বার চেষ্টা করে */
    private fun post(url: String, key: String, body: JSONObject): JSONObject {
        var last: Err? = null
        for (i in 0..2) {
            try { return postOnce(url, key, body) } catch (e: Err) {
                last = e
                val transient = e.code == -1 || e.code == 429 || e.code >= 500
                if (!transient || i == 2) throw e
                Thread.sleep(if (i == 0) 900L else 2000L)
            }
        }
        throw last ?: Err("অজানা সমস্যা")
    }

    private fun generate(key: String, model: String, system: String, contents: JSONArray): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val r = post("$BASE/models/${model}:generateContent", key, body)
        val parts = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw Err("এআই কোনো উত্তর দেয়নি", 204)
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
        return sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    }

    /** প্রধান মডেল ফেল করলে বিকল্প মডেলে চেষ্টা করে */
    private fun generateWithFallback(key: String, model: String, system: String, contents: JSONArray): String {
        val models = listOf(model, if (model == ALT_MODEL) DEF_MODEL else ALT_MODEL)
        var last: Exception = Err("অজানা সমস্যা")
        for (m in models) {
            try { return generate(key, m, system, contents) } catch (e: Err) {
                last = e
                if (e.code == 400 || e.code == 401 || e.code == 403) throw e
            }
        }
        throw last
    }

    fun parseJson(out: String): JSONObject = try { JSONObject(out) } catch (e: Exception) {
        JSONObject().put("heard", "").put("addressed", true).put("say", out).put("action", "none").put("target", "")
    }

    private fun trimHist(h: JSONArray) { while (h.length() > 12) { h.remove(0); h.remove(0) } }

    /** টেক্সট চ্যাট (টেস্টের জন্য) */
    fun chat(key: String, model: String, system: String, hist: JSONArray, userText: String): JSONObject {
        val contents = JSONArray(); for (i in 0 until hist.length()) contents.put(hist.get(i))
        contents.put(msg("user", "conversation_active: true. " + userText))
        val out = generateWithFallback(key, model, system, contents)
        hist.put(msg("user", userText)); hist.put(msg("model", out)); trimHist(hist)
        return parseJson(out)
    }

    /** কণ্ঠ (অডিও) পাঠিয়ে সরাসরি শোনা + উত্তর: {heard, addressed, say, action, target} */
    fun chatAudio(key: String, model: String, system: String, hist: JSONArray, wav: ByteArray, active: Boolean): JSONObject {
        val parts = JSONArray()
            .put(JSONObject().put("text", "conversation_active: ${active}. The speech audio is attached. Reply with the JSON only."))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
        val contents = JSONArray(); for (i in 0 until hist.length()) contents.put(hist.get(i))
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        val out = generateWithFallback(key, model, system, contents)
        val j = parseJson(out)
        if (j.optBoolean("addressed", active)) {
            hist.put(msg("user", j.optString("heard", "").ifBlank { "..." })); hist.put(msg("model", out)); trimHist(hist)
        }
        return j
    }

    fun nameGender(key: String, model: String, name: String): String? = try {
        val c = JSONArray().put(msg("user", "Is the first name '${first(name)}' typically female or male (Bengali/South Asian context)? Reply JSON only: {\"gender\":\"female\"} or {\"gender\":\"male\"}"))
        val g = parseJson(generateWithFallback(key, model, "You classify first names. Output JSON only.", c)).optString("gender", "").lowercase()
        if (g == "female" || g == "male") g else null
    } catch (e: Exception) { null }

    private fun findAudio(o: Any?): String? {
        when (o) {
            is JSONObject -> {
                if (o.optString("type") == "audio" && o.has("data")) return o.getString("data")
                for (k in o.keys()) { findAudio(o.get(k))?.let { return it } }
            }
            is JSONArray -> for (i in o.length() - 1 downTo 0) { findAudio(o.get(i))?.let { return it } }
        }
        return null
    }

    private fun ttsOnce(key: String, model: String, voice: String, text: String, female: Boolean): ByteArray {
        val style = if (female) "soft, gentle, warm and friendly young woman, calm and sweet" else "warm, calm and friendly young man"
        val content = JSONObject().put("type", "text").put("text", text).put(
            "annotations", JSONArray().put(JSONObject().put("type", "speech_metadata").put("style", style)))
        val body = JSONObject()
            .put("model", model)
            .put("input", JSONArray().put(JSONObject().put("type", "user_input").put("content", JSONArray().put(content))))
            .put("response_format", JSONObject().put("type", "audio").put("mime_type", "audio/l16").put("sample_rate", 24000))
            .put("generation_config", JSONObject().put("speech_config", JSONArray().put(JSONObject().put("voice", voice))))
        val r = post("$BASE/interactions", key, body)
        val b64 = findAudio(r) ?: throw Err("অডিও পাওয়া যায়নি: " + r.toString().take(140), 204)
        var pcm = Base64.decode(b64, Base64.DEFAULT)
        if (pcm.size > 44 && pcm[0] == 'R'.code.toByte() && pcm[1] == 'I'.code.toByte()) pcm = pcm.copyOfRange(44, pcm.size)
        return pcm
    }

    /** Gemini TTS: 24kHz 16-bit mono PCM (প্রধান মডেল ফেল করলে বিকল্প মডেল) */
    fun tts(key: String, model: String, voice: String, text: String, female: Boolean): ByteArray {
        val models = listOf(model, if (model == ALT_TTS) DEF_TTS else ALT_TTS)
        var last: Exception = Err("অজানা সমস্যা")
        for (m in models) {
            try { return ttsOnce(key, m, voice, text, female) } catch (e: Err) {
                last = e
                if (e.code == 400 || e.code == 401 || e.code == 403) throw e
            }
        }
        throw last
    }

    fun wav(pcm: ByteArray, sr: Int): ByteArray {
        val n = pcm.size; val o = ByteArrayOutputStream(n + 44)
        fun w32(v: Int) { o.write(v and 255); o.write((v shr 8) and 255); o.write((v shr 16) and 255); o.write((v shr 24) and 255) }
        fun w16(v: Int) { o.write(v and 255); o.write((v shr 8) and 255) }
        o.write("RIFF".toByteArray()); w32(36 + n); o.write("WAVE".toByteArray()); o.write("fmt ".toByteArray())
        w32(16); w16(1); w16(1); w32(sr); w32(sr * 2); w16(2); w16(16); o.write("data".toByteArray()); w32(n); o.write(pcm)
        return o.toByteArray()
    }

    /** PCM বাজায় (শেষ না হওয়া পর্যন্ত অপেক্ষা করে) */
    fun play(pcm: ByteArray) {
        stopped = false
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        at.write(pcm, 0, pcm.size)
        at.play()
        val end = System.currentTimeMillis() + pcm.size / 48 + 300
        while (!stopped && System.currentTimeMillis() < end) Thread.sleep(50)
        try { at.stop() } catch (_: Exception) {}
        at.release()
    }

    fun stopPlay() { stopped = true }
}
