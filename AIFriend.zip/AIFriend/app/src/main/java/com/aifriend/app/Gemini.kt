package com.aifriend.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    const val DEF_MODEL = "gemini-3.5-flash-lite"
    const val DEF_TTS = "gemini-3.8-flash-lite-tts"
    const val DEF_VOICE = "Achernar"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    class Err(m: String) : Exception(m)

    @Volatile private var stopped = false

    fun first(names: String): String =
        names.split(",", "،", "/", "|").map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: "মায়া"

    fun msg(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun systemPrompt(name: String) =
        "You are ${name}, a sweet, soft-spoken, warm young woman and a close friend, living as a voice assistant on the user's Android phone. " +
        "Speak in natural, simple, friendly Bengali by default, in one or two short sentences, like chatting with a close friend. " +
        "If the user speaks another language, reply in that language. Never use emojis, markdown or symbols in the say field because it is read aloud. " +
        "Output ONLY JSON: {\"say\":string,\"action\":\"none|open_app|call|open_url\",\"target\":string}. " +
        "open_app target: facebook, youtube, whatsapp, chrome or a package name. call target: contact name or phone number. open_url target: a full URL."

    private fun post(url: String, key: String, body: JSONObject): JSONObject {
        if (key.isBlank()) throw Err("API Key দেওয়া হয়নি")
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
            throw Err("HTTP ${code}: ${m.take(220)}")
        }
        return JSONObject(txt)
    }

    /** টেক্সট চ্যাট: {say, action, target} ফেরত দেয় */
    fun chat(key: String, model: String, system: String, hist: JSONArray, userText: String): JSONObject {
        hist.put(msg("user", userText))
        try {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", hist)
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            val r = post("$BASE/models/${model}:generateContent", key, body)
            val parts = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw Err("এআই কোনো উত্তর দেয়নি (নিরাপত্তা ফিল্টার হতে পারে)")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
            }
            val out = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            hist.put(msg("model", out))
            while (hist.length() > 12) { hist.remove(0); hist.remove(0) }
            return try { JSONObject(out) } catch (e: Exception) {
                JSONObject().put("say", out).put("action", "none").put("target", "")
            }
        } catch (e: Exception) {
            if (hist.length() > 0) hist.remove(hist.length() - 1)
            throw e
        }
    }

    private fun findAudio(o: Any?): String? {
        when (o) {
            is JSONObject -> {
                if (o.optString("type") == "audio" && o.has("data")) return o.getString("data")
                for (k in o.keys()) { findAudio(o.get(k))?.let { return it } }
            }
            is JSONArray -> for (i in o.length() - 1 downTo 0) { findAudio(o.get(i))?.let { return it } }
        }
        return null
    }

    /** Gemini TTS (মেয়ের কণ্ঠ): 24kHz 16-bit mono PCM ফেরত দেয় */
    fun tts(key: String, model: String, voice: String, text: String): ByteArray {
        val content = JSONObject().put("type", "text").put("text", text).put(
            "annotations", JSONArray().put(
                JSONObject().put("type", "speech_metadata")
                    .put("style", "soft, gentle, warm and friendly young woman, calm and sweet")
            )
        )
        val body = JSONObject()
            .put("model", model)
            .put("input", JSONArray().put(JSONObject().put("type", "user_input").put("content", JSONArray().put(content))))
            .put("response_format", JSONObject().put("type", "audio").put("mime_type", "audio/l16").put("sample_rate", 24000))
            .put("generation_config", JSONObject().put("speech_config", JSONArray().put(JSONObject().put("voice", voice))))
        val r = post("$BASE/interactions", key, body)
        val b64 = findAudio(r) ?: throw Err("অডিও পাওয়া যায়নি: " + r.toString().take(160))
        var pcm = Base64.decode(b64, Base64.DEFAULT)
        if (pcm.size > 44 && pcm[0] == 'R'.code.toByte() && pcm[1] == 'I'.code.toByte()) pcm = pcm.copyOfRange(44, pcm.size)
        return pcm
    }

    /** PCM বাজায় (শেষ না হওয়া পর্যন্ত অপেক্ষা করে) */
    fun play(pcm: ByteArray) {
        stopped = false
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        at.write(pcm, 0, pcm.size)
        at.play()
        val end = System.currentTimeMillis() + pcm.size / 48 + 300
        while (!stopped && System.currentTimeMillis() < end) Thread.sleep(50)
        try { at.stop() } catch (_: Exception) {}
        at.release()
    }

    fun stopPlay() { stopped = true }
}
