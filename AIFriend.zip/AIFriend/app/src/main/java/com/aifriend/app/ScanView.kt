package com.aifriend.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** ফুল স্ক্রিন হ্যাকিং-লুক স্ক্যান: কোড-বৃষ্টি, ঘুরন্ত রাডার, প্রগ্রেস রিং, লাইভ লগ */
class ScanView(c: Context) : View(c) {
    var progress = 0
    private val lines = ArrayList<String>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random()
    private val glyphs = "01ABCDEF789<>/{}#%&".toCharArray()
    private var heads = FloatArray(0)
    private var speed = FloatArray(0)
    private var sweep = 0f
    private var t = 0f
    private var cw = 1f

    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { t = it.animatedValue as Float; sweep = (sweep + 4f) % 360f; invalidate() }
            start()
        }
    }

    fun addLine(s: String) { lines.add(s); while (lines.size > 8) lines.removeAt(0) }
    fun reset() { lines.clear(); progress = 0 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cw = resources.displayMetrics.density * 14f
        val n = (w / cw).toInt() + 1
        heads = FloatArray(n) { rnd.nextFloat() * h }
        speed = FloatArray(n) { 3f + rnd.nextFloat() * 7f }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF020A06.toInt())
        p.style = Paint.Style.FILL; p.typeface = Typeface.MONOSPACE; p.textSize = cw * 1.1f; p.textAlign = Paint.Align.LEFT
        for (i in heads.indices) {
            for (k in 0 until 12) {
                val y = heads[i] - k * cw * 1.2f
                if (y < 0 || y > height) continue
                val a = (255 * (1f - k / 12f) * 0.55f).toInt()
                p.color = (a shl 24) or (if (k == 0) 0xB8FFD0 else 0x00FF66)
                c.drawText(glyphs[rnd.nextInt(glyphs.size)].toString(), i * cw, y, p)
            }
            heads[i] += speed[i]
            if (heads[i] - 12 * cw * 1.2f > height) { heads[i] = 0f; speed[i] = 3f + rnd.nextFloat() * 7f }
        }

        val cx = width / 2f; val cy = height * 0.36f; val r = min(width, height) * 0.30f
        p.style = Paint.Style.FILL; p.color = 0xCC020A06.toInt(); c.drawCircle(cx, cy, r * 1.14f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0xAA00FF66.toInt()
        for (k in 1..4) c.drawCircle(cx, cy, r * k / 4f, p)
        c.drawLine(cx - r, cy, cx + r, cy, p); c.drawLine(cx, cy - r, cx, cy + r, p)

        c.save(); c.rotate(sweep, cx, cy)
        p.style = Paint.Style.FILL
        p.shader = SweepGradient(cx, cy, intArrayOf(0x0000FF66, 0x9900FF66.toInt()), floatArrayOf(0.75f, 1f))
        c.drawCircle(cx, cy, r, p); p.shader = null
        c.restore()

        for (k in 0 until 5) {
            val ang = Math.toRadians(k * 73.0 + 20).toFloat(); val rr = r * (0.3f + 0.13f * k)
            val al = (120 + 120 * sin(t * 6.283f + k)).toInt().coerceIn(0, 255)
            p.style = Paint.Style.FILL; p.color = (al shl 24) or 0xFF4444
            c.drawCircle(cx + rr * cos(ang), cy + rr * sin(ang), 6f, p)
        }

        p.style = Paint.Style.STROKE; p.strokeWidth = 10f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFF00FF66.toInt()
        c.drawArc(cx - r * 1.2f, cy - r * 1.2f, cx + r * 1.2f, cy + r * 1.2f, -90f, 360f * progress / 100f, false, p)

        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = r * 0.4f; p.color = 0xFF00FF66.toInt()
        c.drawText("${progress}%", cx, cy + r * 0.14f, p)
        p.textSize = 44f; p.color = 0xFFB8FFD0.toInt()
        c.drawText("ফোন স্ক্যান চলছে…", cx, cy + r * 1.55f, p)

        p.textAlign = Paint.Align.LEFT; p.typeface = Typeface.DEFAULT; p.textSize = 30f
        var y = height * 0.70f
        for ((idx, s) in lines.withIndex()) {
            val a = 90 + 165 * (idx + 1) / lines.size
            p.color = (a shl 24) or 0x00FF66
            c.drawText("> " + s.take(46), cw, y, p)
            y += 44f
        }
    }
}
