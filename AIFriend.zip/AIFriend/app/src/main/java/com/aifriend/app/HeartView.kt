package com.aifriend.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** স্পন্দিত হৃদয়: রং অনুভূতি অনুযায়ী, স্পন্দনের গতি অনুভূতির তীব্রতা অনুযায়ী */
class HeartView(c: Context) : View(c) {
    var emotion = "calm"
    var intensity = 3
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var phase = 0f
    private var last = 0L

    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000; repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                val now = System.nanoTime()
                val dt = if (last == 0L) 0f else (now - last) / 1e9f
                last = now
                phase = (phase + dt * (0.8f + intensity * 0.12f)) % 1f
                invalidate()
            }
            start()
        }
    }

    private fun bump(x: Float, a: Float, b: Float) = if (x in a..b) sin(Math.PI * (x - a) / (b - a)).toFloat() else 0f

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val s = min(width, height) * 0.30f
        val col = Heart.colorFor(emotion); val rgb = col and 0xFFFFFF
        val beat = max(bump(phase, 0f, 0.25f), 0.6f * bump(phase, 0.3f, 0.5f))
        val sc = 1f + 0.16f * beat
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, s * 2.2f, intArrayOf(rgb or (0x80 shl 24), rgb), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, s * (1.6f + 0.5f * beat), p)
        c.save(); c.scale(sc, sc, cx, cy)
        path.reset()
        path.moveTo(cx, cy + s * 0.95f)
        path.cubicTo(cx - s * 1.7f, cy - s * 0.1f, cx - s * 0.95f, cy - s * 1.3f, cx, cy - s * 0.45f)
        path.cubicTo(cx + s * 0.95f, cy - s * 1.3f, cx + s * 1.7f, cy - s * 0.1f, cx, cy + s * 0.95f)
        path.close()
        p.shader = RadialGradient(cx - s * 0.4f, cy - s * 0.5f, s * 2f, intArrayOf(0xFFFFFFFF.toInt(), col, 0xFF2A0A25.toInt()),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null
        c.restore()
    }
}
