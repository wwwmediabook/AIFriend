package com.aifriend.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** ফোন রিস্টার্ট হলে, আগে চালু থাকলে, সার্ভিস আবার চালু করে (বৈধ অটো-স্টার্ট, লুকানো নয়) */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != "android.intent.action.QUICKBOOT_POWERON") return
        val cfg = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!cfg.getBoolean("running", false)) return
        val svc = Intent(c, AssistantService::class.java)
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(svc) else c.startService(svc)
    }
}
