package com.aifriend.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** ফোন রিস্টার্ট হলে, আগে চালু ছিল ও অনুমতি দেওয়া থাকলে সহকারী আবার নিজে চালু হয় (সাধারণ রিলায়েবিলিটি ফিচার) */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val cfg = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!cfg.getBoolean("running", false)) return
        try { c.startForegroundService(Intent(c, AssistantService::class.java)) } catch (_: Exception) {}
    }
}
