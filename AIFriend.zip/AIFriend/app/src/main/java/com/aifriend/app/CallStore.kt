package com.aifriend.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** কলের কথাবার্তা (লেখা + কলারের অডিও) অ্যাপের ভেতরেই সংরক্ষণ */
object CallStore {
    private fun dir(c: Context) = File(c.filesDir, "calls").apply { mkdirs() }
    private fun idx(c: Context) = File(dir(c), "index.json")

    @Synchronized fun load(c: Context): JSONArray = try { JSONArray(idx(c).readText()) } catch (e: Exception) { JSONArray() }
    @Synchronized private fun save(c: Context, a: JSONArray) { idx(c).writeText(a.toString()) }

    @Synchronized fun begin(c: Context, who: String): String {
        val id = System.currentTimeMillis().toString()
        val a = load(c); a.put(JSONObject().put("id", id).put("who", who).put("lines", JSONArray())); save(c, a)
        return id
    }

    @Synchronized fun line(c: Context, id: String, from: String, text: String, audio: ByteArray? = null) {
        val a = load(c)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("id") == id) {
                var file = ""
                if (audio != null) { file = "${id}_${System.currentTimeMillis()}.wav"; File(dir(c), file).writeBytes(Gemini.wav(audio, 16000)) }
                o.getJSONArray("lines").put(JSONObject().put("t", System.currentTimeMillis()).put("from", from).put("text", text).put("audio", file))
                break
            }
        }
        save(c, a)
    }

    fun file(c: Context, name: String) = File(dir(c), name)
    @Synchronized fun clear(c: Context) { dir(c).listFiles()?.forEach { it.delete() } }
}
