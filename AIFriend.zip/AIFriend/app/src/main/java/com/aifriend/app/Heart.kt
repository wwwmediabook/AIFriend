package com.aifriend.app

import android.content.Context
import android.graphics.Color

/** ভার্চুয়াল হৃদয়: অনুভূতির স্মৃতি, সম্পর্কের গভীরতা, রং ও নাম */
object Heart {
    const val DEF_DEV = "মৃদুল (Medul), যিনি আমাকে তৈরি করেছেন"
    private fun sp(c: Context) = c.getSharedPreferences("heart", Context.MODE_PRIVATE)

    fun bond(c: Context) = sp(c).getInt("bond", 5)
    fun mood(c: Context) = sp(c).getString("mood", "calm") ?: "calm"
    fun intensity(c: Context) = sp(c).getInt("inten", 3)
    fun last(c: Context, k: String) = sp(c).getLong("t_${k}", 0L)
    fun stamp(c: Context, k: String) { sp(c).edit().putLong("t_${k}", System.currentTimeMillis()).apply() }

    fun record(c: Context, emotion: String, inten: Int) {
        val s = sp(c)
        val e = emotion.lowercase().trim().ifBlank { "neutral" }
        val i = inten.coerceIn(0, 10)
        val hist = (s.getString("hist", "") ?: "").split("\n").filter { it.isNotEmpty() }.takeLast(11)
        s.edit().putString("mood", e).putInt("inten", i).putInt("bond", minOf(100, s.getInt("bond", 5) + 1))
            .putString("hist", (hist + "${System.currentTimeMillis()}|${e}|${i}").joinToString("\n")).apply()
    }

    /** মডেলকে দেওয়ার জন্য ছোট স্মৃতি-সারাংশ */
    fun context(c: Context): String {
        return try {
            val s = sp(c); val now = System.currentTimeMillis()
            val items = (s.getString("hist", "") ?: "").split("\n").filter { it.isNotEmpty() }.takeLast(6).map {
                val p = it.split("|"); val m = (now - p[0].toLong()) / 60000
                "${p[1]}(${p[2]}) " + (if (m < 60) "${m} min ago" else "${m / 60} h ago")
            }
            val cfg = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val tn = cfg.getString("trusted", "") ?: ""
            "closeness ${bond(c)}/100; recent feelings you noticed: ${if (items.isEmpty()) "none yet" else items.joinToString(", ")}" +
                (if (tn.isNotBlank()) "; trusted person you may offer to call: ${tn}" else "")
        } catch (e: Exception) { "" }
    }

    fun colorFor(e: String): Int = Color.parseColor(when (e) {
        "love" -> "#FF4F81"; "joy" -> "#FFC93C"; "sad", "pain" -> "#4F8CFF"; "lonely" -> "#7E8BFF"
        "anxious" -> "#B28DFF"; "angry" -> "#FF7043"; "calm" -> "#4FD1C5"; else -> "#FF6F91" })

    fun labelBn(e: String) = when (e) {
        "love" -> "ভালোবাসা"; "joy" -> "আনন্দ"; "calm" -> "শান্ত"; "sad" -> "মন খারাপ"; "pain" -> "কষ্ট"
        "lonely" -> "একাকীত্ব"; "anxious" -> "দুশ্চিন্তা"; "angry" -> "রাগ"; else -> "স্বাভাবিক" }
}
