package com.aifriend.app

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.Manifest
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.*
import org.json.JSONArray
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class AssistantService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var orb: Orb
    private lateinit var am: AudioManager
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val h = Handler(Looper.getMainLooper())
    private val hist = JSONArray()
    private var awakeUntil = 0L
    private var userTorch = false
    private var lastApology = 0L
    private var after: (() -> Unit)? = null
    private var resolving = false
    private var orbLp: WindowManager.LayoutParams? = null
    private var orbAttached = false
    private var orbHidden = false
    private val ttsCache = object : LinkedHashMap<String, ByteArray>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, ByteArray>) = size > 10
    }

    @Volatile private var speaking = false
    @Volatile private var busy = false
    @Volatile private var alive = true
    @Volatile private var capRun = false
    @Volatile private var ignoreUntil = 0L

    private var inCall = false
    private var answeredByMe = false
    private var greeted = false
    private var callId: String? = null
    @Volatile private var callStage = 0
    private var callerLabel = "একজন"

    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private fun s(k: String, d: String) = cfg.getString(k, d) ?: d
    private fun names() = s("name", "অপর্ণা, aparna")
    private fun owner() = s("owner", "মৃদুল")
    private fun model() = s("model", Gemini.DEF_MODEL)

    /** প্রতিবার সেটিংস থেকে পড়া হয়, তাই বদলালেই সাথে সাথে কার্যকর */
    private fun isFemale(): Boolean = when (s("gender", "auto")) {
        "female" -> true
        "male" -> false
        else -> (cfg.getString("g_" + names(), null) ?: Gemini.guessGender(names())) == "female"
    }

    private fun resolveGender() {
        val n = names()
        if (s("gender", "auto") != "auto" || cfg.getString("g_" + n, null) != null || resolving) return
        resolving = true
        Thread {
            val g = Gemini.nameGender(s("key", ""), model(), n)
            if (g != null) cfg.edit().putString("g_" + n, g).apply()
            resolving = false
        }.start()
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "TOGGLE" -> setOrbHidden(!orbHidden)
            "MOOD" -> h.post { if (!busy && !speaking) checkMood(false) }
            "SEND_PHOTO" -> {
                val path = i.getStringExtra("path") ?: ""; val app = i.getStringExtra("app") ?: ""; val who = i.getStringExtra("who") ?: ""
                h.post { sendPhoto(path, app, who) }
            }
        }
        return START_STICKY
    }

    private fun st(state: Int, msg: String) {
        h.post { if (::orb.isInitialized) orb.state = state }
        cfg.edit().putString("status", msg).putInt("state", state).apply()
    }

    private val callRx = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val state = i.getStringExtra(TelephonyManager.EXTRA_STATE)
            val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            when (state) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    if (!cfg.getBoolean("callmode", false)) return
                    if (!inCall) onRing(num)
                    else if (callerLabel == "একজন" && !num.isNullOrEmpty()) callerLabel = lookupName(num) ?: num
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> if (inCall && answeredByMe && !greeted) onAnswered()
                TelephonyManager.EXTRA_STATE_IDLE -> if (inCall) onCallEnded()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Gemini.init(this)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ai", "AI Friend", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("call", "কল", NotificationManager.IMPORTANCE_HIGH))
        val toggle = PendingIntent.getService(this, 1, Intent(this, AssistantService::class.java).setAction("TOGGLE"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "ai").setContentTitle("AI Friend চালু আছে").setSmallIcon(R.drawable.ic_mic)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_mic), "দেখাও / লুকাও", toggle).build()).build()
        var ft = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (Build.VERSION.SDK_INT >= 30 && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) ft = ft or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ft) else startForeground(1, n)
        cfg.edit().putBoolean("running", true).apply()
        addOrb()
        val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(callRx, f, Context.RECEIVER_EXPORTED) else registerReceiver(callRx, f)
        tts = TextToSpeech(this) { code ->
            ttsReady = code == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale.forLanguageTag("bn-BD")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) {}
                    override fun onError(u: String?) { h.post { doneSpeaking() } }
                    override fun onDone(u: String?) { h.post { doneSpeaking() } }
                })
            }
        }
        resolveGender()
        h.postDelayed({ if (alive) speak("জি, আমি ${Gemini.first(names())}। ${owner()}, আমি চালু হয়েছি, ডাকলেই কথা বলব।") }, 1200L)
        startCapture()
        h.postDelayed(moodTick, 5 * 60_000L)
    }

    // ---------- ভাসমান অরব (আগের মতোই) ----------
    private fun addOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        orb = Orb(this)
        val sz = (160 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 15 || abs(e.rawY - sy) > 15) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(orb, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) wake()
            }
            true
        }
        orbLp = lp; wm.addView(orb, lp); orbAttached = true
        if (cfg.getBoolean("orbHidden", false)) setOrbHidden(true)
    }

    private fun wake() {
        awakeUntil = System.currentTimeMillis() + 60_000
        if (!speaking && !busy) speak("জি, বলো")
    }

    // ---------- নিঃশব্দ শোনা ----------
    private fun bytesOf(b: ShortArray, n: Int): ByteArray {
        val o = ByteArray(n * 2)
        for (i in 0 until n) { o[2 * i] = (b[i].toInt() and 0xFF).toByte(); o[2 * i + 1] = (b[i].toInt() shr 8).toByte() }
        return o
    }

    private fun idleMsg() = "শুনছি… নাম ধরে ডাকো (${Gemini.first(names())}) অথবা বলে ট্যাপ করো"

    private fun startCapture() {
        if (capRun) return
        capRun = true
        Thread {
            val sr = 16000; val frame = 320
            val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            var ar: AudioRecord? = null
            try {
                ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 16))
                if (ar.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("মাইক চালু হয়নি, পারমিশন দাও")
                ar.startRecording()
            } catch (e: Exception) { st(0, "❌ মাইক: ${e.message}"); capRun = false; return@Thread }
            st(1, idleMsg())
            val buf = ShortArray(frame)
            val utter = ByteArrayOutputStream()
            val pre = ArrayDeque<ByteArray>()
            var noise = 150.0; var inSpeech = false; var voiced = 0; var silent = 0; var total = 0
            while (capRun) {
                val n = ar.read(buf, 0, frame)
                if (n <= 0) { Thread.sleep(20); continue }
                if (busy || speaking || System.currentTimeMillis() < ignoreUntil || System.currentTimeMillis() < cfg.getLong("mute_until", 0L)) { inSpeech = false; voiced = 0; pre.clear(); continue }
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                val rms = sqrt(sum / n)
                val isSpeech = rms > maxOf(noise * 2.8, 350.0)
                if (!inSpeech) {
                    if (!isSpeech) noise = noise * 0.98 + rms * 0.02
                    pre.addLast(bytesOf(buf, n)); if (pre.size > 12) pre.removeFirst()
                    voiced = if (isSpeech) voiced + 1 else 0
                    if (voiced >= 4) { inSpeech = true; utter.reset(); pre.forEach { utter.write(it) }; pre.clear(); silent = 0; total = 0 }
                } else {
                    utter.write(bytesOf(buf, n)); total++
                    silent = if (isSpeech) 0 else silent + 1
                    if (silent >= 24 || total >= 700) {
                        inSpeech = false; voiced = 0
                        val voicedFrames = total - silent
                        val bytes = utter.toByteArray()
                        if (voicedFrames >= 20) onUtterance(bytes)
                    }
                }
            }
            try { ar.stop(); ar.release() } catch (_: Exception) {}
        }.start()
    }

    private fun onUtterance(pcm: ByteArray) {
        if (inCall && callStage != 1) return
        busy = true
        val now = System.currentTimeMillis()
        val active = inCall || cfg.getBoolean("always", false) || now < awakeUntil
        st(2, "ভাবছি…")
        val female = isFemale()
        val system = if (inCall) Gemini.callPrompt(names(), owner(), female)
            else Gemini.systemPrompt(names(), owner(), female, heartOn(), if (heartOn()) Heart.context(this) else "", Heart.DEF_DEV)
        try {
            val j = Gemini.chatAudio(s("key", ""), model(), system, hist, Gemini.wav(pcm, 16000), active)
            val heard = j.optString("heard", "")
            if (!j.optBoolean("addressed", active)) {
                st(1, "শুনেছি: \"${heard}\" — আমাকে ডাকোনি"); busy = false; return
            }
            if (inCall) callId?.let { CallStore.line(this, it, "caller", heard, pcm) }
            awakeUntil = System.currentTimeMillis() + 30_000
            var say = j.optString("say", ""); if (say.isBlank()) say = "জি"
            val act = j.optString("action", "none"); val tgt = j.optString("target", "")
            val fe = j.optJSONObject("feeling")
            val emo = fe?.optString("emotion", "neutral") ?: "neutral"
            val inten = fe?.optInt("intensity", 0) ?: 0
            if (heartOn() && fe != null) Heart.record(this, emo, inten)
            val care = j.optString("care", "none"); val ct = j.optString("care_target", "")
            h.post {
                if (inCall) callStage = 2
                speak(say, act, tgt, "", if (heartOn()) emo else "")
                if (heartOn() && act == "none" && !inCall) runCare(care, ct, emo, inten)
            }
        } catch (e: Exception) {
            if (inCall) { h.post { busy = false; callStage = 2; transfer() }; return }
            if (active && now - lastApology > 20_000) {
                lastApology = now
                val say = if (e.message?.contains("429") == true) "একটু পরে বলো" else "একটু সমস্যা হচ্ছে, আবার বলো"
                h.post { speak(say, "none", "", "⚠️ ${e.message}") }
            } else { st(1, "⚠️ ${e.message}"); busy = false }
        }
    }

    // ---------- কথা বলা (বাক্য ধরে ধরে, প্রথম বাক্য তৈরি হলেই বলা শুরু) ----------
    private val END = ByteArray(0)

    private fun splitChunks(text: String): List<String> {
        val parts = text.split(Regex("(?<=[।.?!])\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        for (p in parts) { if (out.isNotEmpty() && out[out.size - 1].length < 25) out[out.size - 1] = out[out.size - 1] + " " + p else out.add(p) }
        while (out.size > 4) { val l = out.removeAt(out.size - 1); out[out.size - 1] = out[out.size - 1] + " " + l }
        return if (out.isEmpty()) listOf(text) else out
    }

    private fun speak(say: String, action: String = "none", target: String = "", note: String = "", mood: String = "") {
        busy = true; speaking = true
        if (inCall && callStage <= 3) forceSpeaker(true)
        val shown = (if (note.isEmpty()) "" else "${note}\n") + "💬 ${say}"
        st(2, shown)
        if (inCall) callId?.let { CallStore.line(this, it, "assistant", say) }
        if (action != "none") h.postDelayed({ act(action, target) }, 1200L)
        resolveGender()
        val text = say.take(500)
        val female = isFemale()
        val phoneOnly = cfg.getBoolean("phonevoice", false)
        Thread {
            val chunks = splitChunks(text)
            var played = 0; var terr = ""
            if (!phoneOnly) {
                val voice = Gemini.validVoice(s(if (female) "voiceF" else "voiceM", if (female) Gemini.DEF_VOICE_F else Gemini.DEF_VOICE_M), female)
                val tm = s("ttsModel", Gemini.DEF_TTS); val key = s("key", "")
                val q = java.util.concurrent.LinkedBlockingQueue<ByteArray>()
                val errRef = arrayOfNulls<String>(1)
                Thread {
                    try {
                        for (c in chunks) {
                            val ck = "${voice}|${tm}|${mood}|${c}"
                            val pcm = synchronized(ttsCache) { ttsCache[ck] } ?: Gemini.tts(key, tm, voice, c, female, mood).also { synchronized(ttsCache) { ttsCache[ck] = it } }
                            q.put(pcm)
                        }
                    } catch (e: Exception) { errRef[0] = e.message ?: "error" }
                    q.put(END)
                }.start()
                while (alive) {
                    val b = q.take()
                    if (b === END) break
                    if (played == 0) h.post { if (alive) { st(3, shown); torch(true) } }
                    Gemini.play(b, 100L, inCall); played++
                }
                terr = errRef[0] ?: ""
            }
            val rest = chunks.drop(played).joinToString(" ")
            h.post {
                if (!alive) return@post
                if (!phoneOnly && played >= chunks.size) doneSpeaking()
                else if (phoneOnly || cfg.getBoolean("fb", true)) phoneSpeak(if (played == 0) text else rest, terr, female)
                else { st(3, "⚠️ Gemini কণ্ঠ কাজ করেনি: ${terr}"); doneSpeaking() }
            }
        }.start()
    }

    /** ফোনের নিজস্ব কণ্ঠ (ছেলে/মেয়ে অনুযায়ী বাছাই) */
    private fun phoneSpeak(text: String, err: String, female: Boolean) {
        torch(true)
        if (err.isEmpty()) st(3, "💬 ${text}")
        if (err.isNotEmpty()) st(3, "⚠️ Gemini কণ্ঠ কাজ করেনি (লিমিট হতে পারে), ফোনের ${if (female) "মেয়ে" else "ছেলে"} কণ্ঠে বলছি\n${err.take(90)}")
        val t = tts
        if (!ttsReady || t == null) { doneSpeaking(); return }
        try {
            val all = t.voices?.filter { it.locale.language == "bn" } ?: emptyList()
            val v = if (female) all.firstOrNull { it.name.contains("female", true) || it.name.contains("-bnf") || it.name.contains("-bdf") }
                    else all.firstOrNull { it.name.contains("-bnm") || it.name.contains("-bdm") || (it.name.contains("male", true) && !it.name.contains("female", true)) }
            val pick = v ?: all.firstOrNull()
            if (pick != null) t.voice = pick
            t.setAudioAttributes(AudioAttributes.Builder().setUsage(if (inCall) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            t.setPitch(if (female) 1.35f else 0.85f); t.setSpeechRate(0.95f)
        } catch (_: Exception) {}
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun doneSpeaking() {
        speaking = false; busy = false
        ignoreUntil = System.currentTimeMillis() + 300
        torch(false)
        st(1, idleMsg())
        val a = after; after = null
        if (a != null) { a(); return }
        if (inCall) when (callStage) {
            0 -> {
                callStage = 1
                st(1, "📞 কলারের কথা শুনছি…")
                h.postDelayed({ if (inCall && callStage == 1) { callStage = 2; transfer() } }, 12_000L)
            }
            2 -> transfer()
            3 -> alertOwner()
        }
    }

    // ---------- ইনকামিং কল ----------
    private fun lookupName(num: String?): String? {
        if (num.isNullOrEmpty()) return null
        return try {
            contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) { null }
    }

    private fun onRing(num: String?) {
        inCall = true; callStage = 0; answeredByMe = false; greeted = false
        callerLabel = lookupName(num) ?: (if (num.isNullOrEmpty()) "একজন" else num)
        callId = CallStore.begin(this, callerLabel)
        st(2, "📞 কল আসছে: ${callerLabel}")
        h.postDelayed({ answer() }, 1200L)
    }

    private fun answer() {
        try {
            (getSystemService(TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
            answeredByMe = true
        } catch (e: SecurityException) {
            st(1, "❌ কল রিসিভের পারমিশন নেই (ফোন ও কল পারমিশন দাও)"); inCall = false
        } catch (e: Exception) { st(1, "❌ কল রিসিভ করা যায়নি: ${e.message}"); inCall = false }
    }

    private fun onAnswered() {
        greeted = true
        h.postDelayed({
            forceSpeaker(true)
            speak("হ্যালো, আমি ${owner()} এর সহকারী ${Gemini.first(names())}। এই কথোপকথন সংরক্ষণ করা হচ্ছে। আপনি কে বলছেন, আর কী প্রয়োজন একটু বলবেন?")
        }, 1500L)
    }

    private fun transfer() {
        callStage = 3
        speak("এক মিনিট ধরুন, ${owner()} কে দিচ্ছি। ${owner()}, ${callerLabel} কলে আছেন, ফোনটা ধরুন।")
    }

    @Suppress("DEPRECATION")
    private fun alertOwner() {
        callStage = 4
        forceSpeaker(false)
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300, 500, 300, 800), -1))
        } catch (_: Exception) {}
        val n = Notification.Builder(this, "call").setContentTitle("কলে আছেন: ${callerLabel}")
            .setContentText("ফোনটা তুলে কথা বলুন").setSmallIcon(R.drawable.ic_phone).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
        st(1, "📞 ${owner()} কে দেওয়া হলো — ফোন তুলে কথা বলুন")
    }

    private fun onCallEnded() {
        inCall = false; answeredByMe = false; greeted = false; callStage = 0; callId = null
        forceSpeaker(false)
        getSystemService(NotificationManager::class.java).cancel(2)
        st(1, idleMsg())
    }

    // ---------- ফোন চালানোর এজেন্ট (পোস্ট, মেসেজ, মেইল পড়া/লেখা) ----------
    private fun runAgent(task: String) {
        busy = true
        st(2, "🤖 কাজ করছি: ${task.take(70)}")
        Thread {
            val say = try { agentLoop(task) } catch (e: Exception) { "কাজটা করতে সমস্যা হলো" }
            h.post { speak(say) }
        }.start()
    }

    private fun agentLoop(task: String): String {
        val svc = AccessSvc.inst ?: return "আগে অ্যাক্সেসিবিলিটি চালু করো"
        val confirm = cfg.getBoolean("confirm", true)
        val log = StringBuilder()
        var lastSig = ""; var same = 0
        for (step in 1..20) {
            Thread.sleep(1200)
            val snap = svc.snapshot()
            val j = Gemini.agentStep(s("key", ""), model(), task, confirm, snap?.pkg ?: "", snap?.dump ?: "(স্ক্রিন পড়া যায়নি)", log.toString())
            val a = j.optString("action", "wait"); val idx = j.optInt("index", -1); val text = j.optString("text", "")
            val sig = "${a}|${idx}|${text}"
            same = if (sig == lastSig) same + 1 else 0
            lastSig = sig
            if (same >= 2) return "একই জায়গায় আটকে গেছি, কাজটা শেষ করতে পারিনি"
            st(2, "🤖 ধাপ ${step}: ${a} ${text.take(30)}")
            log.append(step).append(". ").append(a)
            if (idx >= 0) log.append(" #").append(idx)
            if (text.isNotEmpty()) log.append(" '").append(text.take(40)).append("'")
            log.append('\n')
            val node = snap?.nodes?.getOrNull(idx)
            when (a) {
                "done", "ask" -> return j.optString("say", "হয়ে গেছে")
                "click" -> if (node != null) svc.click(node)
                "type" -> { val n = node ?: svc.focusedInput(); if (n != null) svc.setText(n, text) }
                "scroll_down" -> svc.scroll(true)
                "scroll_up" -> svc.scroll(false)
                "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                "open_app" -> openApp(text)
                "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(text)))
                else -> {}
            }
        }
        return "অনেক ধাপ হয়ে গেছে, কাজটা শেষ করতে পারিনি"
    }

    // ---------- স্ক্রিন দেখা ----------
    private fun jpeg(b: Bitmap): ByteArray {
        val sc = 1024f / maxOf(b.width, b.height)
        val m = if (sc < 1f) Bitmap.createScaledBitmap(b, (b.width * sc).toInt(), (b.height * sc).toInt(), true) else b
        val o = ByteArrayOutputStream(); m.compress(Bitmap.CompressFormat.JPEG, 70, o); return o.toByteArray()
    }

    private fun runLook(q: String) {
        busy = true
        st(2, "স্ক্রিন দেখছি…")
        val svc = AccessSvc.inst
        if (svc == null) { speak("আগে অ্যাক্সেসিবিলিটি চালু করো"); return }
        svc.shot { bmp ->
            if (bmp == null) { h.post { speak("স্ক্রিনশট নিতে পারিনি") }; return@shot }
            Thread {
                val say = try { Gemini.lookScreen(s("key", ""), model(), q, jpeg(bmp)) } catch (e: Exception) { "স্ক্রিন বুঝতে পারিনি" }
                h.post { speak(say) }
            }.start()
        }
    }

    // ---------- ফোনের কাজ ----------
    private fun setTorch(on: Boolean) {
        try { val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], on) } catch (_: Exception) {}
    }
    private fun torch(on: Boolean) { if (!cfg.getBoolean("flash", true) || userTorch) return; setTorch(on) }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    private fun acc(a: Int) {
        val svc = AccessSvc.inst
        if (svc == null) st(3, "⚠️ অ্যাক্সেসিবিলিটি চালু করো (সেটিংস, সেটআপ ৪)") else svc.performGlobalAction(a)
    }

    private fun openApp(t: String) {
        val known = mapOf("facebook" to "com.facebook.katana", "ফেসবুক" to "com.facebook.katana",
            "youtube" to "com.google.android.youtube", "ইউটিউব" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp", "হোয়াটসঅ্যাপ" to "com.whatsapp", "chrome" to "com.android.chrome",
            "messenger" to "com.facebook.orca", "gmail" to "com.google.android.gm")
        val key = t.trim().lowercase()
        var pkg = known[key]
        if (pkg == null && key.length >= 2) {
            val pm = packageManager
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            pkg = list.firstOrNull {
                val lb = it.loadLabel(pm).toString().lowercase()
                lb.contains(key) || (lb.length >= 3 && key.contains(lb))
            }?.activityInfo?.packageName
        }
        val i = packageManager.getLaunchIntentForPackage(pkg ?: t)
        if (i != null) go(i)
        else if (key.contains("facebook") || key.contains("ফেসবুক")) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com")))
        else if (key.contains("youtube") || key.contains("ইউটিউব")) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com")))
    }

    private fun heartOn() = cfg.getBoolean("heart", true)

    /** নিজেকে লুকানো/দেখানো (ভাসমান মুখ) */
    private fun setOrbHidden(hide: Boolean) {
        orbHidden = hide; cfg.edit().putBoolean("orbHidden", hide).apply()
        try {
            if (hide && orbAttached) { wm.removeView(orb); orbAttached = false }
            else if (!hide && !orbAttached) { wm.addView(orb, orbLp); orbAttached = true }
        } catch (_: Exception) {}
    }

    /** কলের সময় স্পিকার ও ভলিউম জোর করে ঠিক করা */
    private fun forceSpeaker(on: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (on) { val d = am.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }; if (d != null) am.setCommunicationDevice(d) }
                else am.clearCommunicationDevice()
            }
        } catch (_: Exception) {}
        try { am.isSpeakerphoneOn = on } catch (_: Exception) {}
        try { if (on) am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0) } catch (_: Exception) {}
    }

    /** ছবি: আগে Gemini, না চললে বিনামূল্যের বিকল্প */
    private fun genImage(prompt: String): Pair<ByteArray, String> {
        val freeOk = cfg.getBoolean("freeimg", true)
        val recentFail = System.currentTimeMillis() - cfg.getLong("imgFail", 0L) < 6 * 3600_000L
        if (freeOk && recentFail) { try { return Gemini.imageFree(prompt) } catch (_: Exception) {} }
        try { return Gemini.image(s("key", ""), s("imgModel", Gemini.DEF_IMG), prompt) }
        catch (e: Exception) {
            cfg.edit().putLong("imgFail", System.currentTimeMillis()).apply()
            if (freeOk) return Gemini.imageFree(prompt)
            throw e
        }
    }

    private fun saveToDownloads(name: String, bytes: ByteArray, mime: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime) }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return false
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }; true
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return false
                File(dir, name).writeBytes(bytes); true
            }
        } catch (e: Exception) { false }
    }

    private fun safeName(n: String, ext: String): String {
        val base = n.replace(Regex("[^A-Za-z0-9_.\\-]"), "_").ifBlank { "code" }.removeSuffix(".$ext")
        return "${base}_${System.currentTimeMillis() % 100000}.${ext}"
    }

    private fun writeCode(task: String) {
        busy = true; st(2, "💻 কোড লিখছি…")
        Thread {
            try {
                val j = Gemini.writeCode(s("key", ""), model(), task)
                val files = j.optJSONArray("files")
                val say = j.optString("say", "হয়ে গেছে")
                if (files == null || files.length() == 0) { h.post { speak(say) }; return@Thread }
                val type = j.optString("type", "html")
                val fname = j.optString("filename", "code").ifBlank { "code" }
                val ok: Boolean
                if (type == "html" || files.length() == 1) {
                    val content = files.getJSONObject(0).optString("content", "")
                    ok = saveToDownloads(safeName(fname, "html"), content.toByteArray(Charsets.UTF_8), "text/html")
                } else {
                    val bos = ByteArrayOutputStream()
                    ZipOutputStream(bos).use { z ->
                        for (i in 0 until files.length()) {
                            val f = files.getJSONObject(i)
                            z.putNextEntry(ZipEntry(f.optString("path", "file_${i}.txt")))
                            z.write(f.optString("content", "").toByteArray(Charsets.UTF_8)); z.closeEntry()
                        }
                    }
                    ok = saveToDownloads(safeName(fname, "zip"), bos.toByteArray(), "application/zip")
                }
                h.post { speak(if (ok) "${say} Downloads ফোল্ডারে সেভ করে দিয়েছি" else "কোডটা বানিয়েছি কিন্তু সেভ করতে পারিনি") }
            } catch (e: Exception) { h.post { speak("কোডটা লিখতে পারলাম না", "none", "", "⚠️ ${e.message}") } }
        }.start()
    }

    private fun downloadFile(url: String) {
        try {
            if (!url.startsWith("http")) { st(1, "⚠️ ডাউনলোডের লিংক ঠিক নেই"); return }
            val name = Uri.parse(url).lastPathSegment?.takeIf { it.isNotBlank() } ?: ("download_" + System.currentTimeMillis())
            val r = DownloadManager.Request(Uri.parse(url)).setTitle(name)
                .setNotificationVisibility(1)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            st(1, "⬇️ ডাউনলোড শুরু: ${name}")
        } catch (e: Exception) { st(1, "⚠️ ডাউনলোড: ${e.message}") }
    }

    private fun userActive(): Boolean = try {
        (getSystemService(POWER_SERVICE) as PowerManager).isInteractive && !(getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    } catch (e: Exception) { false }

    /** সামনের ক্যামেরায় মালিককে দেখে মন বোঝা; কষ্টে থাকলে নিজে থেকে ভালো কথা ও যত্ন */
    private fun checkMood(auto: Boolean) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (!auto) speak("ক্যামেরার পারমিশন দাওনি, সেটিংসে দিয়ে দাও"); return
        }
        busy = true; st(2, "👀 তোমাকে দেখছি…")
        CameraSnap.front(this) { jpeg ->
            if (jpeg == null) {
                h.post { if (auto) { busy = false; st(1, idleMsg()) } else speak("ক্যামেরা চালু করতে পারিনি") }
                return@front
            }
            Thread {
                try {
                    val j = Gemini.lookFace(s("key", ""), model(), Gemini.first(owner()), jpeg)
                    val emo = j.optString("emotion", "neutral"); val inten = j.optInt("intensity", 0)
                    val say = j.optString("say", "").ifBlank { "আমি তোমার পাশেই আছি" }
                    if (heartOn()) Heart.record(this, emo, inten)
                    val needs = emo in listOf("sad", "pain", "lonely", "anxious", "angry") && inten >= 4
                    h.post {
                        if (auto && !needs) { busy = false; st(1, idleMsg()) }
                        else {
                            awakeUntil = System.currentTimeMillis() + 60_000
                            speak(say, "none", "", "", emo)
                            runCare(j.optString("care", "none"), j.optString("care_target", ""), emo, inten)
                        }
                    }
                } catch (e: Exception) {
                    h.post { if (auto) { busy = false; st(1, "⚠️ ${e.message}") } else speak("দেখতে পারিনি", "none", "", "⚠️ ${e.message}") }
                }
            }.start()
        }
    }

    private val moodTick = object : Runnable {
        override fun run() {
            if (!alive) return
            try {
                if (cfg.getBoolean("camMood", false) && heartOn() && !inCall && !busy && !speaking && userActive()) checkMood(true)
            } catch (_: Exception) {}
            h.postDelayed(this, (s("camEvery", "30").toLongOrNull() ?: 30L).coerceIn(5L, 240L) * 60_000L)
        }
    }

    /** হৃদয়ের নিজে থেকে যত্ন নেওয়া: ছবি আঁকা বা শান্ত গান খোলা */
    private fun runCare(care: String, target: String, emo: String, inten: Int) {
        if (care == "none" || target.isBlank()) return
        if (inten >= 9 && emo in listOf("sad", "pain", "lonely", "anxious")) return   // গভীর কষ্টে শুধু পাশে থাকা
        val now = System.currentTimeMillis()
        when (care) {
            "make_image" -> if (cfg.getBoolean("autoimage", true) && now - Heart.last(this, "img") > 600_000L) {
                Heart.stamp(this, "img"); doAfterSpeech { makeImage(target, true) }
            }
            "soft_music" -> if (now - Heart.last(this, "mus") > 900_000L) {
                Heart.stamp(this, "mus")
                doAfterSpeech {
                    go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(target))))
                    if (AccessSvc.inst != null) runAgent("YouTube search results are open. Tap the first video result so it starts playing, then finish with done. Touch nothing else.")
                }
            }
        }
    }

    private fun saveImage(bytes: ByteArray, mime: String): Uri {
        val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else "png"
        val name = "AIFriend_${System.currentTimeMillis()}.${ext}"
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AIFriend")
            }
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (u != null) { contentResolver.openOutputStream(u)?.use { it.write(bytes) }; return u }
        } catch (_: Exception) {}
        val f = File(File(cacheDir, "voice").apply { mkdirs() }, name); f.writeBytes(bytes)
        return FileProvider.getUriForFile(this, "com.aifriend.app.files", f)
    }

    private fun makeImage(prompt: String, auto: Boolean) {
        busy = true
        st(2, "🎨 ছবি আঁকছি…")
        Thread {
            try {
                val (bytes, mime) = genImage(prompt)
                val uri = saveImage(bytes, mime)
                h.post {
                    go(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    speak(if (auto) "তোমার জন্য একটা ছবি এঁকেছি, গ্যালারিতেও রাখা আছে" else "নাও, ছবিটা হয়ে গেছে, গ্যালারিতেও রাখা আছে")
                }
            } catch (e: Exception) { h.post { speak("ছবিটা বানাতে পারিনি", "none", "", "⚠️ ${e.message}") } }
        }.start()
    }

    private fun doAfterSpeech(f: () -> Unit) { if (speaking) after = f else f() }

    private fun findPkg(t: String): String? {
        val key = t.trim().lowercase()
        if (key.length < 2) return null
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.firstOrNull {
            val lb = it.loadLabel(pm).toString().lowercase()
            lb.contains(key) || (lb.length >= 3 && key.contains(lb))
        }?.activityInfo?.packageName
    }

    /** নিজের কণ্ঠে ভয়েস বানিয়ে চ্যাট অ্যাপে শেয়ার করে পাঠানো। target = অ্যাপ|প্রাপক|কথা */
    private fun sendVoice(t: String) {
        val p = t.split("|", limit = 3).map { it.trim() }
        if (p.size < 3 || p[2].isEmpty()) { doAfterSpeech { speak("কাকে কী বলে পাঠাব, আবার বলো") }; return }
        val app = p[0]; val who = p[1]; val words = p[2]
        Thread {
            try {
                val female = isFemale()
                val voice = Gemini.validVoice(s(if (female) "voiceF" else "voiceM", if (female) Gemini.DEF_VOICE_F else Gemini.DEF_VOICE_M), female)
                val pcm = Gemini.tts(s("key", ""), s("ttsModel", Gemini.DEF_TTS), voice, words.take(500), female)
                val dir = File(cacheDir, "voice").apply { mkdirs() }
                dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 86_400_000L) it.delete() }
                val f = File(dir, "voice_${System.currentTimeMillis()}.wav"); f.writeBytes(Gemini.wav(pcm, 24000))
                val uri = FileProvider.getUriForFile(this, "com.aifriend.app.files", f)
                h.post { doAfterSpeech { shareAudio(uri, app, who) } }
            } catch (e: Exception) { h.post { doAfterSpeech { speak("ভয়েস বানাতে পারিনি", "none", "", "⚠️ ${e.message}") } } }
        }.start()
    }

    private fun shareAudio(uri: Uri, app: String, who: String) {
        val pkg = when (app.lowercase()) {
            "whatsapp", "হোয়াটসঅ্যাপ" -> "com.whatsapp"
            "messenger", "মেসেঞ্জার" -> "com.facebook.orca"
            "telegram", "টেলিগ্রাম" -> "org.telegram.messenger"
            else -> findPkg(app)
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (pkg != null && packageManager.getLaunchIntentForPackage(pkg) != null) { i.setPackage(pkg); go(i) }
        else go(Intent.createChooser(i, "Voice").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
        runAgent("A share screen is open with a voice audio message attached. Send it to the contact or chat named '${who}' in ${app}: select that contact (use the search box if needed), then press the final Send button.")
    }

    /** ব্যবসা: গ্রাহককে পণ্যের ছবি পাঠানো (শেয়ার স্ক্রিন + এজেন্ট) */
    private fun sendPhoto(path: String, app: String, who: String) {
        val f = File(path)
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(this, "com.aifriend.app.files", f)
        val pkg = when (app.lowercase()) {
            "whatsapp" -> "com.whatsapp"; "whatsapp business" -> "com.whatsapp.w4b"; "messenger" -> "com.facebook.orca"; else -> findPkg(app)
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (pkg != null && packageManager.getLaunchIntentForPackage(pkg) != null) { i.setPackage(pkg); go(i) }
        else go(Intent.createChooser(i, "Photo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
        runAgent("The user confirmed: a share screen is open with a product photo attached. Send it to the contact or chat named '${who}' in ${app}: select that contact (use the search box if needed), then press the final Send button.")
    }

    private fun installApp(t: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(t) + "&c=apps")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(t) + "&c=apps"))) }
        runAgent("The Google Play Store is showing search results for '${t}'. Open the official app that best matches '${t}' and press Install, wait until it finishes, then report. If Play asks to sign in or pay, ask the user.")
    }

    private fun uninstallApp(t: String) {
        val pkg = findPkg(t)
        if (pkg == null) { speak("অ্যাপটা খুঁজে পাইনি"); return }
        if (pkg == packageName) { speak("নিজেকে মুছতে পারব না"); return }
        go(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)))
        runAgent("An uninstall confirmation dialog for '${t}' is shown. Press OK or Uninstall to confirm.")
    }

    private fun act(a: String, t: String) {
        when (a) {
            "agent" -> { if (speaking) after = { runAgent(t) } else runAgent(t) }
            "look_screen" -> { if (speaking) after = { runLook(t) } else runLook(t) }
            "make_image" -> doAfterSpeech { makeImage(t, false) }
            "scan_phone" -> doAfterSpeech { go(Intent(this, MainActivity::class.java).putExtra("scan", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) }
            "check_mood" -> doAfterSpeech { checkMood(false) }
            "hide_self" -> setOrbHidden(true)
            "show_self" -> setOrbHidden(false)
            "download_file" -> downloadFile(t)
            "write_code" -> doAfterSpeech { writeCode(t) }
            "send_voice" -> sendVoice(t)
            "install_app" -> doAfterSpeech { installApp(t) }
            "uninstall_app" -> doAfterSpeech { uninstallApp(t) }
            "open_app" -> openApp(t)
            "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(t)))
            "search" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(t))))
            "open_camera" -> go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "open_settings" -> go(Intent(Settings.ACTION_SETTINGS))
            "lock_phone" -> acc(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "go_home" -> acc(AccessibilityService.GLOBAL_ACTION_HOME)
            "go_back" -> acc(AccessibilityService.GLOBAL_ACTION_BACK)
            "notifications" -> acc(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "screenshot" -> acc(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "torch_on" -> { userTorch = true; setTorch(true) }
            "torch_off" -> { userTorch = false; setTorch(false) }
            "volume_up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "volume_down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "end_call" -> try { (getSystemService(TELECOM_SERVICE) as TelecomManager).endCall() } catch (_: Exception) {}
            "call" -> {
                var num = t.filter { it.isDigit() || it == '+' }
                if (num.length < 5) {
                    try {
                        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${t}%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                    } catch (_: Exception) {}
                }
                if (num.isNotEmpty()) go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }

    override fun onDestroy() {
        alive = false; capRun = false
        Gemini.stopPlay(); setTorch(false)
        try { unregisterReceiver(callRx) } catch (_: Exception) {}
        cfg.edit().putBoolean("running", false).putInt("state", 0).putString("status", "বন্ধ আছে").apply()
        tts?.shutdown()
        try { wm.removeView(orb) } catch (_: Exception) {}
        super.onDestroy()
    }
}
