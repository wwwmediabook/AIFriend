package com.aifriend.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class AssistantService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var orb: Orb
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private val hist = JSONArray()
    private var awakeUntil = 0L
    private var speaking = false
    private var ttsReady = false
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ai", "AI Friend", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ai").setContentTitle("AI Friend চালু আছে")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        addOrb()
        tts = TextToSpeech(this) {
            ttsReady = true
            tts.language = Locale.forLanguageTag(cfg.getString("lang", "bn-BD")!!)
            pickVoice()
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onError(u: String?) { h.post { doneSpeaking() } }
                override fun onDone(u: String?) { h.post { doneSpeaking() } }
            })
            listen()
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    /** মেয়েলি কণ্ঠ: সেভ করা ভয়েস -> নামে "bnf"/"female" থাকা ভয়েস -> যেকোনো বাংলা ভয়েস + হালকা চড়া পিচ */
    private fun pickVoice() {
        try {
            val all = tts.voices?.filter { it.locale.language == "bn" } ?: emptyList()
            val saved = cfg.getString("voice", "")
            val v = all.firstOrNull { it.name == saved }
                ?: all.firstOrNull { it.name.contains("female", true) || Regex("x-bn[a-z]?f").containsMatchIn(it.name) || it.name.contains("-bnf-") }
                ?: all.firstOrNull { !it.name.contains("-bnm-") && !it.name.contains("male", true) }
                ?: all.firstOrNull()
            if (v != null) tts.voice = v
            tts.setPitch(if (saved.isNullOrEmpty()) 1.3f else 1.15f)
            tts.setSpeechRate(0.95f)
        } catch (_: Exception) {}
    }

    private fun addOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        orb = Orb(this)
        val s = (160 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(orb, lp) }
            }; true
        }
        wm.addView(orb, lp)
    }

    private fun listen() {
        if (speaking) return
        orb.state = 1
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) h.postDelayed({ listen() }, 300) else handle(t)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, cfg.getString("lang", "bn-BD"))
            })
        }
    }

    private fun handle(text: String) {
        val name = cfg.getString("name", "জারভিস")!!
        val now = System.currentTimeMillis()
        if (!text.contains(name, true) && now > awakeUntil) { listen(); return }
        awakeUntil = now + 30_000
        orb.state = 2
        Thread {
            val j = try { ask(text) } catch (e: Exception) { JSONObject().put("say", "ইন্টারনেট বা API Key তে সমস্যা হয়েছে").put("action", "none") }
            h.post { speak(j.optString("say"), j.optString("action"), j.optString("target")) }
        }.start()
    }

    private fun ask(text: String): JSONObject {
        val name = cfg.getString("name", "জারভিস")
        val sys = "You are $name, a sweet, warm young woman and close friend, living as a voice assistant on the user's Android phone. Speak naturally in Bengali (বাংলা) by default, short and friendly, like chatting with a friend; use the user's language if they speak another. Never use emojis or symbols in "say" because it is read aloud. " +
            "Output ONLY JSON: {\"say\":string,\"action\":\"none|open_app|call|open_url\",\"target\":string}. " +
            "open_app target: facebook, youtube, whatsapp, chrome or package name. call target: contact name or phone number. open_url target: full URL."
        hist.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", hist)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val u = URL("https://generativelanguage.googleapis.com/v1beta/models/${cfg.getString("model", "gemini-2.5-flash")}:generateContent?key=${cfg.getString("key", "")}")
        val c = u.openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode == 200) c.inputStream else c.errorStream).bufferedReader().readText()
        val out = JSONObject(resp).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        hist.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", out))))
        while (hist.length() > 14) hist.remove(0)
        return JSONObject(out)
    }

    private fun speak(say: String, action: String, target: String) {
        speaking = true; orb.state = 3; torch(true)
        rec?.cancel()
        if (ttsReady) tts.speak(say, TextToSpeech.QUEUE_FLUSH, null, "u") else doneSpeaking()
        h.postDelayed({ act(action, target) }, 1500)
    }

    private fun doneSpeaking() { speaking = false; torch(false); listen() }

    private fun torch(on: Boolean) {
        if (!cfg.getBoolean("flash", true)) return
        try { val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], on) } catch (_: Exception) {}
    }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    private fun act(a: String, t: String) {
        when (a) {
            "open_app" -> {
                val pkg = when (t.lowercase()) {
                    "facebook" -> "com.facebook.katana"; "youtube" -> "com.google.android.youtube"
                    "whatsapp" -> "com.whatsapp"; "chrome" -> "com.android.chrome"; else -> t
                }
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) go(i) else if (t.equals("facebook", true)) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com")))
                else if (t.equals("youtube", true)) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com")))
            }
            "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(t)))
            "call" -> {
                var num = t.filter { it.isDigit() || it == '+' }
                if (num.length < 5) {
                    try {
                        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$t%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                    } catch (_: Exception) {}
                }
                if (num.isNotEmpty()) go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }

    override fun onDestroy() {
        torch(false); rec?.destroy(); tts.shutdown()
        try { wm.removeView(orb) } catch (_: Exception) {}
        super.onDestroy()
    }
}
