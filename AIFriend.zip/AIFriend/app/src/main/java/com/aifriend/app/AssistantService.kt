package com.aifriend.app

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.*
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class AssistantService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var orb: Orb
    private lateinit var am: AudioManager
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val h = Handler(Looper.getMainLooper())
    private val hist = JSONArray()
    private var awakeUntil = 0L
    private var female = true
    private var userTorch = false
    private var lastApology = 0L

    @Volatile private var speaking = false
    @Volatile private var busy = false
    @Volatile private var alive = true
    @Volatile private var capRun = false
    @Volatile private var ignoreUntil = 0L

    // কল সংক্রান্ত
    private var inCall = false
    private var answeredByMe = false
    private var greeted = false
    @Volatile private var callStage = 0   // 0 শুরু, 1 কলারের কথা শুনছি, 2 উত্তর দেওয়া হয়েছে, 3 ট্রান্সফার ঘোষণা, 4 শেষ
    private var callerLabel = "একজন"

    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private fun s(k: String, d: String) = cfg.getString(k, d) ?: d
    private fun names() = s("name", "মায়া")
    private fun owner() = s("owner", "মালিক")

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    private fun st(state: Int, msg: String) {
        h.post { if (::orb.isInitialized) orb.state = state }
        cfg.edit().putString("status", msg).putInt("state", state).apply()
    }

    private val callRx = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val state = i.getStringExtra(TelephonyManager.EXTRA_STATE)
            val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            when (state) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    if (!cfg.getBoolean("callmode", false)) return
                    if (!inCall) onRing(num)
                    else if (callerLabel == "একজন" && !num.isNullOrEmpty()) callerLabel = lookupName(num) ?: num
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> if (inCall && answeredByMe && !greeted) onAnswered()
                TelephonyManager.EXTRA_STATE_IDLE -> if (inCall) onCallEnded()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ai", "AI Friend", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("call", "কল", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, "ai").setContentTitle("AI Friend চালু আছে")
            .setSmallIcon(R.drawable.ic_mic).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        cfg.edit().putBoolean("running", true).apply()
        addOrb()
        val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(callRx, f, Context.RECEIVER_EXPORTED) else registerReceiver(callRx, f)
        tts = TextToSpeech(this) { code ->
            ttsReady = code == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale.forLanguageTag("bn-BD")
                tts?.setPitch(1.2f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) {}
                    override fun onError(u: String?) { h.post { doneSpeaking() } }
                    override fun onDone(u: String?) { h.post { doneSpeaking() } }
                })
            }
        }
        // নাম দেখে ছেলে/মেয়ে কণ্ঠ ঠিক করা, তারপর শুভেচ্ছা
        busy = true
        Thread {
            val name = names()
            female = when (s("gender", "auto")) {
                "female" -> true
                "male" -> false
                else -> {
                    val cached = cfg.getString("g_" + name, null)
                    val g = cached ?: Gemini.nameGender(s("key", ""), s("model", Gemini.DEF_MODEL), name)?.also { cfg.edit().putString("g_" + name, it).apply() }
                        ?: Gemini.guessGender(name)
                    g == "female"
                }
            }
            h.post { busy = false; if (alive) speak("জি, আমি চালু হয়েছি। নাম ধরে ডাকলেই কথা বলব।") }
        }.start()
        startCapture()
    }

    // ---------- ভাসমান অরব ----------
    private fun addOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        orb = Orb(this)
        val sz = (160 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 15 || abs(e.rawY - sy) > 15) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(orb, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) wake()
            }
            true
        }
        wm.addView(orb, lp)
    }

    /** বলে ট্যাপ করলে নাম ছাড়াই ৬০ সেকেন্ড কথা বলা যায় */
    private fun wake() {
        awakeUntil = System.currentTimeMillis() + 60_000
        if (!speaking && !busy) speak("জি, বলো")
    }

    // ---------- নিঃশব্দ শোনা (কোনো বিপ/কট শব্দ নেই) ----------
    private fun bytesOf(b: ShortArray, n: Int): ByteArray {
        val o = ByteArray(n * 2)
        for (i in 0 until n) { o[2 * i] = (b[i].toInt() and 0xFF).toByte(); o[2 * i + 1] = (b[i].toInt() shr 8).toByte() }
        return o
    }

    private fun startCapture() {
        if (capRun) return
        capRun = true
        Thread {
            val sr = 16000; val frame = 320
            val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            var ar: AudioRecord? = null
            try {
                ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 16))
                if (ar.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("মাইক চালু হয়নি, পারমিশন দাও")
                ar.startRecording()
            } catch (e: Exception) { st(0, "❌ মাইক: ${e.message}"); capRun = false; return@Thread }
            st(1, "শুনছি… নাম ধরে ডাকো (${Gemini.first(names())}) অথবা বলে ট্যাপ করো")
            val buf = ShortArray(frame)
            val utter = ByteArrayOutputStream()
            val pre = ArrayDeque<ByteArray>()
            var noise = 150.0; var inSpeech = false; var voiced = 0; var silent = 0; var total = 0
            while (capRun) {
                val n = ar.read(buf, 0, frame)
                if (n <= 0) { Thread.sleep(20); continue }
                if (busy || speaking || System.currentTimeMillis() < ignoreUntil) { inSpeech = false; voiced = 0; pre.clear(); continue }
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                val rms = sqrt(sum / n)
                val isSpeech = rms > maxOf(noise * 2.8, 350.0)
                if (!inSpeech) {
                    if (!isSpeech) noise = noise * 0.98 + rms * 0.02
                    pre.addLast(bytesOf(buf, n)); if (pre.size > 12) pre.removeFirst()
                    voiced = if (isSpeech) voiced + 1 else 0
                    if (voiced >= 4) { inSpeech = true; utter.reset(); pre.forEach { utter.write(it) }; pre.clear(); silent = 0; total = 0 }
                } else {
                    utter.write(bytesOf(buf, n)); total++
                    silent = if (isSpeech) 0 else silent + 1
                    if (silent >= 40 || total >= 700) {
                        inSpeech = false; voiced = 0
                        val voicedFrames = total - silent
                        val bytes = utter.toByteArray()
                        if (voicedFrames >= 20) onUtterance(bytes)
                    }
                }
            }
            try { ar.stop(); ar.release() } catch (_: Exception) {}
        }.start()
    }

    private fun onUtterance(pcm: ByteArray) {
        if (inCall && callStage != 1) return
        busy = true
        val now = System.currentTimeMillis()
        val active = inCall || cfg.getBoolean("always", false) || now < awakeUntil
        st(2, "ভাবছি…")
        val system = if (inCall) Gemini.callPrompt(names(), owner(), female) else Gemini.systemPrompt(names(), owner(), female)
        try {
            val j = Gemini.chatAudio(s("key", ""), s("model", Gemini.DEF_MODEL), system, hist, Gemini.wav(pcm, 16000), active)
            val heard = j.optString("heard", "")
            if (!j.optBoolean("addressed", active)) {
                st(1, "শুনেছি: \"${heard}\" — আমাকে ডাকোনি"); busy = false; return
            }
            awakeUntil = System.currentTimeMillis() + 30_000
            var say = j.optString("say", ""); if (say.isBlank()) say = "জি"
            val act = j.optString("action", "none"); val tgt = j.optString("target", "")
            h.post { if (inCall) callStage = 2; speak(say, act, tgt) }
        } catch (e: Exception) {
            if (inCall) { h.post { busy = false; callStage = 2; transfer() }; return }
            if (active && now - lastApology > 20_000) {
                lastApology = now
                val say = if (e.message?.contains("429") == true) "একটু পরে বলো" else "একটু সমস্যা হচ্ছে, আবার বলো"
                h.post { speak(say, "none", "", "⚠️ ${e.message}") }
            } else { st(1, "⚠️ ${e.message}"); busy = false }
        }
    }

    // ---------- কথা বলা ----------
    private fun speak(say: String, action: String = "none", target: String = "", note: String = "") {
        busy = true; speaking = true
        if (!inCall) torch(true)
        st(3, (if (note.isEmpty()) "" else "${note}\n") + "💬 ${say}")
        if (action != "none") h.postDelayed({ act(action, target) }, 1200L)
        val text = say.take(500)
        Thread {
            var ok = false; var terr = ""
            try {
                val voice = if (female) s("voiceF", Gemini.DEF_VOICE_F) else s("voiceM", Gemini.DEF_VOICE_M)
                val pcm = Gemini.tts(s("key", ""), s("ttsModel", Gemini.DEF_TTS), voice, text, female)
                Gemini.play(pcm); ok = true
            } catch (e: Exception) { terr = e.message ?: "" }
            h.post {
                if (!alive) return@post
                if (ok) doneSpeaking() else {
                    st(3, "⚠️ কণ্ঠ: ${terr}")
                    if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u") else doneSpeaking()
                }
            }
        }.start()
    }

    private fun doneSpeaking() {
        speaking = false; busy = false
        ignoreUntil = System.currentTimeMillis() + 700
        torch(false)
        st(1, "শুনছি… নাম ধরে ডাকো (${Gemini.first(names())}) অথবা বলে ট্যাপ করো")
        if (inCall) when (callStage) {
            0 -> {
                callStage = 1
                st(1, "📞 কলারের কথা শুনছি…")
                h.postDelayed({ if (inCall && callStage == 1) { callStage = 2; transfer() } }, 12_000L)
            }
            2 -> transfer()
            3 -> alertOwner()
        }
    }

    // ---------- ইনকামিং কল ----------
    private fun lookupName(num: String?): String? {
        if (num.isNullOrEmpty()) return null
        return try {
            contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) { null }
    }

    private fun onRing(num: String?) {
        inCall = true; callStage = 0; answeredByMe = false; greeted = false
        callerLabel = lookupName(num) ?: (if (num.isNullOrEmpty()) "একজন" else num)
        st(2, "📞 কল আসছে: ${callerLabel}")
        h.postDelayed({ answer() }, 1200L)
    }

    private fun answer() {
        try {
            (getSystemService(TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
            answeredByMe = true
        } catch (e: SecurityException) {
            st(1, "❌ কল রিসিভের পারমিশন নেই (ফোন ও কল পারমিশন দাও)"); inCall = false
        } catch (e: Exception) { st(1, "❌ কল রিসিভ করা যায়নি: ${e.message}"); inCall = false }
    }

    private fun onAnswered() {
        greeted = true
        h.postDelayed({
            try { am.isSpeakerphoneOn = true } catch (_: Exception) {}
            speak("হ্যালো, আমি ${owner()} এর সহকারী ${Gemini.first(names())}। আপনি কে বলছেন, আর কী প্রয়োজন একটু বলবেন?")
        }, 900L)
    }

    private fun transfer() {
        callStage = 3
        speak("এক মিনিট ধরুন, ${owner()} কে দিচ্ছি। ${owner()}, ${callerLabel} কলে আছেন, ফোনটা ধরুন।")
    }

    @Suppress("DEPRECATION")
    private fun alertOwner() {
        callStage = 4
        try { am.isSpeakerphoneOn = false } catch (_: Exception) {}
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300, 500, 300, 800), -1))
        } catch (_: Exception) {}
        val n = Notification.Builder(this, "call").setContentTitle("কলে আছেন: ${callerLabel}")
            .setContentText("ফোনটা তুলে কথা বলুন").setSmallIcon(R.drawable.ic_phone).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
        st(1, "📞 ${owner()} কে দেওয়া হলো — ফোন তুলে কথা বলুন")
    }

    private fun onCallEnded() {
        inCall = false; answeredByMe = false; greeted = false; callStage = 0
        try { am.isSpeakerphoneOn = false } catch (_: Exception) {}
        getSystemService(NotificationManager::class.java).cancel(2)
        st(1, "শুনছি… নাম ধরে ডাকো (${Gemini.first(names())}) অথবা বলে ট্যাপ করো")
    }

    // ---------- ফোনের কাজ ----------
    private fun setTorch(on: Boolean) {
        try { val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], on) } catch (_: Exception) {}
    }
    private fun torch(on: Boolean) { if (!cfg.getBoolean("flash", true) || userTorch) return; setTorch(on) }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    private fun acc(a: Int) {
        val svc = AccessSvc.inst
        if (svc == null) st(3, "⚠️ অ্যাক্সেসিবিলিটি চালু করো (অ্যাপের সেটআপ বাটন ৪)") else svc.performGlobalAction(a)
    }

    private fun openApp(t: String) {
        val known = mapOf("facebook" to "com.facebook.katana", "ফেসবুক" to "com.facebook.katana",
            "youtube" to "com.google.android.youtube", "ইউটিউব" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp", "হোয়াটসঅ্যাপ" to "com.whatsapp", "chrome" to "com.android.chrome")
        val key = t.trim().lowercase()
        var pkg = known[key]
        if (pkg == null && key.length >= 2) {
            val pm = packageManager
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            pkg = list.firstOrNull {
                val lb = it.loadLabel(pm).toString().lowercase()
                lb.contains(key) || (lb.length >= 3 && key.contains(lb))
            }?.activityInfo?.packageName
        }
        val i = packageManager.getLaunchIntentForPackage(pkg ?: t)
        if (i != null) go(i)
        else if (key.contains("facebook") || key.contains("ফেসবুক")) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com")))
        else if (key.contains("youtube") || key.contains("ইউটিউব")) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com")))
    }

    private fun act(a: String, t: String) {
        when (a) {
            "open_app" -> openApp(t)
            "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(t)))
            "search" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(t))))
            "open_camera" -> go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "open_settings" -> go(Intent(Settings.ACTION_SETTINGS))
            "lock_phone" -> acc(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "go_home" -> acc(AccessibilityService.GLOBAL_ACTION_HOME)
            "go_back" -> acc(AccessibilityService.GLOBAL_ACTION_BACK)
            "notifications" -> acc(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "screenshot" -> acc(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "torch_on" -> { userTorch = true; setTorch(true) }
            "torch_off" -> { userTorch = false; setTorch(false) }
            "volume_up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "volume_down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "end_call" -> try { (getSystemService(TELECOM_SERVICE) as TelecomManager).endCall() } catch (_: Exception) {}
            "call" -> {
                var num = t.filter { it.isDigit() || it == '+' }
                if (num.length < 5) {
                    try {
                        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${t}%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                    } catch (_: Exception) {}
                }
                if (num.isNotEmpty()) go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }

    override fun onDestroy() {
        alive = false; capRun = false
        Gemini.stopPlay(); setTorch(false)
        try { unregisterReceiver(callRx) } catch (_: Exception) {}
        cfg.edit().putBoolean("running", false).putInt("state", 0).putString("status", "বন্ধ আছে").apply()
        tts?.shutdown()
        try { wm.removeView(orb) } catch (_: Exception) {}
        super.onDestroy()
    }
}
