package com.aifriend.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import org.json.JSONArray
import java.util.Locale
import kotlin.math.abs

class AssistantService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var orb: Orb
    private lateinit var am: AudioManager
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private val hist = JSONArray()
    private var awakeUntil = 0L
    private var speaking = false
    private var alive = true
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private fun s(k: String, d: String) = cfg.getString(k, d) ?: d

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    private fun st(state: Int, msg: String) {
        h.post { if (::orb.isInitialized) orb.state = state }
        cfg.edit().putString("status", msg).putInt("state", state).apply()
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ai", "AI Friend", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ai").setContentTitle("AI Friend চালু আছে")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        cfg.edit().putBoolean("running", true).apply()
        addOrb()
        tts = TextToSpeech(this) { code ->
            ttsReady = code == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale.forLanguageTag(s("lang", "bn-BD"))
                pickVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) {}
                    override fun onError(u: String?) { h.post { doneSpeaking() } }
                    override fun onDone(u: String?) { h.post { doneSpeaking() } }
                })
            }
            h.post { speak("জি, আমি চালু হয়েছি। নাম ধরে ডাকলেই কথা বলব।") }
        }
    }

    private fun pickVoice() {
        try {
            val all = tts?.voices?.filter { it.locale.language == "bn" } ?: emptyList()
            val v = all.firstOrNull { it.name.contains("female", true) || it.name.contains("-bnf-") }
                ?: all.firstOrNull { !it.name.contains("-bnm-") && !it.name.contains("male", true) } ?: all.firstOrNull()
            if (v != null) tts?.voice = v
            tts?.setPitch(1.3f); tts?.setSpeechRate(0.95f)
        } catch (_: Exception) {}
    }

    private fun addOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        orb = Orb(this)
        val sz = (160 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 15 || abs(e.rawY - sy) > 15) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(orb, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) wake()
            }
            true
        }
        wm.addView(orb, lp)
    }

    /** বলে ট্যাপ করলে নাম ছাড়াই ৬০ সেকেন্ড কথা বলা যায় */
    private fun wake() {
        awakeUntil = System.currentTimeMillis() + 60_000
        if (!speaking) speak("জি, বলো")
    }

    private fun muteBeep(on: Boolean, force: Boolean = false) {
        if (!force && !cfg.getBoolean("mute", true)) return
        try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {}
    }

    private fun listen() {
        if (speaking || !alive) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            st(0, "❌ ফোনে Google Speech Services নেই — Google অ্যাপ ইনস্টল/আপডেট করো"); return
        }
        st(1, "শুনছি… নাম ধরে ডাকো (${Gemini.first(s("name", "মায়া"))}) অথবা বলে ট্যাপ করো")
        muteBeep(true)
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) h.postDelayed({ listen() }, 300L) else handle(t)
                }
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        st(0, "❌ মাইক পারমিশন দেওয়া হয়নি — অ্যাপ খুলে পারমিশন দাও")
                        h.postDelayed({ listen() }, 5000L)
                    } else h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, s("lang", "bn-BD"))
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            })
        }
    }

    private fun nameHit(t: String) =
        s("name", "মায়া").split(",", "،", "/", "|").map { it.trim() }.filter { it.isNotEmpty() }.any { t.contains(it, true) }

    private fun handle(text: String) {
        val now = System.currentTimeMillis()
        if (!cfg.getBoolean("always", false) && !nameHit(text) && now > awakeUntil) {
            st(1, "শুনেছি: \"${text}\" — নাম বলোনি, তাই চুপ আছি")
            h.postDelayed({ listen() }, 200L); return
        }
        awakeUntil = now + 30_000
        st(2, "ভাবছি… \"${text}\"")
        Thread {
            var say = ""; var act = "none"; var tgt = ""; var note = ""
            try {
                val j = Gemini.chat(s("key", ""), s("model", Gemini.DEF_MODEL), Gemini.systemPrompt(Gemini.first(s("name", "মায়া"))), hist, text)
                say = j.optString("say", ""); act = j.optString("action", "none"); tgt = j.optString("target", "")
                if (say.isBlank()) say = "জি"
            } catch (e: Exception) {
                note = "⚠️ ${e.message}"
                say = if (e.message?.contains("429") == true) "এখন একটু বেশি অনুরোধ হয়ে গেছে, একটু পরে বলো"
                      else "এআই এর সাথে যোগাযোগ করতে পারছি না"
            }
            h.post { speak(say, act, tgt, note) }
        }.start()
    }

    private fun speak(say: String, action: String = "none", target: String = "", note: String = "") {
        speaking = true
        rec?.cancel()
        muteBeep(false)
        torch(true)
        st(3, (if (note.isEmpty()) "" else "${note}\n") + "💬 ${say}")
        if (action != "none") h.postDelayed({ act(action, target) }, 1500L)
        val text = say.take(500)
        Thread {
            var ok = false; var terr = ""
            try {
                val pcm = Gemini.tts(s("key", ""), s("ttsModel", Gemini.DEF_TTS), s("ttsVoice", Gemini.DEF_VOICE), text)
                Gemini.play(pcm); ok = true
            } catch (e: Exception) { terr = e.message ?: "" }
            h.post {
                if (!alive) return@post
                if (ok) doneSpeaking() else {
                    st(3, "⚠️ Gemini কণ্ঠ কাজ করেনি: ${terr}\nফোনের সাধারণ কণ্ঠে বলছি")
                    if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u") else doneSpeaking()
                }
            }
        }.start()
    }

    private fun doneSpeaking() { speaking = false; torch(false); listen() }

    private fun torch(on: Boolean) {
        if (!cfg.getBoolean("flash", true)) return
        try { val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], on) } catch (_: Exception) {}
    }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    private fun act(a: String, t: String) {
        when (a) {
            "open_app" -> {
                val pkg = when (t.lowercase()) {
                    "facebook" -> "com.facebook.katana"; "youtube" -> "com.google.android.youtube"
                    "whatsapp" -> "com.whatsapp"; "chrome" -> "com.android.chrome"; else -> t
                }
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) go(i) else if (t.equals("facebook", true)) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com")))
                else if (t.equals("youtube", true)) go(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com")))
            }
            "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(t)))
            "call" -> {
                var num = t.filter { it.isDigit() || it == '+' }
                if (num.length < 5) {
                    try {
                        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${t}%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                    } catch (_: Exception) {}
                }
                if (num.isNotEmpty()) go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }

    override fun onDestroy() {
        alive = false
        Gemini.stopPlay(); torch(false); muteBeep(false, true)
        cfg.edit().putBoolean("running", false).putInt("state", 0).putString("status", "বন্ধ আছে").apply()
        rec?.destroy(); tts?.shutdown()
        try { wm.removeView(orb) } catch (_: Exception) {}
        super.onDestroy()
    }
}
