package com.aifriend.app

import android.graphics.Color

/** ভাসমান মুখের রূপ (রঙ-থিম) */
object Theme {
    class Pal(val idle: Int, val listen: Int, val think: Int, val speak: Int, val label: String)
    val NAMES = listOf("ocean", "sunset", "royal", "mono", "candy")
    fun of(name: String): Pal = when (name) {
        "sunset" -> Pal(Color.parseColor("#8D6E63"), Color.parseColor("#FF7043"), Color.parseColor("#FFCA28"), Color.parseColor("#FF5252"), "সূর্যাস্ত")
        "royal" -> Pal(Color.parseColor("#5C6BC0"), Color.parseColor("#AB47BC"), Color.parseColor("#FFD54F"), Color.parseColor("#7E57C2"), "রাজকীয় বেগুনি")
        "mono" -> Pal(Color.parseColor("#757575"), Color.parseColor("#9E9E9E"), Color.parseColor("#E0E0E0"), Color.parseColor("#FFFFFF"), "সাদাকালো")
        "candy" -> Pal(Color.parseColor("#4DD0E1"), Color.parseColor("#F06292"), Color.parseColor("#FFD54F"), Color.parseColor("#FF4081"), "ক্যান্ডি গোলাপি")
        else -> Pal(Color.parseColor("#607D8B"), Color.parseColor("#7C4DFF"), Color.parseColor("#FFC107"), Color.parseColor("#00E5FF"), "সমুদ্র নীল")
    }
    fun labelOf(name: String) = of(name).label
}
