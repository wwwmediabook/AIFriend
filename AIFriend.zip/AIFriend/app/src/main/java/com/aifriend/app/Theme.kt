package com.aifriend.app

import android.graphics.Color

/** ভাসমান মুখ ও হোম পেজের রূপ (রঙ-থিম) */
object Theme {
    class Pal(val idle: Int, val listen: Int, val think: Int, val speak: Int, val label: String)
    val NAMES = listOf("ocean", "sunset", "royal", "mono", "candy")
    fun of(name: String): Pal = when (name) {
        "sunset" -> Pal(Color.parseColor("#8D6E63"), Color.parseColor("#FF7043"), Color.parseColor("#FFCA28"), Color.parseColor("#FF5252"), "সূর্যাস্ত")
        "royal" -> Pal(Color.parseColor("#5C6BC0"), Color.parseColor("#AB47BC"), Color.parseColor("#FFD54F"), Color.parseColor("#7E57C2"), "রাজকীয় বেগুনি")
        "mono" -> Pal(Color.parseColor("#757575"), Color.parseColor("#9E9E9E"), Color.parseColor("#E0E0E0"), Color.parseColor("#FFFFFF"), "সাদাকালো")
        "candy" -> Pal(Color.parseColor("#4DD0E1"), Color.parseColor("#F06292"), Color.parseColor("#FFD54F"), Color.parseColor("#FF4081"), "ক্যান্ডি গোলাপি")
        else -> Pal(Color.parseColor("#607D8B"), Color.parseColor("#7C4DFF"), Color.parseColor("#FFC107"), Color.parseColor("#00E5FF"), "সমুদ্র নীল")
    }
    fun labelOf(name: String) = of(name).label
    val FACE_NAMES = listOf("globe", "avatar")
    fun faceLabel(n: String) = if (n == "avatar") "কার্টুন মুখ" else "ঘুরন্ত পৃথিবী"
}

/** পোশাকের প্রিসেট (রঙভিত্তিক, স্টাইলিশ নাম) */
object Outfits {
    data class P(val name: String, val color: Int)
    val FEMALE = listOf(
        P("মেরুন এমব্রয়ডারি", android.graphics.Color.parseColor("#7A1F3D")),
        P("রয়েল পার্পল গাউন", android.graphics.Color.parseColor("#6A3FA0")),
        P("ব্লাশ পিংক", android.graphics.Color.parseColor("#E85A8A")),
        P("এমারেল্ড গ্রিন", android.graphics.Color.parseColor("#1F8A6E")),
        P("স্কাই ব্লু", android.graphics.Color.parseColor("#3E8EDE")),
        P("গোল্ডেন ইয়েলো", android.graphics.Color.parseColor("#E0A83A"))
    )
    val MALE = listOf(
        P("নেভি ব্লেজার", android.graphics.Color.parseColor("#22304F")),
        P("চারকোল গ্রে", android.graphics.Color.parseColor("#3C3F45")),
        P("ক্লাসিক হোয়াইট শার্ট", android.graphics.Color.parseColor("#D8DEE8")),
        P("অলিভ ক্যাজুয়াল", android.graphics.Color.parseColor("#55653A")),
        P("ম্যারুন পোলো", android.graphics.Color.parseColor("#7A2B2B")),
        P("স্কাই ব্লু শার্ট", android.graphics.Color.parseColor("#3E7FBF"))
    )
}
