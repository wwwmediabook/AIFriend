package com.aifriend.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** ব্যবসা: দোকান (মার্কেটপ্লেস), পণ্য, সার্কুলার, অর্ডার ও স্বয়ংক্রিয় উত্তরের নিয়ন্ত্রণ */
class BizActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var sv: ScrollView
    private lateinit var box: LinearLayout
    private var screen = 0
    private var shopId = ""
    private var prodId = ""
    private var saveFn: (() -> Unit)? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun col(s: String) = Color.parseColor(s)
    private fun bg(c: String, r: Int = 20, stroke: String? = null) = GradientDrawable().apply {
        setColor(col(c)); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), col(stroke))
    }
    private fun grad(c1: String, c2: String) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(col(c1), col(c2))).apply { cornerRadius = dp(16).toFloat() }
    private fun ico(res: Int, tint: String = "#FFFFFF"): Drawable {
        val d = getDrawable(res)!!.mutate(); d.setTint(col(tint)); d.setBounds(0, 0, dp(22), dp(22)); return d
    }

    private fun card(title: String, res: Int): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(18)); background = bg("#1AFFFFFF", 24, "#22FFFFFF")
        }
        box.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        c.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(col("#8EE7FF")); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL; compoundDrawablePadding = dp(10)
            setCompoundDrawablesRelative(ico(res, "#8EE7FF"), null, null, null)
        })
        return c
    }

    private fun note(c: LinearLayout, t: String, color: String = "#9AA5C4"): TextView = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(col(color)); setPadding(0, dp(8), 0, 0); c.addView(this)
    }

    private fun field(c: LinearLayout, label: String, v: String, multi: Boolean = false, num: Boolean = false): EditText {
        c.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(col("#9AA5C4")); setPadding(0, dp(12), 0, dp(4)) })
        val e = EditText(this).apply {
            setText(v); setTextColor(Color.WHITE); textSize = 15f
            if (multi) { minLines = 4; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
            else setSingleLine()
            if (num) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            background = bg("#33000000", 14, "#33FFFFFF"); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        c.addView(e, LinearLayout.LayoutParams(-1, -2))
        return e
    }

    private fun check(c: LinearLayout, t: String, v: Boolean) = CheckBox(this).apply {
        text = t; isChecked = v; setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(6), dp(8), 0, dp(8)); c.addView(this)
    }

    private fun pill(c: LinearLayout, t: String, res: Int, c1: String = "#2B3A67", c2: String = "#3C4F8F", f: () -> Unit): Button =
        Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 14f
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(dp(18), 0, dp(18), 0); compoundDrawablePadding = dp(12)
            setCompoundDrawablesRelative(ico(res), null, null, null)
            background = grad(c1, c2); setOnClickListener { f() }
            c.addView(this, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        }

    private fun header(title: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(ImageButton(this).apply {
            setImageDrawable(ico(R.drawable.ic_back)); background = bg("#22FFFFFF", 24); setOnClickListener { back() }
        }, LinearLayout.LayoutParams(dp(46), dp(46)))
        row.addView(TextView(this).apply { text = title; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(14), 0, 0, 0) })
        box.addView(row)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("cfg", MODE_PRIVATE)
        sv = ScrollView(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(col("#050816"), col("#1A1245"))) }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(40)) }
        sv.addView(box)
        setContentView(sv)
        render()
    }

    override fun onResume() { super.onResume(); if (screen == 0) render() }

    private fun go(s: Int) { saveFn?.invoke(); saveFn = null; screen = s; render() }
    private fun back() { when (screen) { 2 -> go(1); 1, 3 -> go(0); else -> finish() } }
    override fun onBackPressed() { back() }

    private fun render() {
        box.removeAllViews(); saveFn = null
        when (screen) { 0 -> home(); 1 -> shopEditor(); 2 -> productEditor(); 3 -> orders() }
        sv.scrollTo(0, 0)
    }

    private fun appsOf(s: JSONObject): String {
        val l = ArrayList<String>()
        if (s.optBoolean("wa")) l.add("WhatsApp"); if (s.optBoolean("w4b")) l.add("WhatsApp Business"); if (s.optBoolean("msg")) l.add("Messenger")
        return if (l.isEmpty()) "কোনো অ্যাপে যুক্ত নয়" else l.joinToString(" • ")
    }

    private fun ago(ts: Long): String {
        val m = (System.currentTimeMillis() - ts) / 60000
        return if (m < 1) "এইমাত্র" else if (m < 60) "${m} মিনিট আগে" else if (m < 1440) "${m / 60} ঘণ্টা আগে" else "${m / 1440} দিন আগে"
    }

    // ---------------- হোম ----------------
    private fun home() {
        header("ব্যবসা")
        val mode = p.getString("bizmode", "off") ?: "off"
        val c1 = card("স্বয়ংক্রিয় উত্তর", R.drawable.ic_store)
        val access = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        note(c1, if (access) "নোটিফিকেশন অ্যাক্সেস: চালু ✅" else "নোটিফিকেশন অ্যাক্সেস: বন্ধ ❌ (নিচের বাটন চেপে AI Friend চালু করো)", if (access) "#5CFFB0" else "#FF8A8A")
        fun modeBtn(m: String, t: String, c1c: String, c2c: String) =
            pill(c1, (if (mode == m) "✔  " else "") + t, R.drawable.ic_shield, c1c, c2c) { p.edit().putString("bizmode", m).apply(); render() }
        modeBtn("off", "বন্ধ", "#455A64", "#78909C")
        modeBtn("approve", "অনুমোদন সহ (আমি 'পাঠাও' চাপলে যাবে)", "#00796B", "#26A69A")
        modeBtn("auto", "অটো (নিজে থেকে উত্তর পাঠাবে)", "#C62828", "#EF5350")
        note(c1, "প্রথমে 'অনুমোদন সহ' চালিয়ে দেখো উত্তরগুলো ঠিক আসছে কি না, তারপর অটো দাও।")
        pill(c1, "নোটিফিকেশন অ্যাক্সেস দাও", R.drawable.ic_lock) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        val cIntro = check(c1, "প্রথম মেসেজে জানাবে যে এটি এআই সহকারী", p.getBoolean("bizintro", true))
        val fIntro = field(c1, "পরিচয়ের বাক্য (ফাঁকা রাখলে স্বয়ংক্রিয়)", p.getString("bizintrotext", "") ?: "")
        val cPhoto = check(c1, "গ্রাহক ছবি চাইলে নিজে পাঠাবে (অ্যাক্সেসিবিলিটি ও START চালু লাগে, ফোনের স্ক্রিন কিছুক্ষণ দখল হয়)", p.getBoolean("bizphoto", false))
        pill(c1, "সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") {
            p.edit().putBoolean("bizintro", cIntro.isChecked).putString("bizintrotext", fIntro.text.toString().trim()).putBoolean("bizphoto", cPhoto.isChecked).apply()
            Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
        }

        val cc = card("সংযোগ অবস্থা (WhatsApp / Business / Messenger)", R.drawable.ic_shield)
        val live = p.getBoolean("biz_conn", false)
        note(cc, if (!access) "শোনার সার্ভিস: অনুমতি নেই ❌"
            else if (live) "শোনার সার্ভিস: চালু ও যুক্ত ✅"
            else "শোনার সার্ভিস: অনুমতি আছে, কিন্তু এখনো যুক্ত হয়নি। 'রিকানেক্ট' চাপো ⚠️",
            if (access && live) "#5CFFB0" else "#FFB74D")
        for ((k, nm, pkg) in listOf(Triple("wa", "WhatsApp", "com.whatsapp"), Triple("w4b", "WhatsApp Business", "com.whatsapp.w4b"), Triple("msg", "Messenger", "com.facebook.orca"))) {
            val installed = packageManager.getLaunchIntentForPackage(pkg) != null ||
                (k == "msg" && packageManager.getLaunchIntentForPackage("com.facebook.mlite") != null)
            val seen = p.getLong("seen_${k}", 0L); val noact = p.getLong("noact_${k}", 0L)
            val shopName = Biz.shopFor(this, k)?.optString("name")
            val state = when {
                !installed -> "ফোনে ইনস্টল নেই"
                seen > 0 -> "শেষ মেসেজ ধরা পড়েছে ${ago(seen)} ✅"
                noact > 0 -> "মেসেজ এসেছে কিন্তু নোটিফিকেশনে Reply বাটন নেই ⚠️"
                else -> "এখনো কোনো মেসেজ ধরা পড়েনি, অন্য ফোন থেকে মেসেজ পাঠিয়ে পরীক্ষা করো"
            }
            note(cc, "${nm}: ${state}\nযুক্ত দোকান: ${shopName ?: "নেই"}", "#FFFFFF")
            if (installed) pill(cc, "${nm}-এর নোটিফিকেশন সেটিংস", R.drawable.ic_tune) {
                try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)) } catch (_: Exception) {}
            }
        }
        pill(cc, "রিকানেক্ট করো", R.drawable.ic_bolt, "#00796B", "#26A69A") {
            try { android.service.notification.NotificationListenerService.requestRebind(android.content.ComponentName(this, BizListener::class.java)) } catch (_: Exception) {}
            Toast.makeText(this, "আবার যুক্ত করার অনুরোধ পাঠানো হয়েছে", Toast.LENGTH_SHORT).show(); render()
        }
        pill(cc, "ব্যাটারি অপটিমাইজেশন বন্ধ (সার্ভিস টিকে থাকতে)", R.drawable.ic_bolt) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        note(cc, "পরীক্ষা: অন্য নম্বর থেকে এই ফোনে 'হ্যালো' পাঠাও। ঠিক থাকলে এখানে 'মেসেজ ধরা পড়েছে' আসবে। Reply বাটন না এলে: ফোনের Settings, Notifications, Lock screen-এ 'সব কনটেন্ট দেখাও' দাও এবং ওই অ্যাপের মেসেজ নোটিফিকেশন চালু রাখো।")

        val c2 = card("মার্কেটপ্লেস: আমার দোকান", R.drawable.ic_store)
        val data = Biz.load(this); val shops = data.getJSONArray("shops")
        if (shops.length() == 0) note(c2, "এখনো কোনো দোকান নেই। নিচে নতুন দোকান বানাও।")
        for (i in 0 until shops.length()) {
            val s = shops.getJSONObject(i)
            note(c2, "${s.optString("name").ifBlank { "(নামহীন)" }}\n${appsOf(s)} • পণ্য ${s.optJSONArray("products")?.length() ?: 0}টি", "#FFFFFF")
            pill(c2, "দোকান সম্পাদনা", R.drawable.ic_tune) { shopId = s.optString("id"); go(1) }
            pill(c2, "মুছে ফেলো", R.drawable.ic_stop, "#C62828", "#EF5350") {
                val d = Biz.load(this); val a = d.getJSONArray("shops"); val keep = JSONArray()
                for (k in 0 until a.length()) if (a.getJSONObject(k).optString("id") != s.optString("id")) keep.put(a.getJSONObject(k))
                d.put("shops", keep); Biz.save(this, d); render()
            }
        }
        pill(c2, "নতুন দোকান", R.drawable.ic_play, "#00897B", "#26C6A8") {
            val d = Biz.load(this); val sh = JSONObject().put("id", Biz.newId()).put("name", "নতুন দোকান").put("products", JSONArray())
            d.getJSONArray("shops").put(sh); Biz.save(this, d); shopId = sh.optString("id"); go(1)
        }
        note(c2, "প্রতিটি দোকানকে WhatsApp, WhatsApp Business বা Messenger-এ যুক্ত করা যায়। ওই অ্যাপে মেসেজ এলে যুক্ত দোকানের তথ্য দিয়ে উত্তর যাবে।")

        val c3 = card("অর্ডার", R.drawable.ic_list)
        pill(c3, "অর্ডার দেখো (${data.getJSONArray("orders").length()})", R.drawable.ic_list, "#6A1B9A", "#AB47BC") { go(3) }

        val c4 = card("সাম্প্রতিক কার্যক্রম", R.drawable.ic_chart)
        val lg = data.getJSONArray("log"); val sb = StringBuilder()
        for (i in lg.length() - 1 downTo maxOf(0, lg.length() - 12)) sb.append(lg.getString(i)).append('\n')
        note(c4, if (sb.isEmpty()) "এখনো কিছু হয়নি" else sb.toString().trim())

        val c5 = card("জেনে রাখো", R.drawable.ic_shield)
        note(c5, "• এটা ফোনের নোটিফিকেশন পড়ে ও নোটিফিকেশনের Reply দিয়ে উত্তর পাঠায়, তাই অ্যাপ বদলালে বা ফোন বন্ধ থাকলে চলবে না।\n" +
            "• শুধু সরাসরি (১-টু-১) চ্যাটে কাজ করে, গ্রুপে নয়। একই চ্যাটে ১০ মিনিটে ৬টির বেশি উত্তর দেয় না।\n" +
            "• দাম: তালিকা-দাম থেকে শুরু, দরদামে ধাপে ধাপে কমে, কিন্তু আপনার দেওয়া সর্বনিম্ন দামের নিচে কোড নিজেই যেতে দেয় না। সর্বনিম্ন দাম এআই-কে কখনো জানানো হয় না।\n" +
            "• অর্ডার নিশ্চিত হয় শুধু নাম, ফোন, ঠিকানা ও দাম/স্টক মিললে। অস্পষ্ট বা অভিযোগের ক্ষেত্রে আপনাকে জানায়।\n" +
            "• এটা WhatsApp-এর অফিসিয়াল Business API নয়। বড় ব্যবসায় অফিসিয়াল API দরকার, যার জন্য আলাদা সার্ভার লাগে।\n" +
            "• গ্রাহকের মেসেজ উত্তর বানাতে Gemini-তে (Google) যায়।")
    }

    // ---------------- দোকান সম্পাদনা ----------------
    private fun shopEditor() {
        header("দোকান")
        val d = Biz.load(this); val s = Biz.find(d.getJSONArray("shops"), shopId) ?: run { go(0); return }
        val c1 = card("দোকানের তথ্য", R.drawable.ic_store)
        val fName = field(c1, "দোকানের নাম", s.optString("name"))
        val fAbout = field(c1, "দোকান সম্পর্কে বিস্তারিত (কী বিক্রি করো, কোথায়, বিশেষত্ব)", s.optString("about"), true)
        val fPolicy = field(c1, "সার্কুলার/নিয়ম: ডেলিভারি, পেমেন্ট (বিকাশ নম্বর), রিটার্ন, সময়, ঠিকানা", s.optString("policy"), true)
        val fTone = field(c1, "আপনার বিশেষ নির্দেশনা (কথার ধরন, যা বলা যাবে না ইত্যাদি)", s.optString("tone"), true)
        val fQuick = field(c1, "দ্রুত উত্তর (লাইন ধরে: কিওয়ার্ড১, কিওয়ার্ড২ => উত্তর)। মিললে এআই ছাড়াই এটা যাবে", s.optString("quick"), true)
        val fFrom = field(c1, "ব্যবসার সময় শুরু (যেমন 10:00)", s.optString("hoursFrom"))
        val fTo = field(c1, "ব্যবসার সময় শেষ (যেমন 22:00)", s.optString("hoursTo"))
        val cAway = check(c1, "সময়ের বাইরে এআই চুপ থাকবে, শুধু নিচের বার্তা দেবে", s.optBoolean("awayOn"))
        val fAway = field(c1, "সময়ের বাইরের বার্তা", s.optString("awayText"))
        val cWa = check(c1, "WhatsApp-এ এই দোকান কাজ করবে", s.optBoolean("wa"))
        val cW4b = check(c1, "WhatsApp Business-এ এই দোকান কাজ করবে", s.optBoolean("w4b"))
        val cMsg = check(c1, "Messenger-এ এই দোকান কাজ করবে", s.optBoolean("msg"))

        fun saveShop() {
            val dd = Biz.load(this); val ss = Biz.find(dd.getJSONArray("shops"), shopId) ?: return
            ss.put("name", fName.text.toString().trim()).put("about", fAbout.text.toString().trim())
                .put("policy", fPolicy.text.toString().trim()).put("tone", fTone.text.toString().trim())
                .put("quick", fQuick.text.toString().trim()).put("hoursFrom", fFrom.text.toString().trim()).put("hoursTo", fTo.text.toString().trim())
                .put("awayOn", cAway.isChecked).put("awayText", fAway.text.toString().trim())
            // এক অ্যাপে একটাই দোকান: অন্য দোকান থেকে সরিয়ে দেওয়া
            val arr = dd.getJSONArray("shops")
            for ((k, on) in listOf("wa" to cWa.isChecked, "w4b" to cW4b.isChecked, "msg" to cMsg.isChecked)) {
                ss.put(k, on)
                if (on) for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.optString("id") != shopId) o.put(k, false) }
            }
            Biz.save(this, dd)
        }
        saveFn = { saveShop() }

        val c2 = card("পণ্য", R.drawable.ic_list)
        val ps = s.optJSONArray("products") ?: JSONArray()
        if (ps.length() == 0) note(c2, "এখনো কোনো পণ্য নেই।")
        for (i in 0 until ps.length()) {
            val pr = ps.getJSONObject(i)
            note(c2, "${pr.optString("name").ifBlank { "(নামহীন)" }} • দাম ${Biz.fmt(pr.optDouble("price"))} • সর্বনিম্ন ${Biz.fmt(pr.optDouble("min", pr.optDouble("price")))}" +
                (if (pr.optString("img").isNotEmpty()) " • ছবি আছে" else ""), "#FFFFFF")
            pill(c2, "সম্পাদনা", R.drawable.ic_tune) { prodId = pr.optString("id"); go(2) }
        }
        pill(c2, "নতুন পণ্য", R.drawable.ic_play, "#00897B", "#26C6A8") {
            saveShop()
            val dd = Biz.load(this); val ss = Biz.find(dd.getJSONArray("shops"), shopId)
            val np = JSONObject().put("id", Biz.newId()).put("name", "").put("price", 0).put("min", 0).put("stock", -1).put("info", "")
            ss?.optJSONArray("products")?.put(np); Biz.save(this, dd); prodId = np.optString("id"); saveFn = null; screen = 2; render()
        }
        pill(box, "দোকান সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") { saveShop(); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }
    }

    // ---------------- পণ্য সম্পাদনা ----------------
    private fun productEditor() {
        header("পণ্য")
        val d = Biz.load(this); val s = Biz.find(d.getJSONArray("shops"), shopId)
        val pr = Biz.find(s?.optJSONArray("products"), prodId) ?: run { go(1); return }
        val c = card("পণ্যের তথ্য", R.drawable.ic_list)
        val fN = field(c, "পণ্যের নাম", pr.optString("name"))
        val fP = field(c, "দাম (তালিকা)", if (pr.optDouble("price") == 0.0) "" else Biz.fmt(pr.optDouble("price")), false, true)
        val fM = field(c, "সর্বনিম্ন দাম (এর নিচে কখনো যাবে না, গ্রাহককে বলা হয় না)", if (pr.optDouble("min") == 0.0) "" else Biz.fmt(pr.optDouble("min")), false, true)
        val fS = field(c, "স্টক (ফাঁকা বা -1 মানে সীমাহীন)", if (pr.optInt("stock", -1) < 0) "" else pr.optInt("stock").toString(), false, true)
        val fI = field(c, "বিবরণ (সাইজ, রং, উপাদান, গ্যারান্টি ইত্যাদি)", pr.optString("info"), true)
        val img = pr.optString("img")
        if (img.isNotEmpty()) {
            val bm = BitmapFactory.decodeFile(File(Biz.imgDir(this), img).absolutePath)
            if (bm != null) c.addView(ImageView(this).apply { setImageBitmap(bm); adjustViewBounds = true; maxHeight = dp(220); setPadding(0, dp(12), 0, 0) })
        }
        pill(c, if (img.isEmpty()) "ছবি যোগ করো" else "ছবি বদলাও", R.drawable.ic_play, "#6A1B9A", "#AB47BC") {
            saveProduct(fN, fP, fM, fS, fI)
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 11)
        }
        saveFn = { saveProduct(fN, fP, fM, fS, fI) }
        pill(box, "পণ্য সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") { saveProduct(fN, fP, fM, fS, fI); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }
        pill(box, "পণ্য মুছো", R.drawable.ic_stop, "#C62828", "#EF5350") {
            val dd = Biz.load(this); val ss = Biz.find(dd.getJSONArray("shops"), shopId); val a = ss?.optJSONArray("products")
            if (a != null) { val keep = JSONArray(); for (i in 0 until a.length()) if (a.getJSONObject(i).optString("id") != prodId) keep.put(a.getJSONObject(i)); ss.put("products", keep) }
            Biz.save(this, dd); saveFn = null; go(1)
        }
    }

    private fun saveProduct(n: EditText, pr: EditText, mn: EditText, st: EditText, inf: EditText) {
        val d = Biz.load(this); val s = Biz.find(d.getJSONArray("shops"), shopId)
        val o = Biz.find(s?.optJSONArray("products"), prodId) ?: return
        val price = pr.text.toString().toDoubleOrNull() ?: 0.0
        val min = (mn.text.toString().toDoubleOrNull() ?: price).coerceAtMost(price)
        o.put("name", n.text.toString().trim()).put("price", price).put("min", min)
            .put("stock", st.text.toString().toIntOrNull() ?: -1).put("info", inf.text.toString().trim())
        Biz.save(this, d)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 11 || res != RESULT_OK || data?.data == null) return
        try {
            val bm0 = contentResolver.openInputStream(data.data!!)?.use { BitmapFactory.decodeStream(it) } ?: return
            val sc = 1024f / maxOf(bm0.width, bm0.height)
            val bm: Bitmap = if (sc < 1f) Bitmap.createScaledBitmap(bm0, (bm0.width * sc).toInt(), (bm0.height * sc).toInt(), true) else bm0
            val name = "p_${prodId}.jpg"
            File(Biz.imgDir(this), name).outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            val d = Biz.load(this); val s = Biz.find(d.getJSONArray("shops"), shopId)
            Biz.find(s?.optJSONArray("products"), prodId)?.put("img", name); Biz.save(this, d)
            render()
        } catch (e: Exception) { Toast.makeText(this, "ছবি নেওয়া যায়নি", Toast.LENGTH_SHORT).show() }
    }

    // ---------------- অর্ডার ----------------
    private fun orders() {
        header("অর্ডার")
        val d = Biz.load(this); val a = d.getJSONArray("orders")
        if (a.length() == 0) note(box, "এখনো কোনো অর্ডার নেই।")
        val statuses = listOf("নতুন", "কনফার্ম", "পাঠানো হয়েছে", "ডেলিভারি হয়েছে", "বাতিল")
        for (i in a.length() - 1 downTo 0) {
            val o = a.getJSONObject(i)
            val whenTxt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(o.optLong("ts")))
            val c = card("${whenTxt} • ${o.optString("who")}", R.drawable.ic_store)
            val items = o.optJSONArray("items"); val sb = StringBuilder()
            if (items != null) for (k in 0 until items.length()) { val r = items.getJSONObject(k); sb.append("${r.optString("name")} × ${r.optInt("qty")} = ${Biz.fmt(r.optDouble("price") * r.optInt("qty"))}\n") }
            note(c, sb.toString().trim() + "\nমোট: ${Biz.fmt(o.optDouble("total"))} টাকা", "#FFFFFF")
            note(c, "গ্রাহক: ${o.optString("customer")}\nফোন: ${o.optString("phone")}\nঠিকানা: ${o.optString("address")}\nদোকান: ${o.optString("shop")} • ${o.optString("app")}")
            pill(c, "অবস্থা: ${o.optString("status")} (বদলাও)", R.drawable.ic_tune) {
                val dd = Biz.load(this); val oo = Biz.find(dd.getJSONArray("orders"), o.optString("id"))
                if (oo != null) { oo.put("status", statuses[(statuses.indexOf(oo.optString("status")) + 1).mod(statuses.size)]); Biz.save(this, dd) }
                render()
            }
        }
        if (a.length() > 0) pill(box, "সব অর্ডার মুছে ফেলো", R.drawable.ic_stop, "#C62828", "#EF5350") {
            val dd = Biz.load(this); dd.put("orders", JSONArray()); Biz.save(this, dd); render()
        }
    }
}
