package com.aifriend.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** state: 0 idle, 1 listening, 2 thinking, 3 speaking */
class Orb(c: Context) : View(c) {
    var state = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { t = it.animatedValue as Float; invalidate() }; start()
        }
    }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = width * 0.28f
        val col = when (state) { 3 -> 0xFF00E5FF.toInt(); 2 -> 0xFFFFC107.toInt(); 1 -> 0xFF7C4DFF.toInt(); else -> 0xFF607D8B.toInt() }
        val speed = if (state == 3) 2 else 1
        val pulse = 0.5f + 0.5f * sin(t * 6.283f * speed)
        val g = r * (1.35f + 0.35f * pulse)
        p.shader = RadialGradient(cx, cy, g, intArrayOf((col and 0xFFFFFF) or (0xB0 shl 24), col and 0xFFFFFF), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, g, p)
        p.shader = RadialGradient(cx - r / 3, cy - r / 3, r * 1.5f, intArrayOf(0xFFFFFFFF.toInt(), col, 0xFF101030.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p); p.shader = null
        p.color = 0xFF0B0F1E.toInt()
        val blink = if (t > 0.92f) 0.15f else 1f
        for (s in listOf(-1, 1))
            c.drawOval(cx + s * r * 0.38f - r * 0.1f, cy - r * 0.2f - r * 0.16f * blink, cx + s * r * 0.38f + r * 0.1f, cy - r * 0.2f + r * 0.16f * blink, p)
        if (state == 3) {
            val o = r * (0.08f + 0.22f * abs(sin(t * 6.283f * 4)))
            c.drawOval(cx - r * 0.22f, cy + r * 0.28f - o / 2, cx + r * 0.22f, cy + r * 0.28f + o / 2, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.07f; p.strokeCap = Paint.Cap.ROUND
            c.drawArc(cx - r * 0.25f, cy + r * 0.05f, cx + r * 0.25f, cy + r * 0.45f, 20f, 140f, false, p)
            p.style = Paint.Style.FILL
        }
    }
}
