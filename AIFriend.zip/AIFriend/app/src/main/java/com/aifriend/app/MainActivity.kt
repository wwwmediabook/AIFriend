package com.aifriend.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import org.json.JSONArray

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var p: SharedPreferences
    private lateinit var orb: Orb
    private lateinit var chip: TextView
    private lateinit var status: TextView
    private lateinit var fKey: EditText
    private lateinit var fModel: EditText
    private lateinit var fName: EditText
    private lateinit var fLang: EditText
    private lateinit var fVoice: EditText
    private lateinit var fTts: EditText
    private lateinit var cAlways: CheckBox
    private lateinit var cFlash: CheckBox
    private lateinit var cMute: CheckBox

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun col(s: String) = Color.parseColor(s)
    private fun bg(c: String, r: Int = 20, stroke: String? = null) = GradientDrawable().apply {
        setColor(col(c)); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), col(stroke))
    }

    private fun card(root: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(18)); background = bg("#1AFFFFFF", 24, "#22FFFFFF")
        }
        root.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        c.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(col("#8EE7FF")); typeface = Typeface.DEFAULT_BOLD })
        return c
    }

    private fun field(c: LinearLayout, label: String, v: String): EditText {
        c.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(col("#9AA5C4")); setPadding(0, dp(12), 0, dp(4)) })
        val e = EditText(this).apply {
            setText(v); setTextColor(Color.WHITE); textSize = 15f; setSingleLine()
            background = bg("#33000000", 14, "#33FFFFFF"); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        c.addView(e, LinearLayout.LayoutParams(-1, -2))
        return e
    }

    private fun check(c: LinearLayout, t: String, v: Boolean) = CheckBox(this).apply {
        text = t; isChecked = v; setTextColor(Color.WHITE); textSize = 14f; c.addView(this)
    }

    private fun btn(c: LinearLayout, t: String, color: String = "#2B3A67", f: () -> Unit) =
        Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 14f; background = bg(color, 16)
            setOnClickListener { f() }
            c.addView(this, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("cfg", MODE_PRIVATE)
        if ((p.getString("model", "") ?: "").startsWith("gemini-2")) p.edit().putString("model", Gemini.DEF_MODEL).apply()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(40), dp(18), dp(40)) }
        val sv = ScrollView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(col("#070B1A"), col("#1A1245")))
            addView(root)
        }
        setContentView(sv)

        orb = Orb(this)
        root.addView(orb, LinearLayout.LayoutParams(dp(180), dp(180)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(TextView(this).apply { text = "AI Friend"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "তোমার আপন কণ্ঠের বন্ধু"; textSize = 14f; setTextColor(col("#9AA5C4")); gravity = Gravity.CENTER })
        chip = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(14), dp(6), dp(14), dp(6)); background = bg("#22FFFFFF", 30) }
        root.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10) })
        status = TextView(this).apply { textSize = 13f; setTextColor(col("#C9D2F0")); gravity = Gravity.CENTER; setPadding(dp(8), dp(10), dp(8), 0) }
        root.addView(status)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        row.addView(Button(this).apply {
            text = "▶  START"; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            background = bg("#00A686", 18); setOnClickListener { startAssistant() }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        row.addView(Button(this).apply {
            text = "⏹  STOP"; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            background = bg("#B3394A", 18); setOnClickListener { stopService(Intent(this@MainActivity, AssistantService::class.java)) }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })

        val c1 = card(root, "⚙️  সেটিংস")
        fKey = field(c1, "Gemini API Key", p.getString("key", "") ?: "")
        fName = field(c1, "ডাকনাম (কমা দিয়ে একাধিক, যেমন: মায়া, maya)", p.getString("name", "মায়া") ?: "মায়া")
        fModel = field(c1, "এআই মডেল", p.getString("model", Gemini.DEF_MODEL) ?: Gemini.DEF_MODEL)
        fVoice = field(c1, "মেয়ের কণ্ঠ (Achernar, Vindemiatrix, Sulafat, Leda, Kore)", p.getString("ttsVoice", Gemini.DEF_VOICE) ?: Gemini.DEF_VOICE)
        fTts = field(c1, "কণ্ঠের মডেল", p.getString("ttsModel", Gemini.DEF_TTS) ?: Gemini.DEF_TTS)
        fLang = field(c1, "ভাষা কোড (বাংলা: bn-BD)", p.getString("lang", "bn-BD") ?: "bn-BD")
        cAlways = check(c1, "নাম ছাড়াই সব কথার উত্তর দেবে", p.getBoolean("always", false))
        cMute = check(c1, "শোনার বিপ শব্দ বন্ধ (শোনার সময় মিডিয়া ভলিউম মিউট থাকে)", p.getBoolean("mute", true))
        cFlash = check(c1, "কথা বলার সময় ফোনের ফ্ল্যাশ লাইট জ্বলবে", p.getBoolean("flash", true))
        btn(c1, "💾  সেভ করো", "#3D5AFE") { save(); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }
        btn(c1, "🔊  টেস্ট (এআই + মেয়ের কণ্ঠ)", "#7C4DFF") { test() }

        val c2 = card(root, "🔐  একবারের সেটআপ")
        btn(c2, "১. মাইক, ক্যামেরা, কল, কন্টাক্ট পারমিশন") {
            val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(l.toTypedArray(), 1)
        }
        btn(c2, "২. অন্য অ্যাপের উপরে দেখানো") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn(c2, "৩. ব্যাটারি অপটিমাইজেশন বন্ধ") { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }

        val c3 = card(root, "🆓  ফ্রি API Key কোথায় পাবে")
        c3.addView(TextView(this).apply {
            text = "aistudio.google.com/apikey এ Google অ্যাকাউন্ট দিয়ে ঢুকে Create API key চাপো। ক্রেডিট কার্ড লাগে না। কী কপি করে উপরে পেস্ট করো।"
            textSize = 13f; setTextColor(col("#C9D2F0")); setPadding(0, dp(8), 0, 0)
        })
        btn(c3, "API Key পেজ খোলো") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) }
    }

    private fun save() {
        p.edit().putString("key", fKey.text.toString().trim()).putString("model", fModel.text.toString().trim())
            .putString("name", fName.text.toString().trim()).putString("lang", fLang.text.toString().trim())
            .putString("ttsVoice", fVoice.text.toString().trim()).putString("ttsModel", fTts.text.toString().trim())
            .putBoolean("always", cAlways.isChecked).putBoolean("flash", cFlash.isChecked).putBoolean("mute", cMute.isChecked).apply()
    }

    private fun startAssistant() {
        save()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে ২ নম্বর অনুমতি দাও", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "আগে ১ নম্বর পারমিশন দাও", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        startForegroundService(Intent(this, AssistantService::class.java))
    }

    private fun test() {
        save(); status.text = "টেস্ট চলছে…"
        val key = fKey.text.toString().trim(); val model = fModel.text.toString().trim()
        val tm = fTts.text.toString().trim(); val voice = fVoice.text.toString().trim(); val name = Gemini.first(fName.text.toString())
        Thread {
            try {
                val j = Gemini.chat(key, model, Gemini.systemPrompt(name), JSONArray(), "নিজের পরিচয় এক বাক্যে দাও")
                val say = j.optString("say", "হ্যালো")
                runOnUiThread { status.text = "✅ এআই ঠিক আছে: ${say}" }
                val pcm = Gemini.tts(key, tm, voice, say)
                runOnUiThread { status.text = "✅ এআই ও মেয়ের কণ্ঠ দুটোই ঠিক আছে" }
                Gemini.play(pcm)
            } catch (e: Exception) { runOnUiThread { status.text = "❌ ${e.message}" } }
        }.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            val running = p.getBoolean("running", false)
            orb.state = if (running) p.getInt("state", 0) else 0
            chip.text = if (running) "●  চালু আছে" else "○  বন্ধ আছে"
            chip.setTextColor(col(if (running) "#5CFFB0" else "#FF8A8A"))
            if (running) status.text = p.getString("status", "") ?: ""
            h.postDelayed(this, 800)
        }
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
