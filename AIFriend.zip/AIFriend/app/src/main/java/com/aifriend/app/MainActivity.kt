package com.aifriend.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var p: SharedPreferences
    private lateinit var globe: Globe
    private lateinit var avatar: Avatar
    private lateinit var faceHolder: FrameLayout
    private lateinit var chip: TextView
    private lateinit var status: TextView
    private lateinit var big: Button
    private lateinit var home: LinearLayout
    private lateinit var settingsView: ScrollView
    private lateinit var callsView: ScrollView
    private lateinit var wardrobeView: ScrollView
    private lateinit var settingsBox: LinearLayout
    private lateinit var callsBox: LinearLayout
    private lateinit var wardrobeBox: LinearLayout
    private lateinit var bGender: Button
    private lateinit var bFace: Button
    private lateinit var bTheme: Button
    private lateinit var statsTv: TextView
    private lateinit var logTv: TextView
    private lateinit var fKey: EditText
    private lateinit var fModel: EditText
    private lateinit var fName: EditText
    private lateinit var fOwner: EditText
    private lateinit var fTts: EditText
    private lateinit var cAlways: CheckBox
    private lateinit var cFlash: CheckBox
    private lateinit var cCall: CheckBox
    private lateinit var cPhone: CheckBox
    private lateinit var cFb: CheckBox
    private lateinit var cConfirm: CheckBox
    private lateinit var fVt: EditText
    private lateinit var cCam: CheckBox
    private lateinit var fCamEvery: EditText
    private lateinit var cFree: CheckBox
    private lateinit var scanPanel: FrameLayout
    private lateinit var scanView: ScanView
    private lateinit var scanRes: ScrollView
    private lateinit var scanBox: LinearLayout
    private var scanning = false
    private var gMode = "auto"
    private var theme = "ocean"
    private var faceStyle = "globe"
    private var panel = 0
    private var lastRun: Boolean? = null
    private var player: MediaPlayer? = null
    private var uploadGenderIsMale = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun col(s: String) = Color.parseColor(s)
    private fun bg(c: String, r: Int = 20, stroke: String? = null) = GradientDrawable().apply {
        setColor(col(c)); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), col(stroke))
    }
    private fun grad(c1: String, c2: String, r: Int = 16) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(col(c1), col(c2))).apply { cornerRadius = dp(r).toFloat() }
    private fun ico(res: Int, tint: String = "#FFFFFF"): Drawable {
        val d = getDrawable(res)!!.mutate(); d.setTint(col(tint)); d.setBounds(0, 0, dp(22), dp(22)); return d
    }

    private fun card(root: LinearLayout, title: String, res: Int): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(18)); background = bg("#1AFFFFFF", 24, "#22FFFFFF")
        }
        root.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        c.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(col("#8EE7FF")); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL; compoundDrawablePadding = dp(10)
            setCompoundDrawablesRelative(ico(res, "#8EE7FF"), null, null, null)
        })
        return c
    }

    private fun note(c: LinearLayout, t: String): TextView = TextView(this).apply {
        text = t; textSize = 12.5f; setTextColor(col("#9AA5C4")); setPadding(0, dp(8), 0, 0); c.addView(this)
    }

    private fun field(c: LinearLayout, label: String, v: String): EditText {
        c.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(col("#9AA5C4")); setPadding(0, dp(12), 0, dp(4)) })
        val e = EditText(this).apply {
            setText(v); setTextColor(Color.WHITE); textSize = 15f; setSingleLine()
            background = bg("#33000000", 14, "#33FFFFFF"); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        c.addView(e, LinearLayout.LayoutParams(-1, -2))
        return e
    }

    private fun check(c: LinearLayout, t: String, v: Boolean) = CheckBox(this).apply {
        text = t; isChecked = v; setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(6), dp(8), 0, dp(8)); c.addView(this)
    }

    private fun pill(c: LinearLayout, t: String, res: Int, c1: String = "#2B3A67", c2: String = "#3C4F8F", f: () -> Unit): Button =
        Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 14f
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(dp(18), 0, dp(18), 0); compoundDrawablePadding = dp(12)
            setCompoundDrawablesRelative(ico(res), null, null, null)
            background = grad(c1, c2); setOnClickListener { f() }
            c.addView(this, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        }

    private fun header(box: LinearLayout, title: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(ImageButton(this).apply {
            setImageDrawable(ico(R.drawable.ic_back)); background = bg("#22FFFFFF", 24); setOnClickListener { showPanel(0) }
        }, LinearLayout.LayoutParams(dp(46), dp(46)))
        row.addView(TextView(this).apply { text = title; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(14), 0, 0, 0) })
        box.addView(row)
    }

    private fun gLabel() = when (gMode) { "female" -> "কণ্ঠ: মেয়ে"; "male" -> "কণ্ঠ: ছেলে"; else -> "কণ্ঠ: নাম দেখে অটো" }
    private fun voiceF() = Gemini.validVoice(p.getString("voiceF", Gemini.DEF_VOICE_F) ?: "", true)
    private fun voiceM() = Gemini.validVoice(p.getString("voiceM", Gemini.DEF_VOICE_M) ?: "", false)

    private fun resolveFemale(): Boolean {
        val nm = p.getString("name", "অপর্ণা, aparna") ?: ""
        return when (p.getString("gender", "auto")) {
            "female" -> true
            "male" -> false
            else -> (p.getString("g_" + nm, null) ?: Gemini.guessGender(nm)) == "female"
        }
    }

    private fun applyFaceToViews() {
        val female = resolveFemale()
        globe.theme = theme
        avatar.theme = theme; avatar.male = !female
        avatar.outfitColor = currentOutfitColor(female)
        faceHolder.removeAllViews()
        if (faceStyle == "avatar") faceHolder.addView(avatar, FrameLayout.LayoutParams(-1, -1))
        else faceHolder.addView(globe, FrameLayout.LayoutParams(-1, -1))
    }

    private fun outfitsArr(female: Boolean): JSONArray =
        try { JSONArray(p.getString(if (female) "outfitsF" else "outfitsM", "[]")) } catch (e: Exception) { JSONArray() }

    private fun currentOutfitColor(female: Boolean): Int? {
        val idx = p.getInt(if (female) "outfitIdxF" else "outfitIdxM", 0)
        val presets = if (female) Outfits.FEMALE else Outfits.MALE
        val uploads = outfitsArr(female)
        return if (idx < presets.size) presets[idx].color
        else uploads.optJSONObject(idx - presets.size)?.optInt("color")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("cfg", MODE_PRIVATE)
        Gemini.init(this)
        if (p.getString("name", null) == "মায়া") p.edit().putString("name", "অপর্ণা, aparna").apply()
        if (p.getString("owner", null) == "মালিক") p.edit().putString("owner", "মৃদুল").apply()
        if ((p.getString("model", "") ?: "").startsWith("gemini-2")) p.edit().putString("model", Gemini.DEF_MODEL).apply()
        gMode = p.getString("gender", "auto") ?: "auto"
        theme = p.getString("theme", "ocean") ?: "ocean"
        faceStyle = p.getString("faceStyle", "globe") ?: "globe"

        val frame = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(col("#050816"), col("#1A1245")))
        }
        setContentView(frame)

        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(28)) }
        frame.addView(home, FrameLayout.LayoutParams(-1, -1))
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        home.addView(top, LinearLayout.LayoutParams(-1, -2))
        top.addView(TextView(this).apply { text = "AI Friend"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        chip = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(14), dp(6), dp(14), dp(6)); background = bg("#22FFFFFF", 30) }
        top.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
        top.addView(ImageButton(this).apply {
            setImageDrawable(ico(R.drawable.ic_store)); background = bg("#22FFB300", 24); setOnClickListener { startActivity(Intent(this@MainActivity, BizActivity::class.java)) }
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
        top.addView(ImageButton(this).apply {
            setImageDrawable(ico(R.drawable.ic_shield)); background = bg("#2200FF88", 24); setOnClickListener { startScan() }
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
        top.addView(ImageButton(this).apply {
            setImageDrawable(ico(R.drawable.ic_tune)); background = bg("#22FFFFFF", 24); setOnClickListener { showPanel(1) }
        }, LinearLayout.LayoutParams(dp(46), dp(46)))

        globe = Globe(this)
        avatar = Avatar(this)
        faceHolder = FrameLayout(this)
        home.addView(faceHolder, LinearLayout.LayoutParams(-1, 0, 1f))
        applyFaceToViews()

        val hr = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(6)); background = bg("#1AFFFFFF", 24, "#22FFFFFF")
        }
        val heartView = HeartView(this)
        hr.addView(heartView, LinearLayout.LayoutParams(dp(56), dp(56)))
        val heartTv = TextView(this).apply { textSize = 13.5f; setTextColor(Color.WHITE); setPadding(dp(12), 0, 0, 0) }
        hr.addView(heartTv, LinearLayout.LayoutParams(0, -2, 1f))
        home.addView(hr, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        status = TextView(this).apply { textSize = 13.5f; setTextColor(col("#C9D2F0")); gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(12)); minLines = 2 }
        home.addView(status, LinearLayout.LayoutParams(-1, -2))
        big = Button(this).apply {
            isAllCaps = false; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; compoundDrawablePadding = dp(10); setPadding(dp(24), 0, dp(24), 0)
            setOnClickListener { if (p.getBoolean("running", false)) stopService(Intent(this@MainActivity, AssistantService::class.java)) else startAssistant() }
        }
        home.addView(big, LinearLayout.LayoutParams(-1, dp(60)))

        settingsView = ScrollView(this).apply { visibility = View.GONE }
        settingsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(40)) }
        settingsView.addView(settingsBox)
        frame.addView(settingsView, FrameLayout.LayoutParams(-1, -1))
        buildSettings(settingsBox)

        callsView = ScrollView(this).apply { visibility = View.GONE }
        callsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(40)) }
        callsView.addView(callsBox)
        frame.addView(callsView, FrameLayout.LayoutParams(-1, -1))

        wardrobeView = ScrollView(this).apply { visibility = View.GONE }
        wardrobeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(40)) }
        wardrobeView.addView(wardrobeBox)
        frame.addView(wardrobeView, FrameLayout.LayoutParams(-1, -1))

        scanPanel = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK) }
        scanView = ScanView(this)
        scanPanel.addView(scanView, FrameLayout.LayoutParams(-1, -1))
        scanRes = ScrollView(this).apply { visibility = View.GONE; setBackgroundColor(col("#F0020A06")) }
        scanBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(40)) }
        scanRes.addView(scanBox)
        scanPanel.addView(scanRes, FrameLayout.LayoutParams(-1, -1))
        frame.addView(scanPanel, FrameLayout.LayoutParams(-1, -1))
        if (intent?.getBooleanExtra("scan", false) == true) h.post { startScan() }

        heartTickRef = { running ->
            heartView.emotion = Heart.mood(this); heartView.intensity = Heart.intensity(this)
            heartTv.text = Heart.labelBn(heartView.emotion) + "  •  সম্পর্কের গভীরতা " + Heart.bond(this) + "%"
        }
    }

    private var heartTickRef: (Boolean) -> Unit = {}

    private fun buildSettings(root: LinearLayout) {
        header(root, "সেটিংস")

        val c1 = card(root, "এআই কানেকশন", R.drawable.ic_key)
        fKey = field(c1, "Gemini API Key", p.getString("key", "") ?: "")
        fModel = field(c1, "এআই মডেল", p.getString("model", Gemini.DEF_MODEL) ?: Gemini.DEF_MODEL)
        pill(c1, "টেস্ট করো (এআই + কণ্ঠ)", R.drawable.ic_bolt, "#7C4DFF", "#B388FF") { test() }

        val c2 = card(root, "পরিচয় ও কণ্ঠ", R.drawable.ic_person)
        fName = field(c2, "ডাকনাম (কমা দিয়ে একাধিক, যেমন: অপর্ণা, aparna)", p.getString("name", "অপর্ণা, aparna") ?: "অপর্ণা, aparna")
        fOwner = field(c2, "আপনার নাম (কলের সময় ব্যবহার হবে)", p.getString("owner", "মৃদুল") ?: "মৃদুল")
        bGender = pill(c2, gLabel(), R.drawable.ic_tune, "#00897B", "#26C6A8") {
            gMode = when (gMode) { "auto" -> "female"; "female" -> "male"; else -> "auto" }
            bGender.text = gLabel(); p.edit().putString("gender", gMode).apply()
            applyFaceToViews()
            if (p.getBoolean("running", false)) Toast.makeText(this, "সেভ হয়েছে, এখনই কার্যকর", Toast.LENGTH_SHORT).show()
        }
        bFace = pill(c2, "মুখের ধরন: ${Theme.faceLabel(faceStyle)}", R.drawable.ic_shield, "#5E35B1", "#7E57C2") {
            faceStyle = if (faceStyle == "avatar") "globe" else "avatar"
            bFace.text = "মুখের ধরন: ${Theme.faceLabel(faceStyle)}"
            p.edit().putString("faceStyle", faceStyle).apply(); applyFaceToViews()
        }
        bTheme = pill(c2, "রূপ/রং: ${Theme.labelOf(theme)}", R.drawable.ic_shield, "#5E35B1", "#7E57C2") {
            val i = (Theme.NAMES.indexOf(theme) + 1) % Theme.NAMES.size
            theme = Theme.NAMES[i]; bTheme.text = "রূপ/রং: ${Theme.labelOf(theme)}"
            p.edit().putString("theme", theme).apply(); applyFaceToViews()
            if (p.getBoolean("running", false)) sendBroadcast(Intent("com.aifriend.app.THEME").setPackage(packageName).putExtra("theme", theme))
        }
        pill(c2, "পোশাক/ওয়্যারড্রোব", R.drawable.ic_person, "#AD1457", "#EC407A") { showPanel(4) }
        fVoiceCard(c2)
        fTts = field(c2, "কণ্ঠের মডেল", p.getString("ttsModel", Gemini.DEF_TTS) ?: Gemini.DEF_TTS)
        note(c2, "ব্যবহারকারী যে ভাষায় কথা বলবে, উত্তরও সেই ভাষাতেই আসবে।")
        cAlways = check(c2, "নাম ছাড়াই সব কথার উত্তর দেবে", p.getBoolean("always", false))
        cFlash = check(c2, "কথা বলার সময় ফোনের ফ্ল্যাশ জ্বলবে", p.getBoolean("flash", true))
        cPhone = check(c2, "শুধু ফোনের নিজস্ব কণ্ঠ (লিমিট লাগে না)", p.getBoolean("phonevoice", false))
        cFb = check(c2, "Gemini কণ্ঠ ব্যর্থ হলে ফোনের কণ্ঠে বলবে", p.getBoolean("fb", true))
        cConfirm = check(c2, "পোস্ট/মেসেজ/মেইল/ইনস্টল/ডিলিটের আগে আমার অনুমতি নেবে", p.getBoolean("confirm", true))
        pill(c2, "সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") { save(); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }

        val ch = card(root, "হৃদয় ও ছবি", R.drawable.ic_heart)
        val cHeart = check(ch, "ভার্চুয়াল হৃদয় চালু (কষ্ট, ভালোবাসা বুঝে যত্ন নেবে)", p.getBoolean("heart", true))
        val cAuto = check(ch, "মন বুঝে নিজে থেকে ছবি এঁকে দেবে", p.getBoolean("autoimage", true))
        val fTrusted = field(ch, "বিশ্বস্ত ব্যক্তি (নাম বা নম্বর, কষ্টে কল করার প্রস্তাব দেবে)", p.getString("trusted", "") ?: "")
        val fImg = field(ch, "ছবির মডেল", p.getString("imgModel", Gemini.DEF_IMG) ?: Gemini.DEF_IMG)
        cCam = check(ch, "সামনের ক্যামেরায় মাঝে মাঝে আমার মন দেখবে (ফোন ব্যবহারের সময়)", p.getBoolean("camMood", false))
        fCamEvery = field(ch, "মন দেখার বিরতি (মিনিট)", p.getString("camEvery", "30") ?: "30")
        cFree = check(ch, "Gemini ছবি না চললে বিনামূল্যের বিকল্প সার্ভিস (Pollinations) ব্যবহার", p.getBoolean("freeimg", true))
        pill(ch, "এখনই আমাকে দেখে মন বোঝো", R.drawable.ic_heart, "#AD1457", "#EC407A") {
            saveHeart(cHeart, cAuto, fTrusted, fImg)
            if (p.getBoolean("running", false)) startService(Intent(this, AssistantService::class.java).setAction("MOOD"))
            else Toast.makeText(this, "আগে চালু করো", Toast.LENGTH_SHORT).show()
        }
        pill(ch, "সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") { saveHeart(cHeart, cAuto, fTrusted, fImg); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }

        val c3 = card(root, "ইনকামিং কল", R.drawable.ic_phone)
        cCall = check(c3, "কল এলে আগে নিজে রিসিভ করবে", p.getBoolean("callmode", false))
        note(c3, "রিসিভ করে স্পিকারে জানায় যে কথোপকথন সংরক্ষণ হচ্ছে, কলারকে জিজ্ঞেস করে, তারপর আপনাকে জানায়। সব নম্বরের জন্য কাজ করে, অ্যাপ চালু (START) থাকতে হবে। কথাগুলো অ্যাপের ভেতরে সংরক্ষিত থাকে।")
        pill(c3, "কল রেকর্ড দেখো", R.drawable.ic_list, "#6A1B9A", "#AB47BC") { showPanel(2) }
        pill(c3, "সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") { save(); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }

        val c4 = card(root, "একবারের সেটআপ", R.drawable.ic_lock)
        pill(c4, "১. মাইক, কল, কন্টাক্ট, ক্যামেরা পারমিশন", R.drawable.ic_mic) {
            val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_CALL_LOG)
            if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(l.toTypedArray(), 1)
        }
        pill(c4, "২. অন্য অ্যাপের উপরে দেখানো", R.drawable.ic_shield) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        pill(c4, "৩. ব্যাটারি অপটিমাইজেশন বন্ধ", R.drawable.ic_bolt) { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        pill(c4, "৪. অ্যাক্সেসিবিলিটি (স্ক্রিন, পোস্ট, মেসেজ, লক)", R.drawable.ic_lock) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        pill(c4, "৫. নোটিফিকেশন অ্যাক্সেস (ব্যবসা, WhatsApp/Messenger)", R.drawable.ic_store) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        note(c4, "৪ ও ৫ নম্বরে AI Friend বেছে চালু করো। আপডেটের পর একবার বন্ধ করে আবার চালু করো। বাটন ধূসর হলে: Settings, Apps, AI Friend, ওপরের তিন ডট, Allow restricted settings।")

        val csc = card(root, "ফোন স্ক্যান", R.drawable.ic_shield)
        fVt = field(csc, "VirusTotal API Key (ঐচ্ছিক, বাইরে থেকে নেওয়া অ্যাপের ম্যালওয়্যার যাচাই)", p.getString("vtkey", "") ?: "")
        note(csc, "ফ্রি কী virustotal.com এ অ্যাকাউন্ট খুলে পাবে। কী ছাড়াও স্ক্যান চলে। বলেও করানো যায়: অপর্ণা, ফোন স্ক্যান করো।")
        pill(csc, "সেভ করো", R.drawable.ic_shield, "#3D5AFE", "#5C7CFF") { p.edit().putString("vtkey", fVt.text.toString().trim()).apply(); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }
        pill(csc, "স্ক্যান শুরু করো", R.drawable.ic_shield, "#00796B", "#26A69A") { p.edit().putString("vtkey", fVt.text.toString().trim()).apply(); startScan() }

        val c5 = card(root, "API ব্যবহার ও লিমিট", R.drawable.ic_chart)
        statsTv = note(c5, ""); statsTv.setTextColor(Color.WHITE)
        logTv = note(c5, ""); logTv.textSize = 11.5f
        note(c5, "Google কোটা-বাকি জানানোর কোনো API দেয় না, তাই এখানে অ্যাপের নিজের গণনা দেখানো হচ্ছে। সঠিক লিমিট ও ব্যবহার AI Studio-তে দেখো।")
        pill(c5, "AI Studio-তে লিমিট দেখো", R.drawable.ic_chart, "#00796B", "#26A69A") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/usage?timeRange=last-28-days&tab=rate-limit")))
        }
        pill(c5, "লগ রিফ্রেশ করো", R.drawable.ic_list) { refreshStats() }

        val c6 = card(root, "ফ্রি API Key কোথায় পাবে", R.drawable.ic_key)
        note(c6, "aistudio.google.com/apikey এ Google অ্যাকাউন্ট দিয়ে ঢুকে Create API key চাপো। ক্রেডিট কার্ড লাগে না।")
        pill(c6, "API Key পেজ খোলো", R.drawable.ic_key) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) }

        val c7 = card(root, "ডেভলপার", R.drawable.ic_code)
        c7.addView(TextView(this).apply { text = "Medul"; textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(10), 0, 0) })
        note(c7, "AI Friend v4.0, তৈরি করেছেন Medul • এই নাম কখনো বদলানো যায় না")
    }

    private var bVoiceF: Button? = null
    private var bVoiceM: Button? = null
    private fun fVoiceCard(c2: LinearLayout) {
        bVoiceF = pill(c2, "মেয়ে কণ্ঠ বেছে শোনো: ${voiceF()}", R.drawable.ic_mic, "#AD1457", "#EC407A") { pickVoice(true) }
        bVoiceM = pill(c2, "ছেলে কণ্ঠ বেছে শোনো: ${voiceM()}", R.drawable.ic_mic, "#1565C0", "#42A5F5") { pickVoice(false) }
    }

    private fun saveHeart(cHeart: CheckBox, cAuto: CheckBox, fTrusted: EditText, fImg: EditText) {
        p.edit().putBoolean("heart", cHeart.isChecked).putBoolean("autoimage", cAuto.isChecked)
            .putString("trusted", fTrusted.text.toString().trim()).putString("imgModel", fImg.text.toString().trim())
            .putBoolean("camMood", cCam.isChecked).putString("camEvery", fCamEvery.text.toString().trim())
            .putBoolean("freeimg", cFree.isChecked).apply()
    }

    // ---------------- ওয়্যারড্রোব ----------------
    private fun buildWardrobe() {
        wardrobeBox.removeAllViews()
        header(wardrobeBox, "পোশাক / ওয়্যারড্রোব")
        note(wardrobeBox, "কার্টুন মুখে হুবহু আপনার পোশাকের ছবি বসানো সম্ভব না, কিন্তু ছবিটার প্রধান রঙ বের করে সেটা পোশাকের রঙ হিসেবে ব্যবহার করা যায়। ছবি এখানেই জমা থাকবে।")
        for (female in listOf(true, false)) {
            val c = card(wardrobeBox, if (female) "মেয়ে পোশাক" else "ছেলে পোশাক", R.drawable.ic_person)
            val presets = if (female) Outfits.FEMALE else Outfits.MALE
            val curIdx = p.getInt(if (female) "outfitIdxF" else "outfitIdxM", 0)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val sv = HorizontalScrollView(this); sv.addView(row)
            c.addView(sv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            for ((idx, o) in presets.withIndex()) {
                row.addView(Button(this).apply {
                    text = o.name; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
                    background = GradientDrawable().apply { setColor(o.color); cornerRadius = dp(14).toFloat(); if (idx == curIdx) setStroke(dp(3), Color.WHITE) }
                    setOnClickListener { p.edit().putInt(if (female) "outfitIdxF" else "outfitIdxM", idx).apply(); applyFaceToViews(); buildWardrobe() }
                }, LinearLayout.LayoutParams(dp(120), dp(46)).apply { marginEnd = dp(8) })
            }
            val uploads = outfitsArr(female)
            for (i in 0 until uploads.length()) {
                val u = uploads.getJSONObject(i)
                val idx = presets.size + i
                val f = File(filesDir, "outfits/${u.optString("file")}")
                val thumb = if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                col.addView(ImageView(this).apply {
                    if (thumb != null) setImageBitmap(thumb) else setBackgroundColor(u.optInt("color"))
                    background = bg("#00000000", 10, if (idx == curIdx) "#FFFFFF" else "#22FFFFFF")
                    setOnClickListener { p.edit().putInt(if (female) "outfitIdxF" else "outfitIdxM", idx).apply(); applyFaceToViews(); buildWardrobe() }
                }, LinearLayout.LayoutParams(dp(64), dp(64)))
                row.addView(col, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
            }
            pill(c, "গ্যালারি থেকে আপলোড করো", R.drawable.ic_play, "#00897B", "#26C6A8") {
                uploadGenderIsMale = !female
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), if (female) 21 else 22)
            }
        }
        pill(wardrobeBox, "ব্যাক", R.drawable.ic_back) { showPanel(1) }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data?.data == null || (req != 21 && req != 22)) return
        val female = req == 21
        try {
            val bm0 = contentResolver.openInputStream(data.data!!)?.use { BitmapFactory.decodeStream(it) } ?: return
            val sc = 300f / maxOf(bm0.width, bm0.height)
            val bm: Bitmap = if (sc < 1f) Bitmap.createScaledBitmap(bm0, (bm0.width * sc).toInt(), (bm0.height * sc).toInt(), true) else bm0
            val avg = averageColor(bm)
            val dir = File(filesDir, "outfits").apply { mkdirs() }
            val name = "o_${System.currentTimeMillis()}.jpg"
            File(dir, name).outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            val key = if (female) "outfitsF" else "outfitsM"
            val arr = outfitsArr(female)
            arr.put(JSONObject().put("file", name).put("color", avg))
            p.edit().putString(key, arr.toString()).apply()
            val presets = (if (female) Outfits.FEMALE else Outfits.MALE).size
            p.edit().putInt(if (female) "outfitIdxF" else "outfitIdxM", presets + arr.length() - 1).apply()
            applyFaceToViews(); buildWardrobe()
            Toast.makeText(this, "পোশাকের রঙ নেওয়া হয়েছে", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "ছবি নেওয়া যায়নি", Toast.LENGTH_SHORT).show() }
    }

    private fun averageColor(b: Bitmap): Int {
        var r = 0L; var g = 0L; var bl = 0L; var n = 0
        val sx = maxOf(1, b.width / 40); val sy = maxOf(1, b.height / 40)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val c = b.getPixel(x, y)
                r += Color.red(c); g += Color.green(c); bl += Color.blue(c); n++
                x += sx
            }
            y += sy
        }
        if (n == 0) return Color.GRAY
        return Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
    }

    // ---------------- কল রেকর্ড ----------------
    private fun buildCalls() {
        callsBox.removeAllViews()
        header(callsBox, "কল রেকর্ড")
        val arr = CallStore.load(this)
        if (arr.length() == 0) note(callsBox, "এখনো কোনো কল রেকর্ড নেই।")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            val whenTxt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(o.getString("id").toLong()))
            val c = card(callsBox, "${whenTxt} • ${o.getString("who")}", R.drawable.ic_phone)
            val lines = o.getJSONArray("lines")
            for (j in 0 until lines.length()) {
                val l = lines.getJSONObject(j)
                val who = if (l.getString("from") == "caller") "কলার" else "সহকারী"
                c.addView(TextView(this).apply {
                    text = "${who}: ${l.getString("text")}"; textSize = 14f
                    setTextColor(col(if (l.getString("from") == "caller") "#FFD54F" else "#E0E6FF")); setPadding(0, dp(8), 0, 0)
                })
                val af = l.optString("audio", "")
                if (af.isNotEmpty()) pill(c, "কলারের কণ্ঠ শুনো", R.drawable.ic_play, "#2B3A67", "#3C4F8F") { playFile(af) }
            }
        }
        if (arr.length() > 0) pill(callsBox, "সব মুছে ফেলো", R.drawable.ic_stop, "#C62828", "#EF5350") { CallStore.clear(this); buildCalls() }
    }

    private fun playFile(name: String) {
        try {
            player?.release()
            player = MediaPlayer().apply { setDataSource(CallStore.file(this@MainActivity, name).absolutePath); prepare(); start() }
        } catch (e: Exception) { Toast.makeText(this, "শোনা যাচ্ছে না", Toast.LENGTH_SHORT).show() }
    }

    private fun pickVoice(female: Boolean) {
        val list = (if (female) Gemini.FEMALE_VOICES else Gemini.MALE_VOICES).toTypedArray()
        AlertDialog.Builder(this).setTitle(if (female) "মেয়ে কণ্ঠ (চাপলে শুনতে পাবে)" else "ছেলে কণ্ঠ (চাপলে শুনতে পাবে)")
            .setItems(list) { _, i ->
                val v = list[i]
                p.edit().putString(if (female) "voiceF" else "voiceM", v).apply()
                (if (female) bVoiceF else bVoiceM)?.text = (if (female) "মেয়ে" else "ছেলে") + " কণ্ঠ বেছে শোনো: ${v}"
                val key = fKey.text.toString().trim(); val tm = fTts.text.toString().trim()
                status.text = "নমুনা আনছি…"
                Thread {
                    try {
                        val pcm = Gemini.tts(key, tm, v, "হ্যালো, আমি তোমার বন্ধু। আমার কণ্ঠটা কেমন লাগছে?", female)
                        runOnUiThread { status.text = "সেভ হয়েছে: ${v}" }
                        Gemini.play(pcm)
                    } catch (e: Exception) { runOnUiThread { status.text = "❌ ${e.message}" } }
                }.start()
            }.show()
    }

    private fun showPanel(n: Int) {
        if (panel == 1) save()
        panel = n
        home.visibility = if (n == 0) View.VISIBLE else View.GONE
        settingsView.visibility = if (n == 1) View.VISIBLE else View.GONE
        callsView.visibility = if (n == 2) View.VISIBLE else View.GONE
        scanPanel.visibility = if (n == 3) View.VISIBLE else View.GONE
        wardrobeView.visibility = if (n == 4) View.VISIBLE else View.GONE
        if (n != 3) window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        if (n == 1) refreshStats()
        if (n == 2) buildCalls()
        if (n == 4) buildWardrobe()
        if (n == 0) applyFaceToViews()
    }

    override fun onBackPressed() { if (panel != 0) showPanel(0) else super.onBackPressed() }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i?.getBooleanExtra("scan", false) == true) startScan()
    }

    private fun startScan() {
        if (scanning) return
        scanning = true
        showPanel(3)
        scanRes.visibility = View.GONE; scanView.reset()
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        val vt = p.getString("vtkey", "") ?: ""
        val key = p.getString("key", "") ?: ""; val model = p.getString("model", Gemini.DEF_MODEL) ?: Gemini.DEF_MODEL
        val owner = p.getString("owner", "মৃদুল") ?: "মৃদুল"
        Thread {
            val r = Scanner.scan(this, vt) { line, pct -> runOnUiThread { scanView.addLine(line); scanView.progress = pct } }
            val say = try { Gemini.scanSummary(key, model, owner, r.text(), r.score) }
                catch (e: Exception) { "স্ক্যান শেষ। নিরাপত্তা স্কোর ${r.score}। ${r.findings.count { it.sev >= 2 }}টি গুরুত্বপূর্ণ বিষয় পেয়েছি।" }
            runOnUiThread { showScanResult(r, say) }
            try {
                val female = resolveFemale()
                val voice = Gemini.validVoice(p.getString(if (female) "voiceF" else "voiceM", "") ?: "", female)
                val pcm = Gemini.tts(key, p.getString("ttsModel", Gemini.DEF_TTS) ?: Gemini.DEF_TTS, voice, say, female)
                p.edit().putLong("mute_until", System.currentTimeMillis() + pcm.size / 48 + 1500).apply()
                Gemini.play(pcm)
            } catch (_: Exception) {}
        }.start()
    }

    private fun showScanResult(r: Scanner.Result, say: String) {
        scanning = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        scanBox.removeAllViews()
        header(scanBox, "স্ক্যান ফলাফল")
        val colr = if (r.score >= 80) "#5CFFB0" else if (r.score >= 55) "#FFD54F" else "#FF6B6B"
        scanBox.addView(TextView(this).apply { text = "${r.score}/100"; textSize = 48f; setTextColor(col(colr)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0) })
        scanBox.addView(TextView(this).apply { text = "নিরাপত্তা স্কোর • ${r.apps}টি অ্যাপ পরীক্ষা"; textSize = 13f; setTextColor(col("#9AA5C4")); gravity = Gravity.CENTER })
        val cs = card(scanBox, "সারাংশ", R.drawable.ic_shield)
        note(cs, say).setTextColor(Color.WHITE)
        if (r.findings.isEmpty()) note(scanBox, "কোনো সন্দেহজনক চিহ্ন পাইনি।")
        for (f in r.findings) {
            val color = when (f.sev) { 3 -> "#FF6B6B"; 2 -> "#FFB74D"; 1 -> "#FFF176"; else -> "#9AA5C4" }
            val cc = card(scanBox, f.title, R.drawable.ic_lock)
            note(cc, f.detail).setTextColor(col(color))
        }
        pill(scanBox, "আবার স্ক্যান করো", R.drawable.ic_shield, "#00796B", "#26A69A") { startScan() }
        note(scanBox, "এটা একটা নিরাপত্তা-পরীক্ষা, সম্পূর্ণ অ্যান্টিভাইরাস নয়। সব ভাইরাস ধরতে পারে না, তাই সন্দেহজনক অ্যাপ বাদ দিন ও শুধু অফিসিয়াল স্টোর থেকে অ্যাপ নিন।")
        scanRes.visibility = View.VISIBLE
    }

    private fun refreshStats() { statsTv.text = Gemini.statsText(); logTv.text = "সাম্প্রতিক লগ:\n" + Gemini.logText() }

    private fun save() {
        p.edit().putString("key", fKey.text.toString().trim()).putString("model", fModel.text.toString().trim())
            .putString("name", fName.text.toString().trim()).putString("owner", fOwner.text.toString().trim())
            .putString("gender", gMode).putString("ttsModel", fTts.text.toString().trim())
            .putBoolean("always", cAlways.isChecked).putBoolean("flash", cFlash.isChecked).putBoolean("callmode", cCall.isChecked)
            .putBoolean("phonevoice", cPhone.isChecked).putBoolean("fb", cFb.isChecked).putBoolean("confirm", cConfirm.isChecked).apply()
    }

    private fun startAssistant() {
        save()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে সেটিংসে ২ নম্বর অনুমতি দাও", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "আগে সেটিংসে ১ নম্বর পারমিশন দাও", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        startForegroundService(Intent(this, AssistantService::class.java))
    }

    private fun test() {
        save(); status.text = "টেস্ট চলছে…"
        val key = fKey.text.toString().trim(); val model = fModel.text.toString().trim()
        val names = fName.text.toString().trim(); val owner = fOwner.text.toString().trim()
        val tm = fTts.text.toString().trim(); val mode = gMode
        Thread {
            try {
                val female = when (mode) {
                    "female" -> true
                    "male" -> false
                    else -> (Gemini.nameGender(key, model, names) ?: Gemini.guessGender(names)) == "female"
                }
                val j = Gemini.chat(key, model, Gemini.systemPrompt(names, owner, female), JSONArray(), "নিজের পরিচয় এক বাক্যে দাও")
                val say = j.optString("say", "হ্যালো")
                runOnUiThread { status.text = "✅ এআই ঠিক আছে: ${say}" }
                val pcm = Gemini.tts(key, tm, if (female) voiceF() else voiceM(), say, female)
                runOnUiThread { status.text = "✅ এআই ও কণ্ঠ দুটোই ঠিক আছে (${if (female) "মেয়ে" else "ছেলে"} কণ্ঠ)" }
                Gemini.play(pcm)
            } catch (e: Exception) { runOnUiThread { status.text = "❌ ${e.message}" } }
        }.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            val running = p.getBoolean("running", false)
            val face = if (faceStyle == "avatar") avatar.state else globe.state
            if (faceStyle == "avatar") avatar.state = if (running) p.getInt("state", 0) else 0
            else globe.state = if (running) p.getInt("state", 0) else 0
            heartTickRef(running)
            chip.text = if (running) "●  চালু" else "○  বন্ধ"
            chip.setTextColor(col(if (running) "#5CFFB0" else "#FF8A8A"))
            if (running && panel == 0) status.text = p.getString("status", "") ?: ""
            if (lastRun != running) {
                lastRun = running
                if (!running && panel == 0) status.text = "চালু করতে নিচের বাটন চাপো"
                big.text = if (running) "বন্ধ করো" else "চালু করো"
                big.background = if (running) grad("#C62828", "#EF5350", 30) else grad("#00A686", "#2BD9A8", 30)
                big.setCompoundDrawablesRelative(ico(if (running) R.drawable.ic_stop else R.drawable.ic_play), null, null, null)
            }
            h.postDelayed(this, 800)
        }
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); if (panel == 1) save() }
}
