package com.aifriend.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private fun edit(l: LinearLayout, hint: String, v: String) = EditText(this).apply {
        this.hint = hint; setText(v); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); l.addView(this)
    }
    private fun btn(l: LinearLayout, t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }; l.addView(this)
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B0F1E")); addView(root) }
        root.addView(TextView(this).apply { text = "🤖 AI Friend"; textSize = 28f; setTextColor(Color.CYAN); gravity = Gravity.CENTER })
        val key = edit(root, "Gemini API Key", p.getString("key", "")!!)
        val model = edit(root, "Model (যেমন gemini-2.5-flash)", p.getString("model", "gemini-2.5-flash")!!)
        val name = edit(root, "Assistant নাম (এই নামে ডাকবেন)", p.getString("name", "জারভিস")!!)
        val lang = edit(root, "ভাষা কোড (বাংলা: bn-BD) (bn-BD / en-US)", p.getString("lang", "bn-BD")!!)
        val flash = CheckBox(this).apply { text = "কথা বলার সময় ফোনের ফ্ল্যাশ লাইট জ্বলবে"; setTextColor(Color.WHITE); isChecked = p.getBoolean("flash", true) }
        root.addView(flash)
        btn(root, "💾 Save") {
            p.edit().putString("key", key.text.toString().trim()).putString("model", model.text.toString().trim())
                .putString("name", name.text.toString().trim()).putString("lang", lang.text.toString().trim())
                .putBoolean("flash", flash.isChecked).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        btn(root, "1️⃣ পারমিশন দিন (মাইক, ক্যামেরা, কল, কন্টাক্ট)") {
            val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
                Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(l.toTypedArray(), 1)
        }
        btn(root, "2️⃣ অন্য অ্যাপের উপরে দেখানোর পারমিশন") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn(root, "🔊 মেয়ের কণ্ঠ বেছে নিন") {
            var t: android.speech.tts.TextToSpeech? = null
            t = android.speech.tts.TextToSpeech(this) {
                val vs = t!!.voices?.filter { it.locale.language == "bn" }?.sortedBy { it.name } ?: emptyList()
                if (vs.isEmpty()) {
                    Toast.makeText(this, "বাংলা ভয়েস নেই। Google Speech Services এ বাংলা ভয়েস ডাউনলোড করুন", Toast.LENGTH_LONG).show()
                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                } else AlertDialog.Builder(this).setTitle("ভয়েস চাপুন, শুনে পছন্দ করুন")
                    .setItems(vs.map { it.name }.toTypedArray()) { _, i ->
                        p.edit().putString("voice", vs[i].name).apply()
                        t!!.voice = vs[i]; t!!.setPitch(1.15f)
                        t!!.speak("হ্যালো, আমি তোমার বন্ধু। এই কণ্ঠটা কেমন লাগছে?", android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "x")
                        Toast.makeText(this, "সেভ হয়েছে: " + vs[i].name + " — START আবার চাপুন", Toast.LENGTH_LONG).show()
                    }.show()
            }
        }
        btn(root, "🔋 ব্যাটারি অপটিমাইজেশন বন্ধ করুন (সবসময় চালু থাকার জন্য)") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn(root, "▶️ START (সবসময় চালু)") { startForegroundService(Intent(this, AssistantService::class.java)) }
        btn(root, "⏹ STOP") { stopService(Intent(this, AssistantService::class.java)) }
    }
}
