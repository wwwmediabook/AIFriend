package com.aifriend.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** ফোন লক / হোম / ব্যাক / স্ক্রিনশট করার জন্য */
class AccessSvc : AccessibilityService() {
    companion object { @Volatile var inst: AccessSvc? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
