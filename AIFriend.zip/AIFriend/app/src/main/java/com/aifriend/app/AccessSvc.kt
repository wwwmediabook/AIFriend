package com.aifriend.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** স্ক্রিন পড়া, ট্যাপ, টাইপ, স্ক্রল, স্ক্রিনশট, ফোন লক ইত্যাদির জন্য */
class AccessSvc : AccessibilityService() {
    companion object { @Volatile var inst: AccessSvc? = null }

    class Snap(val pkg: String, val dump: String, val nodes: List<AccessibilityNodeInfo>)

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun snapshot(): Snap? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || nodes.size >= 90 || depth > 25) return
            if (n.isVisibleToUser) {
                val t = (n.text?.toString() ?: "").take(70)
                val d = (n.contentDescription?.toString() ?: "").take(70)
                if (t.isNotEmpty() || d.isNotEmpty() || n.isClickable || n.isEditable || n.isScrollable) {
                    val i = nodes.size; nodes.add(n)
                    val r = Rect(); n.getBoundsInScreen(r)
                    sb.append(i).append('|').append((n.className?.toString() ?: "").substringAfterLast('.')).append('|')
                        .append(if (t.isNotEmpty()) t else d).append('|')
                        .append(if (n.isClickable) "c" else "").append(if (n.isEditable) "e" else "")
                        .append(if (n.isScrollable) "s" else "").append(if (n.isChecked) "k" else "")
                        .append('|').append(r.centerX()).append(',').append(r.centerY()).append('\n')
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return Snap(root.packageName?.toString() ?: "", sb.toString(), nodes)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var d = 0
        while (x != null && d < 6) {
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent; d++
        }
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun focusedInput(): AccessibilityNodeInfo? = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    fun scroll(forward: Boolean): Boolean {
        val s = findScrollable(rootInActiveWindow) ?: return false
        return s.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun shot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val bmp = try { Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false) } catch (e: Exception) { null }
                try { r.hardwareBuffer.close() } catch (_: Exception) {}
                cb(bmp)
            }
            override fun onFailure(code: Int) { cb(null) }
        })
    }
}
