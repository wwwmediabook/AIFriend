plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.aifriend.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.aifriend.app"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "4.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core:1.12.0")
}
